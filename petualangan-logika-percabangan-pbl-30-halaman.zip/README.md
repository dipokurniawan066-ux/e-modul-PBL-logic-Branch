# E-Modul Web Digital Flipbook (30 Halaman) Berbasis Problem-Based Learning (PBL)
**Mata Pelajaran:** Informatika — Elemen Berpikir Komputasional (BK)  
**Sasaran:** Fase E (Kelas X SMK) Kurikulum Merdeka  
**Materi Pokok:** Penalaran & Pemecahan Masalah Logika Percabangan (*Single IF*, *IF-ELSE*, dan *Nested IF*)

## Kesesuaian dengan Spesifikasi Produk (Tabel 1.1 Skripsi)
1. **Format & Aksesibilitas:** Web responsif berbasis HTML5 Digital Flipbook (30 Halaman / 15 Spread Bukaan Buku + Mode Fokus 1 Halaman) lintas platform (PC, laptop, smartphone) tanpa instalasi tambahan.
2. **Cakupan Kurikulum:** Capaian Pembelajaran (CP) Elemen Berpikir Komputasional (BK) Informatika Fase E Kelas X SMK pada materi **Single IF (KB 1)**, **IF-ELSE (KB 2)**, dan **Nested IF & Percabangan Majemuk (KB 3)**.
3. **Struktur Pedagogis (5 Tahapan Sintaks PBL di Setiap KB):**
   - **Tahap 1 — Orientasi Masalah:** Studi kasus logika kontrol kontekstual SMK (Hal. 5, 11, 17).
   - **Tahap 2 — Organisasi Belajar:** Identifikasi variabel input, kondisi, dan output (Hal. 6, 12, 18).
   - **Tahap 3 — Penyelidikan Mandiri:** Pemaparan konsep, visualisasi flowchart berkode warna, penelusuran kode (*code tracing*), dan simulasi interaktif (Hal. 7–8, 13–14, 19–22).
   - **Tahap 4 — Penyajian Solusi:** Lembar kerja perancangan alur percabangan / LKPD Digital (Hal. 9, 15, 23).
   - **Tahap 5 — Evaluasi & Refleksi:** Kuis pemecahan masalah formatif dengan umpan balik otomatis (*immediate feedback*) & jurnal refleksi mandiri (Hal. 10, 16, 24).
4. **Desain Antarmuka (UI/UX):** Dilengkapi **Clickable Table of Contents (Daftar Isi Interaktif)**, **Bilah Pencarian (Search Bar)** real-time, **Tombol Navigasi & Lompat Halaman (1–30)**, serta **Visualisasi Diagram Alir (Flowchart) Berkode Warna**.
5. **Fitur Interaktivitas:** Menyematkan **Video Penjelasan Konsep Singkat (Microlearning)**, **Simulasi Alur Percabangan 2D/3D**, **Code Tracing Interaktif**, dan **Latihan Formatif & Sumatif Digital (Immediate Feedback)**.
6. **Bahan Penyerta (Supplementary Material):**
   - **Modul Ajar / Rencana Pembelajaran Mendalam (RPM) Informatika Fase E** (Hal. 27–28).
   - **Buku Petunjuk Penggunaan (User Guide) Guru dan Peserta Didik** (Hal. 29–30).

## Cara Menjalankan Proyek (Mode Pengembangan)
1. Instal dependensi: `npm install` atau `bun install`
2. Jalankan server pengembangan: `npm run dev` atau `bun dev`
3. Build produksi: `npm run build`
