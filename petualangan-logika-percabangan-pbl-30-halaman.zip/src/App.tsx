/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * 
 * PETUALANGAN LOGIKA PERCABANGAN: Dari Lampu Merah Sampai Wahana Roller Coaster
 * VIK Kompas Pop-Editorial Interactive 3D Flipbook E-Module (Edisi Khusus Anak & Pemula)
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  BookOpen,
  ChevronLeft,
  ChevronRight,
  Volume2,
  VolumeX,
  RotateCcw,
  Sparkles,
  Award,
  ArrowRight,
  ShieldAlert,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Lightbulb,
  Trophy,
  Target,
  Smile,
  Zap,
  Check,
  Gift,
  Coins,
  Copy,
  Terminal,
  Sliders,
  Code2,
  Play,
  RefreshCw,
  Compass,
  ClipboardList,
  FileText,
  Search,
  Gamepad2
} from 'lucide-react';
import { VendingMachine3D } from './components/VendingMachine3D';
import { VendingMachine2D } from './components/VendingMachine2D';
import { PAGES_CATALOG, SPREADS_CATALOG } from './data/pagesCatalog';
import { PageHeaderBadge } from './components/InteractiveWidgets';
import {
  KB1Spread1OrientasiOrganisasi,
  KB1Page07FlowchartAndTracing,
  KB1Spread3SolusiEvaluasi,
  KB2Spread1OrientasiOrganisasi,
  KB2Page13FlowchartAndTracing,
  KB2Spread3SolusiEvaluasi,
  KB3Spread1OrientasiOrganisasi,
  KB3Spread2NestedIfInvestigation,
  KB3Spread4SolusiEvaluasi
} from './components/PBLActivityPages';
import {
  Spread0CoverAndIntro,
  Spread1TocAndCurriculum,
  Spread12SummativeEvaluation,
  Spread13ModulAjarRPM,
  Spread14UserGuideAndBackCover
} from './components/FrontAndBackPages';

// ==========================================
// 1. SYNTHETIC AUDIO ENGINE (Web Audio API)
// ==========================================
class SoundSynth {
  private ctx: AudioContext | null = null;
  public enabled: boolean = true;

  private getContext(): AudioContext | null {
    if (!this.ctx && typeof window !== 'undefined') {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  // Realistic magazine page turn whoosh
  playPageFlip() {
    if (!this.enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const bufferSize = Math.floor(ctx.sampleRate * 0.22);
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.4));
      }
      const noise = ctx.createBufferSource();
      noise.buffer = buffer;

      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(800, ctx.currentTime);
      filter.frequency.exponentialRampToValueAtTime(160, ctx.currentTime + 0.2);
      filter.Q.setValueAtTime(1.8, ctx.currentTime);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.35, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.21);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      noise.start();
    } catch {
      // Audio fallback silent
    }
  }

  // Tactile button click
  playClick() {
    if (!this.enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(520, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(120, ctx.currentTime + 0.05);

      gain.gain.setValueAtTime(0.18, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.05);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.06);
    } catch {
      // ignore
    }
  }

  // Celebratory chord for success/approval
  playSuccess() {
    if (!this.enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
      notes.forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'sine';
        osc.frequency.value = freq;

        const startTime = ctx.currentTime + idx * 0.07;
        gain.gain.setValueAtTime(0.12, startTime);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.35);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + 0.36);
      });
    } catch {
      // ignore
    }
  }

  // Star sound
  playStarEarned() {
    if (!this.enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      [659.25, 830.61, 987.77, 1318.51].forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.value = freq;

        const startTime = ctx.currentTime + idx * 0.06;
        gain.gain.setValueAtTime(0.15, startTime);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.4);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + 0.41);
      });
    } catch {
      // ignore
    }
  }

  // Buzzer/rejection sound
  playBuzzer() {
    if (!this.enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(170, ctx.currentTime);
      osc.frequency.setValueAtTime(120, ctx.currentTime + 0.1);

      gain.gain.setValueAtTime(0.14, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.24);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.25);
    } catch {
      // ignore
    }
  }

  // Tire brake screech
  playBrake() {
    if (!this.enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(850, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(260, ctx.currentTime + 0.3);

      gain.gain.setValueAtTime(0.16, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.3);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.31);
    } catch {
      // ignore
    }
  }

  // Rollercoaster rush whoosh
  playCoaster() {
    if (!this.enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(180, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(750, ctx.currentTime + 0.22);
      osc.frequency.exponentialRampToValueAtTime(140, ctx.currentTime + 0.45);

      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.45);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.46);
    } catch {
      // ignore
    }
  }

  // Vending snack drop
  playVendingDrop() {
    if (!this.enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(780, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(210, ctx.currentTime + 0.16);

      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.16);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.17);
    } catch {
      // ignore
    }
  }

  // Coin insert sound
  playCoinInsert() {
    if (!this.enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1200, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(2400, ctx.currentTime + 0.08);

      gain.gain.setValueAtTime(0.15, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.09);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.1);
    } catch {
      // ignore
    }
  }

  // Arcade tone beep
  playArcadeBeep(frequency = 650) {
    if (!this.enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'square';
      osc.frequency.setValueAtTime(frequency, ctx.currentTime);
      gain.gain.setValueAtTime(0.14, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.09);
    } catch {
      // ignore
    }
  }

  // Jackpot fanfare celebration
  playJackpot() {
    if (!this.enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;
    try {
      [523.25, 659.25, 783.99, 1046.5, 1318.51, 1567.98].forEach((freq, idx) => {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.value = freq;

        const startTime = ctx.currentTime + idx * 0.07;
        gain.gain.setValueAtTime(0.15, startTime);
        gain.gain.exponentialRampToValueAtTime(0.001, startTime + 0.35);

        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(startTime);
        osc.stop(startTime + 0.36);
      });
    } catch {
      // ignore
    }
  }
}

const audio = new SoundSynth();

// ==========================================
// 2. DATA & TYPES
// ==========================================
interface ChapterInfo {
  id: number;
  badge: string;
  title: string;
  subtitle: string;
  themeColor: string;
}

const CHAPTERS: ChapterInfo[] = [
  {
    id: 0,
    badge: 'EDISI SPESIAL ANAK',
    title: 'COVER & PETUNJUK',
    subtitle: 'Petualangan Logika Percabangan',
    themeColor: 'amber'
  },
  {
    id: 1,
    badge: 'BAB 01 // KEPUTUSAN TUNGGAL',
    title: 'IF TUNGGAL',
    subtitle: 'Simulasi Lampu Zebra Cross',
    themeColor: 'red'
  },
  {
    id: 2,
    badge: 'BAB 02 // DUA PERCABANGAN',
    title: 'IF - ELSE',
    subtitle: 'Verifikasi Berkas Magang (Rapor, Jurusan, Ijazah)',
    themeColor: 'emerald'
  },
  {
    id: 3,
    badge: 'BAB 03 // BANYAK KONDISI BERTINGKAT',
    title: 'ELSE IF BERTINGKAT',
    subtitle: 'Mesin Permainan Arcade & Hadiah Poin Tiket',
    themeColor: 'amber'
  },
  {
    id: 4,
    badge: 'BAB 04 // PEMILIH CEPAT',
    title: 'SWITCH - CASE',
    subtitle: '3D Vending Machine Realistis Kantin Asli',
    themeColor: 'purple'
  },
  {
    id: 5,
    badge: 'BAB 05 // MULTI-SYARAT',
    title: 'LOGIKA && DAN ||',
    subtitle: 'Gerbang Masuk Roller Coaster',
    themeColor: 'rose'
  }
];

// Component for Kids Quiz & Mission Box
function KidMissionBox({
  chapterId,
  missionTitle,
  analogy,
  steps,
  question,
  options,
  hasWonStar,
  onEarnStar
}: {
  chapterId: number;
  missionTitle: string;
  analogy: string;
  steps: string[];
  question: string;
  options: { text: string; correct: boolean; explanation: string }[];
  hasWonStar: boolean;
  onEarnStar: () => void;
}) {
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [showFeedback, setShowFeedback] = useState<boolean>(false);

  const handleSelectOption = (idx: number) => {
    setSelectedOption(idx);
    setShowFeedback(true);
    const opt = options[idx];
    if (opt.correct) {
      audio.playStarEarned();
      onEarnStar();
    } else {
      audio.playBuzzer();
    }
  };

  return (
    <div className="mt-4 p-4 bg-amber-50 rounded-xl border-2 border-slate-950 pop-card text-slate-900">
      {/* Header Misi */}
      <div className="flex items-center justify-between border-b-2 border-slate-900 pb-2 mb-3">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-amber-400 border border-slate-900 flex items-center justify-center font-black text-xs">
            🎯
          </div>
          <div>
            <div className="text-xs font-black tracking-wider uppercase text-amber-900">
              MISI DETEKTIF CILIK #{chapterId}
            </div>
            <div className="text-xs font-black text-slate-950">{missionTitle}</div>
          </div>
        </div>

        {/* Badge Bintang */}
        <div className={`px-2.5 py-1 rounded-full text-xs font-black flex items-center gap-1 border-2 border-slate-950 pop-card-sm ${
          hasWonStar ? 'bg-amber-400 text-slate-950' : 'bg-slate-200 text-slate-600'
        }`}>
          <Sparkles className="w-3.5 h-3.5" />
          <span>{hasWonStar ? 'BINTANG DIDAPAT! ⭐' : 'BELUM SELESAI'}</span>
        </div>
      </div>

      {/* 3 Langkah Bermain Interaktif */}
      <div className="mb-3 bg-white p-3 rounded-lg border border-slate-900">
        <div className="text-[11px] font-black uppercase text-slate-700 tracking-wider mb-1.5 flex items-center gap-1.5">
          <Target className="w-3.5 h-3.5 text-emerald-600" />
          <span>3 Langkah Praktik Menyenangkan:</span>
        </div>
        <div className="space-y-1 text-xs text-slate-800">
          {steps.map((st, i) => (
            <div key={i} className="flex items-start gap-1.5">
              <span className="font-bold text-amber-600 shrink-0">{i + 1}.</span>
              <span>{st}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Analogi Dunia Nyata Anak */}
      <div className="mb-3 bg-amber-100/70 p-2.5 rounded-lg border border-amber-300 flex items-start gap-2 text-xs">
        <Lightbulb className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
        <div>
          <strong className="text-amber-950">Analogi Seru:</strong>{' '}
          <span className="text-amber-900">{analogy}</span>
        </div>
      </div>

      {/* Soal Tantangan Interaktif */}
      <div className="border-t-2 border-dashed border-slate-300 pt-3">
        <div className="text-xs font-black text-slate-950 mb-2 flex items-center gap-1.5">
          <HelpCircle className="w-4 h-4 text-sky-600" />
          <span>Tantangan Soal: {question}</span>
        </div>

        {/* Opsi Pilihan Jawaban */}
        <div className="space-y-1.5">
          {options.map((opt, idx) => {
            const isSelected = selectedOption === idx;
            return (
              <button
                key={idx}
                onClick={() => handleSelectOption(idx)}
                className={`w-full text-left p-2.5 rounded-lg border-2 text-xs font-bold transition-all cursor-pointer flex items-center justify-between ${
                  isSelected
                    ? opt.correct
                      ? 'bg-emerald-200 border-emerald-600 text-emerald-950 pop-card-sm'
                      : 'bg-rose-200 border-rose-600 text-rose-950 pop-card-sm'
                    : 'bg-white hover:bg-slate-100 border-slate-900 text-slate-900'
                }`}
              >
                <span>{opt.text}</span>
                {isSelected && (
                  <span>
                    {opt.correct ? (
                      <Check className="w-4 h-4 text-emerald-700 stroke-[3]" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-700" />
                    )}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Feedback Penjelasan */}
        {showFeedback && selectedOption !== null && (
          <div className={`mt-2.5 p-2.5 rounded-lg border text-xs font-semibold ${
            options[selectedOption].correct
              ? 'bg-emerald-100 border-emerald-400 text-emerald-900'
              : 'bg-rose-100 border-rose-400 text-rose-900'
          }`}>
            <div className="font-black mb-0.5">
              {options[selectedOption].correct
                ? '🎉 Luar Biasa! Jawabanmu Benar!'
                : '💡 Jangan Menyerah! Coba Pikirkan Lagi:'}
            </div>
            <div>{options[selectedOption].explanation}</div>
          </div>
        )}
      </div>
    </div>
  );
}

// ==========================================
// 3. SPREAD 0: COVER SPREAD
// ==========================================
function CoverSpread({
  onOpenBook,
  onOpenPBLModal
}: {
  onOpenBook: () => void;
  onOpenPBLModal: () => void;
}) {
  const [teaserState, setTeaserState] = useState(false);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 h-full w-full">
      {/* HALAMAN KIRI: HERO EDITORIAL KOMPAS POP */}
      <div className="relative p-6 lg:p-10 flex flex-col justify-between border-b lg:border-b-0 lg:border-r-2 border-slate-900 bg-amber-400 overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#0f172a_2px,transparent_2px)] [background-size:18px_18px] pointer-events-none" />

        <div className="relative z-10 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 bg-slate-950 text-white px-3 py-1 text-xs font-bold tracking-widest pop-card-sm uppercase">
            <span>VIK KOMPAS</span>
            <span className="text-amber-400">●</span>
            <span>EDUKASI ANAK</span>
          </div>
          <span className="text-xs font-black tracking-wider text-slate-950 uppercase border-b-2 border-slate-950">
            VOL. 01 / EDISI SISWA CERDAS
          </span>
        </div>

        <div className="relative z-10 my-auto py-4">
          <div className="inline-flex items-center gap-1.5 bg-slate-950 text-amber-300 text-[11px] font-black px-3 py-1 mb-2 border-2 border-slate-950 pop-card-sm tracking-wider uppercase">
            <Compass className="w-3.5 h-3.5 text-amber-400" />
            <span>★ E-MODUL BERBASIS PROBLEM-BASED LEARNING (PBL)</span>
          </div>
          <h1 className="text-3xl lg:text-5xl font-black text-slate-950 leading-[1.08] tracking-tight uppercase">
            Petualangan <br />
            <span className="bg-slate-950 text-amber-300 px-2 py-0.5 inline-block my-1 pop-card-sm">
              Logika Percabangan
            </span>
          </h1>
          <p className="mt-3 text-sm lg:text-base font-bold text-slate-900 leading-snug max-w-md">
            Mulai dari Lampu Merah Penyeberang Jalan, Seleksi Berkas Magang, Pabrik Hadiah Juara Anak, Vending Machine Jajanan Asli, Sampai Wahana Roller Coaster Ekstrem!
          </p>

          <div className="mt-5 p-4 bg-white border-2 border-slate-950 pop-card flex items-center justify-around gap-2">
            <div className="flex flex-col items-center">
              <div className="w-8 h-16 bg-slate-950 rounded-lg p-1.5 flex flex-col justify-between items-center border border-slate-800">
                <div className="w-4 h-4 rounded-full bg-red-500 shadow-[0_0_8px_#ef4444]" />
                <div className="w-4 h-4 rounded-full bg-amber-500/30" />
                <div className="w-4 h-4 rounded-full bg-emerald-500/30" />
              </div>
              <span className="text-[10px] font-bold mt-1 uppercase text-slate-800">IF (Merah)</span>
            </div>

            <div className="flex flex-col items-center">
              <div className="w-12 h-12 rotate-45 bg-amber-400 border-2 border-slate-950 flex items-center justify-center font-black text-xs text-slate-950 shadow-sm">
                <span className="-rotate-45">IF ?</span>
              </div>
              <span className="text-[10px] font-bold mt-3 uppercase text-slate-800">Kondisi</span>
            </div>

            <div className="flex flex-col items-center">
              <div className="relative w-14 h-12 bg-sky-500 border-2 border-slate-950 rounded-md flex items-center justify-center text-white font-black text-xs">
                <span>🎢 CO</span>
                <div className="absolute -bottom-2 -left-1 w-3 h-3 rounded-full bg-slate-950 border border-white" />
                <div className="absolute -bottom-2 -right-1 w-3 h-3 rounded-full bg-slate-950 border border-white" />
              </div>
              <span className="text-[10px] font-bold mt-2 uppercase text-slate-800">&& AND</span>
            </div>
          </div>
        </div>

        <div className="relative z-10 w-full overflow-hidden bg-slate-950 text-amber-300 py-1.5 border-2 border-slate-950 font-code text-xs font-bold tracking-widest uppercase">
          <div className="animate-ticker">
            <span className="mx-4">PBL: 1. MASALAH NYATA • 2. VARIABEL SYARAT • 3. LAB PENYELIDIKAN • 4. SOLUSI ALGORITMA • 5. EVALUASI KUIS •</span>
            <span className="mx-4">PBL: 1. MASALAH NYATA • 2. VARIABEL SYARAT • 3. LAB PENYELIDIKAN • 4. SOLUSI ALGORITMA • 5. EVALUASI KUIS •</span>
          </div>
        </div>
      </div>

      {/* HALAMAN KANAN */}
      <div className="relative p-6 lg:p-10 flex flex-col justify-between bg-slate-50 text-slate-900 paper-bg">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-slate-600 mb-1">
            <BookOpen className="w-4 h-4 text-amber-600" />
            <span>PANDUAN BELAJAR SERU // LOGIKA PEMROGRAMAN BERBASIS MASALAH (PBL)</span>
          </div>
          <h2 className="text-2xl font-black text-slate-950 tracking-tight">
            Bagaimana Komputer Mengambil Keputusan?
          </h2>
          <p className="mt-2 text-xs lg:text-sm text-slate-700 leading-relaxed">
            Halo Teman-Teman! Komputer itu seperti robot pembantu yang sangat patuh. Komputer memakai 
            <strong className="text-slate-950 font-bold"> Logika Percabangan</strong>: aturan 
            <span className="bg-amber-200 px-1 font-bold">"JIKA syarat terpenuhi, MAKA lakukan aksi ini"</span>. 
            Di modul berbasis <strong className="text-sky-700 font-black">Problem-Based Learning (PBL)</strong> ini, kalian akan menjadi <strong className="text-slate-950">Detektif Logika</strong> untuk memecahkan 5 masalah nyata sehari-hari!
          </p>

          {/* Banner Interaktif Model PBL */}
          <div className="mt-3 p-3 bg-gradient-to-r from-sky-100 via-amber-50 to-emerald-100 border-2 border-slate-900 rounded-xl pop-card-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2.5">
            <div>
              <div className="text-[10px] font-mono font-black uppercase text-sky-800 flex items-center gap-1">
                <span>🧭</span>
                <span>MODEL PEMBELAJARAN INOVATIF</span>
              </div>
              <div className="text-xs font-black text-slate-950">
                5 Sintaks Problem-Based Learning (PBL)
              </div>
              <div className="text-[11px] text-slate-700 font-medium">
                Pecahkan masalah nyata dari zebra cross hingga wahana Dufan!
              </div>
            </div>
            <button
              onClick={() => {
                audio.playClick();
                onOpenPBLModal();
              }}
              className="py-1.5 px-3 bg-slate-950 hover:bg-slate-800 text-amber-300 font-black text-xs rounded border border-slate-900 pop-card-sm cursor-pointer whitespace-nowrap shrink-0 transition-transform active:scale-95 flex items-center gap-1.5"
            >
              <Compass className="w-3.5 h-3.5 text-amber-400" />
              <span>Buka Panduan PBL & LKPD</span>
            </button>
          </div>

          <div className="mt-3 p-3 bg-amber-50 border-2 border-slate-900 rounded-lg pop-card-sm">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                Uji Coba Cepat: Klik Tombol Saklar Ini!
              </span>
              <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold border ${teaserState ? 'bg-emerald-200 border-emerald-600 text-emerald-950' : 'bg-red-200 border-red-600 text-red-950'}`}>
                KONDISI: {teaserState ? 'TRUE (BENAR)' : 'FALSE (SALAH)'}
              </span>
            </div>
            <button
              onClick={() => {
                audio.playClick();
                setTeaserState(!teaserState);
              }}
              className="w-full py-2 px-3 text-xs font-black uppercase tracking-wider bg-slate-900 text-white rounded hover:bg-slate-800 transition-transform active:translate-y-0.5 pop-card-sm flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>{teaserState ? '✅ KONDISI SEKARANG: TRUE (BENAR)' : '👉 KLIK UNTUK MENGUBAH JADI TRUE!'}</span>
            </button>
          </div>

          <div className="mt-3">
            <div className="text-[11px] font-black tracking-wider text-slate-500 uppercase mb-1.5">
              5 Misi Masalah Nyata (PBL):
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs font-bold">
              {CHAPTERS.slice(1).map((ch) => (
                <div key={ch.id} className="p-2 bg-white border border-slate-900 rounded pop-card-sm flex items-start gap-2">
                  <span className="w-5 h-5 rounded-full bg-slate-950 text-white flex items-center justify-center text-[10px] shrink-0 font-mono">
                    {ch.id}
                  </span>
                  <div>
                    <div className="text-slate-950 font-black">{ch.title}</div>
                    <div className="text-[11px] text-slate-600 font-medium">{ch.subtitle}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-4 pt-3 border-t-2 border-slate-300">
          <button
            onClick={() => {
              audio.playPageFlip();
              onOpenBook();
            }}
            className="w-full py-3.5 px-6 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-sm uppercase tracking-wider rounded-lg border-2 border-slate-950 pop-card flex items-center justify-center gap-2 transition-all active:translate-y-0.5 cursor-pointer"
          >
            <span>Mulai Petualangan Misi 1 (IF Tunggal) →</span>
          </button>
          <div className="mt-1.5 text-center text-[11px] font-semibold text-slate-500">
            Kumpulkan 5 Bintang ⭐ dari tiap bab untuk mendapatkan Sertifikat Juara Detektif!
          </div>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 4. SPREAD 1: IF TUNGGAL (ZEBRA CROSS)
// ==========================================
function ZebraCrossSpread({
  hasWonStar,
  onEarnStar,
  onOpenPBLModal
}: {
  hasWonStar: boolean;
  onEarnStar: () => void;
  onOpenPBLModal: () => void;
}) {
  const [buttonPressed, setButtonPressed] = useState<boolean>(false);
  const [carX, setCarX] = useState<number>(10);
  const [kidStep, setKidStep] = useState<number>(0);
  const [carSpeed, setCarSpeed] = useState<number>(60);
  const [codeLang, setCodeLang] = useState<'js' | 'indo'>('js');
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);

  useEffect(() => {
    let animId: number;
    let currentX = 5;
    const speedFactor = carSpeed === 30 ? 0.6 : carSpeed === 60 ? 1.1 : 1.8;

    const animate = () => {
      if (!buttonPressed) {
        currentX = currentX + speedFactor;
        if (currentX > 105) currentX = -25;
        setCarX(currentX);
        setKidStep(0);
        animId = requestAnimationFrame(animate);
      } else {
        // Mobil berhenti tertib sebelum garis putih (Stop Line di 50%)
        // Posisi carX = 18%, sehingga bumper depan mobil berada di ~38% (jarak aman ~12% sebelum garis)
        setCarX(18);
        setKidStep((prev) => (prev < 100 ? prev + 1.2 : 100));
        animId = requestAnimationFrame(animate);
      }
    };
    animId = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(animId);
  }, [buttonPressed, carSpeed]);

  const handleToggle = () => {
    if (!buttonPressed) {
      audio.playBrake();
      setTimeout(() => audio.playSuccess(), 400);
      setButtonPressed(true);
    } else {
      audio.playClick();
      setButtonPressed(false);
      setKidStep(0);
    }
  };

  const handleCopyCode = () => {
    audio.playClick();
    const codeString = `// Logika Percabangan IF Tunggal Lampu Zebra Cross
let tombolDitekan = ${buttonPressed};

if (tombolDitekan === true) {
  lampuLaluLintas = "MERAH (STOP)";
  mobil.remBerhentiSebelumGarisPutih(); // 🛑 Berhenti tertib sebelum garis henti
  palangZebra.buka();
  pejalanKaki.menyeberang();
}`;
    navigator.clipboard?.writeText(codeString);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const runSimulation = () => {
    audio.playClick();
    setIsSimulating(true);
    setTimeout(() => {
      if (!buttonPressed) {
        handleToggle();
      }
      setIsSimulating(false);
    }, 600);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 h-full w-full">
      {/* ========================================================= */}
      {/* SISI KIRI: ATAS = CONTOH KODING, BAWAH = LAB COBA SENDIRI */}
      {/* ========================================================= */}
      <div className="relative p-5 lg:p-7 flex flex-col justify-between border-b lg:border-b-0 lg:border-r-2 border-slate-900 bg-slate-100 overflow-y-auto">
        <div>
          {/* Header */}
          <div className="flex items-center justify-between text-xs font-bold mb-1">
            <span className="bg-red-500 text-white px-2.5 py-0.5 rounded pop-card-sm uppercase">
              BAB 01 // KEPUTUSAN TUNGGAL (IF)
            </span>
            <span className="font-mono text-slate-700 font-bold bg-white px-2 py-0.5 rounded border border-slate-900">
              KODE & LAB MANDIRI
            </span>
          </div>
          <h2 className="text-xl lg:text-2xl font-black text-slate-950 uppercase tracking-tight mb-3">
            Logika IF Tunggal & Playground
          </h2>

          {/* ALUR PROBLEM-BASED LEARNING (PBL) */}
          <PBLStepBar chapterNum={1} onOpenPBLModal={onOpenPBLModal} />

          {/* --------------------------------------------------------- */}
          {/* SISI KIRI ATAS: CONTOH KODING INTERAKTIF                   */}
          {/* --------------------------------------------------------- */}
          <div className="bg-slate-950 text-slate-100 rounded-xl border-2 border-slate-900 pop-card overflow-hidden mb-4 shadow-lg">
            {/* Window Bar */}
            <div className="bg-slate-900 px-3 py-2 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                </div>
                <div className="flex items-center gap-1.5 ml-2 font-mono text-xs font-bold text-slate-300">
                  <Code2 className="w-3.5 h-3.5 text-sky-400" />
                  <span>zebra_cross.js</span>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <div className="flex bg-slate-800 rounded p-0.5 border border-slate-700 text-[10px] font-bold">
                  <button
                    onClick={() => setCodeLang('js')}
                    className={`px-1.5 py-0.5 rounded cursor-pointer ${codeLang === 'js' ? 'bg-sky-500 text-slate-950 font-black' : 'text-slate-400 hover:text-white'}`}
                  >
                    JavaScript
                  </button>
                  <button
                    onClick={() => setCodeLang('indo')}
                    className={`px-1.5 py-0.5 rounded cursor-pointer ${codeLang === 'indo' ? 'bg-amber-400 text-slate-950 font-black' : 'text-slate-400 hover:text-white'}`}
                  >
                    Bahasa Logika
                  </button>
                </div>
                <button
                  onClick={handleCopyCode}
                  className="flex items-center gap-1 px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 text-[10px] font-bold cursor-pointer"
                  title="Salin Kode"
                >
                  {copiedCode ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-400" />
                      <span className="text-emerald-400">Tersalin!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>Salin</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Live Variable Indicator */}
            <div className="px-3.5 py-1.5 bg-slate-900/60 border-b border-slate-800/80 flex items-center justify-between text-[11px] font-mono">
              <div className="flex items-center gap-2">
                <span className="text-slate-400">Variabel Input:</span>
                <span className={`px-2 py-0.5 rounded font-bold border ${buttonPressed ? 'bg-emerald-950 text-emerald-300 border-emerald-800' : 'bg-slate-800 text-slate-300 border-slate-700'}`}>
                  let tombolDitekan = {buttonPressed ? 'true' : 'false'};
                </span>
              </div>
              <span className={`px-2 py-0.5 rounded font-black text-[10px] border ${buttonPressed ? 'bg-emerald-400 text-slate-950 border-emerald-600' : 'bg-slate-800 text-slate-400 border-slate-700'}`}>
                {buttonPressed ? 'KONDISI: TRUE (BENAR)' : 'KONDISI: FALSE (SALAH)'}
              </span>
            </div>

            {/* Code Body */}
            <div className="p-3 font-mono text-[11px] leading-relaxed select-text space-y-1">
              <div className={`p-2 rounded transition-all duration-300 ${buttonPressed ? 'bg-emerald-950/80 border-l-4 border-emerald-400 text-emerald-100 shadow-md font-bold' : 'opacity-60 text-slate-400'}`}>
                <div className="flex items-center justify-between">
                  <span>
                    <span className="text-purple-400">{codeLang === 'js' ? 'if' : 'JIKA'}</span>
                    {' (tombolDitekan === '}<span className="text-amber-300">true</span>{') {'}
                  </span>
                  {buttonPressed && (
                    <span className="text-[10px] bg-emerald-400 text-slate-950 px-1.5 py-0.2 rounded font-black tracking-wider animate-pulse">
                      👉 DIEKSEKUSI (TRUE)
                    </span>
                  )}
                </div>
                <div className="pl-4">
                  <span className="text-sky-300">lampu</span> = <span className="text-emerald-300">"MERAH (STOP)"</span>;
                </div>
                <div className="pl-4">
                  <span className="text-yellow-300">mobil</span>.<span className="text-sky-200">remBerhenti()</span>;
                </div>
                <div className="pl-4">
                  <span className="text-yellow-300">anak</span>.<span className="text-sky-200">menyeberangAman()</span>;
                </div>
                <div>{'}'}</div>
              </div>

              {!buttonPressed && (
                <div className="text-[10px] text-slate-400 italic pl-1">
                  // Saat kondisi FALSE, baris di dalam if dilewati. Mobil terus jalan!
                </div>
              )}
            </div>

            {/* Micro Callout */}
            <div className="p-2.5 bg-slate-900 border-t border-slate-800 text-[10px] text-slate-300 flex items-center gap-2">
              <Lightbulb className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>
                <strong>Cara Komputer Berpikir:</strong> Komputer hanya memiliki 1 aturan. Jika tombol bernilai <span className="text-emerald-300 font-bold">TRUE</span>, mobil wajib direm. Tapi kalau <span className="text-rose-300 font-bold">FALSE</span>, komputer tidak melakukan apa-apa dan mobil meluncur bebas!
              </span>
            </div>
          </div>

          {/* --------------------------------------------------------- */}
          {/* SISI KIRI BAWAH: FITUR COBA SENDIRI (LAB REACT JS)        */}
          {/* --------------------------------------------------------- */}
          <div className="bg-white rounded-xl border-2 border-slate-900 p-4 pop-card shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="p-1 bg-red-400 rounded border border-slate-900 text-white">
                  <Sparkles className="w-3.5 h-3.5" />
                </span>
                <div>
                  <div className="text-[10px] font-black uppercase text-red-700 tracking-wider">
                    SISI KIRI BAWAH // LAB COBA SENDIRI
                  </div>
                  <h3 className="text-sm font-black text-slate-950 uppercase">
                    Eksplorasi Saklar & Kecepatan Mobil
                  </h3>
                </div>
              </div>

              <span className={`text-[10px] font-mono font-black px-2 py-0.5 rounded border border-slate-900 ${buttonPressed ? 'bg-red-400 text-white' : 'bg-emerald-400 text-slate-950'}`}>
                {buttonPressed ? 'MOBIL: REM' : 'MOBIL: JALAN'}
              </span>
            </div>

            <p className="text-xs text-slate-600 mb-3">
              Pijit tombol fisik penyeberang atau ganti kecepatan mobil untuk melihat reaksi kode secara langsung!
            </p>

            {/* Tombol Saklar Fisik Utama */}
            <div className="p-3 bg-slate-50 rounded-lg border-2 border-slate-900 pop-card-sm mb-3">
              <div className="text-xs font-bold text-slate-800 mb-2">
                1. Saklar Tombol Penyeberang Jalan:
              </div>
              <button
                onClick={handleToggle}
                className={`w-full py-3 px-4 text-xs font-black uppercase tracking-wider rounded-lg border-2 border-slate-950 transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  buttonPressed
                    ? 'bg-red-500 text-white shadow-inner translate-y-0.5'
                    : 'bg-amber-400 hover:bg-amber-300 text-slate-950 pop-card active:translate-y-0.5'
                }`}
              >
                <span>{buttonPressed ? '🛑 TOMBOL AKTIF (TRUE) - KLIK UNTUK RESET' : '🚸 [ TEKAN TOMBOL ZEBRA CROSS ]'}</span>
              </button>
            </div>

            {/* Pilihan Kecepatan Mobil */}
            <div className="mb-3">
              <div className="text-[11px] font-bold text-slate-700 mb-1.5">
                2. Atur Kecepatan Laju Mobil:
              </div>
              <div className="grid grid-cols-3 gap-1.5 text-xs font-black">
                <button
                  onClick={() => {
                    audio.playClick();
                    setCarSpeed(30);
                  }}
                  className={`p-2 rounded border border-slate-900 pop-card-sm cursor-pointer text-center ${carSpeed === 30 ? 'bg-sky-300 text-slate-950 ring-2 ring-sky-500' : 'bg-slate-100 hover:bg-slate-200'}`}
                >
                  🐢 30 km/jam
                </button>
                <button
                  onClick={() => {
                    audio.playClick();
                    setCarSpeed(60);
                  }}
                  className={`p-2 rounded border border-slate-900 pop-card-sm cursor-pointer text-center ${carSpeed === 60 ? 'bg-sky-300 text-slate-950 ring-2 ring-sky-500' : 'bg-slate-100 hover:bg-slate-200'}`}
                >
                  🚗 60 km/jam
                </button>
                <button
                  onClick={() => {
                    audio.playClick();
                    setCarSpeed(100);
                  }}
                  className={`p-2 rounded border border-slate-900 pop-card-sm cursor-pointer text-center ${carSpeed === 100 ? 'bg-sky-300 text-slate-950 ring-2 ring-sky-500' : 'bg-slate-100 hover:bg-slate-200'}`}
                >
                  🏎️ 100 km/jam
                </button>
              </div>
            </div>

            {/* Tombol Eksekusi Step-by-Step */}
            <button
              onClick={runSimulation}
              disabled={isSimulating}
              className={`w-full py-2.5 px-3 rounded-lg border-2 border-slate-900 font-black text-xs uppercase tracking-wider pop-card-sm flex items-center justify-center gap-2 cursor-pointer transition-all ${
                isSimulating ? 'bg-amber-300 animate-pulse text-slate-950' : 'bg-slate-900 hover:bg-slate-800 text-amber-300 active:translate-y-0.5'
              }`}
            >
              <Zap className="w-4 h-4 text-amber-400" />
              <span>{isSimulating ? '⚡ MEMPROSES EVALUASI LOGIKA...' : '⚡ TEST & JALANKAN LOGIKA KODE (STEP-BY-STEP)'}</span>
            </button>

            {/* Terminal Output */}
            <div className="mt-2.5 p-2.5 bg-slate-950 rounded-lg border border-slate-900 text-[10px] font-mono text-emerald-400">
              <div className="flex items-center gap-1.5 text-slate-400 border-b border-slate-800 pb-1 mb-1 font-bold">
                <Terminal className="w-3 h-3 text-emerald-400" />
                <span>TERMINAL HASIL EKSEKUSI REACT JS:</span>
              </div>
              <div className="text-slate-300">
                &gt; Input tombolDitekan: <span className={buttonPressed ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>{buttonPressed ? 'TRUE (DITEKAN)' : 'FALSE (BELUM DITEKAN)'}</span>
              </div>
              <div className="text-slate-300">
                &gt; Lampu Lalu Lintas: <span className={buttonPressed ? 'text-red-400 font-bold' : 'text-emerald-400 font-bold'}>{buttonPressed ? 'MERAH (STOP)' : 'HIJAU (JALAN)'}</span>
              </div>
              <div className={buttonPressed ? 'text-emerald-300 font-bold' : 'text-amber-300'}>
                &gt; Respon Mobil: {buttonPressed ? 'Rem aktif! Mobil berhenti tertib SEBELUM garis henti putih (Stop Line).' : `Melaju kencang pada ${carSpeed} km/jam.`}
              </div>
              <div className="text-slate-300">
                &gt; Pejalan Kaki: {buttonPressed ? 'Siti menyeberang aman di atas zebra cross dengan senyum ceria! 😊' : 'Menunggu aman di tepi trotoar jalan. 🚶'}
              </div>
            </div>
          </div>
        </div>

        {/* Reset */}
        <div className="mt-3 pt-2 border-t border-slate-200 flex justify-end">
          <button
            onClick={() => {
              audio.playClick();
              setButtonPressed(false);
              setKidStep(0);
              setCarSpeed(60);
            }}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-slate-950 px-3 py-1.5 rounded border border-slate-900 bg-white pop-card-sm hover:bg-slate-50 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Bab 1</span>
          </button>
        </div>
      </div>

      {/* ========================================================= */}
      {/* SISI KANAN: PANGGUNG VISUAL JALAN RAYA & MISI DETEKTIF     */}
      {/* ========================================================= */}
      <div className="relative p-5 lg:p-7 flex flex-col justify-between bg-white text-slate-900 paper-bg overflow-y-auto">
        <div>
          {/* Header Panggung Kanan */}
          <div className="flex items-center justify-between text-xs font-bold mb-1">
            <span className="bg-emerald-600 text-white px-2.5 py-0.5 rounded pop-card-sm uppercase">
              SISI KANAN // PANGGUNG VISUAL
            </span>
            <span className="font-mono text-slate-700 font-bold">
              100% GAMBAR BERGERAK
            </span>
          </div>
          <h2 className="text-xl lg:text-2xl font-black text-slate-950 uppercase tracking-tight mb-3">
            Simulasi Lampu & Jalan Raya Bergerak
          </h2>

          {/* Canvas Jalan Raya */}
          <div className="relative w-full h-64 lg:h-72 bg-slate-800 rounded-xl border-2 border-slate-950 pop-card overflow-hidden mb-3.5 shadow-inner">
            {/* Langit & Tiang Lampu Lalu Lintas */}
            <div className="absolute top-0 left-0 right-0 h-16 bg-slate-300 border-b-2 border-slate-900 flex items-center justify-between px-4 z-20">
              <div className="relative flex items-center gap-2">
                <div className="w-7 h-14 bg-slate-950 rounded-md p-1 flex flex-col justify-between items-center border border-slate-700 shadow-md">
                  <div className={`w-3.5 h-3.5 rounded-full transition-all duration-300 ${buttonPressed ? 'bg-red-500 shadow-[0_0_12px_#ef4444]' : 'bg-red-950/40'}`} />
                  <div className="w-3.5 h-3.5 rounded-full bg-amber-950/30" />
                  <div className={`w-3.5 h-3.5 rounded-full transition-all duration-300 ${!buttonPressed ? 'bg-emerald-500 shadow-[0_0_12px_#10b981]' : 'bg-emerald-950/40'}`} />
                </div>
                <div className="text-[10px] font-bold text-slate-800 bg-white px-2 py-0.5 rounded border border-slate-900 pop-card-sm flex flex-col">
                  <span>LAMPU MOBIL: {buttonPressed ? '🛑 MERAH' : '🟢 HIJAU'}</span>
                  <span className="text-[8px] text-slate-600 font-mono">
                    PENYEBERANG: {buttonPressed ? '🚶‍♂️ JALAN (HIJAU)' : '🧍‍♂️ TUNGGU (MERAH)'}
                  </span>
                </div>
              </div>

              <div className="text-xs bg-white text-slate-900 font-bold px-3 py-1.5 rounded-lg border-2 border-slate-900 pop-card-sm max-w-[210px]">
                {buttonPressed ? (
                  <span className="text-emerald-700 font-bold">“Bagus! Mobil tertib berhenti SEBELUM garis putih! ✨”</span>
                ) : (
                  <span className="text-slate-700">“Mobil meluncur, tekan tombol zebra cross yuk! ⚠️”</span>
                )}
              </div>
            </div>

            {/* Aspal Jalan Raya */}
            <div className="absolute top-16 bottom-12 left-0 right-0 bg-slate-900 flex flex-col justify-center overflow-hidden">
              {/* Garis Marka Kuning Tengah Jalan Putus-Putus */}
              <div className="w-full border-t-2 border-dashed border-amber-400 opacity-60 z-0" />

              {/* BEKAS REM BAN (SKID MARKS) & ASAP SAAT MENGEREM */}
              {buttonPressed && (
                <>
                  <div className="absolute left-[6%] top-[45%] w-[12%] h-1 bg-black/80 rounded-full blur-[0.5px] z-10" />
                  <div className="absolute left-[6%] top-[57%] w-[12%] h-1 bg-black/80 rounded-full blur-[0.5px] z-10" />
                  <div className="absolute left-[16%] top-[38%] text-[8px] font-mono font-bold text-amber-300 bg-slate-950/90 px-1.5 py-0.5 rounded border border-amber-400 z-30 animate-pulse">
                    🛑 Rem Aktif! Berhenti Sebelum Garis Putih
                  </div>
                </>
              )}

              {/* 1. GARIS HENTI PUTIH TEBAL (STOP LINE) DI SEBELUM ZEBRA CROSS */}
              <div className="absolute left-[48%] top-0 bottom-0 w-3 bg-white border-x border-slate-300 z-10 shadow-[0_0_8px_rgba(255,255,255,0.7)] flex flex-col justify-between items-center py-1">
                <div className="w-1.5 h-1.5 bg-red-500 rounded-full" />
                <div className="w-1.5 h-1.5 bg-red-500 rounded-full" />
              </div>

              {/* Label Marka Aspal "STOP LINE" */}
              <div className="absolute left-[40%] top-2 text-[8px] font-mono font-black text-slate-300 uppercase tracking-widest pointer-events-none select-none z-10 bg-slate-950/40 px-1 rounded">
                STOP LINE ➔
              </div>

              {/* 2. ZEBRA CROSS BELANG PUTIH (LETAK DI SEBELAH KANAN GARIS HENTI) */}
              <div className="absolute left-[56%] top-0 bottom-0 w-28 flex flex-col justify-around py-1.5 z-0">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="h-2 bg-white rounded-sm shadow-md opacity-95" />
                ))}
              </div>

              {/* Mobil Merah Bergerak */}
              <div
                className="absolute top-1/2 -translate-y-1/2 transition-transform duration-75 z-20"
                style={{ left: `${carX}%` }}
              >
                {/* Asap Ban Berdecit saat berhenti */}
                {buttonPressed && (
                  <div className="absolute -left-6 bottom-1 flex gap-1 animate-pulse">
                    <div className="w-4 h-4 rounded-full bg-slate-200/90 animate-ping" />
                    <div className="w-3 h-3 rounded-full bg-slate-300/90" />
                  </div>
                )}

                <div className="relative w-24 h-12 bg-red-600 rounded-t-xl rounded-b-md border-2 border-slate-950 pop-card-sm flex items-center justify-center shadow-lg">
                  <div className="absolute top-1 left-4 right-4 h-4 bg-sky-200 rounded-t-lg border border-slate-900 flex items-center justify-around">
                    <div className="w-2.5 h-2.5 rounded-full bg-slate-800" />
                  </div>
                  <div className="absolute right-0 top-6 w-2 h-3 bg-amber-300 rounded-r shadow-[0_0_6px_#fde047]" />
                  <div className="absolute -bottom-2.5 left-3 w-5 h-5 rounded-full bg-slate-950 border-2 border-white flex items-center justify-center">
                    <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-spin-fast" />
                  </div>
                  <div className="absolute -bottom-2.5 right-3 w-5 h-5 rounded-full bg-slate-950 border-2 border-white flex items-center justify-center">
                    <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-spin-fast" />
                  </div>
                </div>
              </div>

              {/* Anak Menyeberang di Atas Garis Zebra Cross */}
              <div
                className="absolute left-[70%] z-30 transition-all duration-300"
                style={{
                  top: buttonPressed ? `${12 + (kidStep / 100) * 58}%` : '6%'
                }}
              >
                <div className="relative flex flex-col items-center">
                  {/* Balon Kata Siti */}
                  {buttonPressed && (
                    <div className="absolute -top-6 whitespace-nowrap bg-white text-slate-950 text-[9px] font-black px-1.5 py-0.5 rounded border border-slate-900 pop-card-sm shadow-sm animate-bounce-gentle">
                      {kidStep >= 90 ? '🎉 Sampai seberang!' : '🚶‍♀️ Menyeberang aman!'}
                    </div>
                  )}
                  <div className="w-6 h-6 rounded-full bg-amber-200 border-2 border-slate-950 flex items-center justify-center text-[11px] shadow-sm">
                    {buttonPressed ? '😊' : '🚶'}
                  </div>
                  <div className="w-5 h-5 bg-blue-500 rounded-t-sm border border-slate-950 relative">
                    <div className="absolute -left-1 top-1 w-2 h-3 bg-amber-700 rounded-sm" />
                    <div className="absolute -right-1 top-1.5 w-1.5 h-3 bg-rose-400 rounded-sm" />
                  </div>
                  <div className="flex gap-1 -mt-0.5">
                    <div className="w-1.5 h-3.5 bg-slate-900" />
                    <div className="w-1.5 h-3.5 bg-slate-900" />
                  </div>
                </div>
              </div>
            </div>

            {/* Trotoar Bawah */}
            <div className="absolute bottom-0 left-0 right-0 h-12 bg-slate-300 border-t-2 border-slate-900 flex items-center justify-between px-4 text-[11px] font-bold text-slate-800 z-20">
              <span className="flex items-center gap-1.5">
                <span>TROTOAR SEBERANG JALAN</span>
                {buttonPressed && kidStep >= 90 && (
                  <span className="bg-emerald-400 text-slate-950 px-1.5 py-0.2 rounded text-[10px] font-black animate-pulse">
                    ✅ SITI SELAMAT!
                  </span>
                )}
              </span>
              <span className="font-mono bg-white px-2 py-0.5 rounded border border-slate-900 shadow-sm">
                SPEEDOMETER: {buttonPressed ? '0 km/jam (STOP)' : `${carSpeed} km/jam`}
              </span>
            </div>
          </div>

          {/* MISI & SOAL DETEKTIF CILIK */}
          <KidMissionBox
            chapterId={1}
            missionTitle="Bantu Siti Menyeberang Jalan Raya Tanpa Tertabrak!"
            analogy="Sama seperti membawa payung: JIKA hujan turun (TRUE), kamu buka payung. Tapi kalau tidak hujan (FALSE), payung tetap disimpan di tas."
            steps={[
              'Lihat sisi kiri atas: Perhatikan koding IF Tunggal yang hanya aktif saat tombol bernilai TRUE!',
              'Coba sisi kiri bawah: Tekan tombol kuning penyeberang atau ganti kecepatan mobil!',
              'Perhatikan sisi kanan: Lampu berubah merah, mobil tertib mengerem SEBELUM garis putih henti, dan Siti menyeberang aman di atas zebra cross!'
            ]}
            question="Jika tombol zebra cross TIDAK DITEKAN (nilainya FALSE), apa yang akan dilakukan mobil?"
            options={[
              {
                text: 'Mobil otomatis mengerem sendiri tanpa sebab',
                correct: false,
                explanation: 'Salah ya! Komputer tidak bisa membaca pikiran pejalan kaki kalau tombol tidak ditekan.'
              },
              {
                text: 'Mobil terus melaju kencang karena lampu tetap hijau',
                correct: true,
                explanation: 'HEBAT SEKALI! ⭐ Karena tombolDitekan bernilai FALSE, kode di dalam IF dilewati dan mobil tetap berjalan seperti biasa!'
              },
              {
                text: 'Mobilnya tiba-tiba terbang ke luar angkasa',
                correct: false,
                explanation: 'Hihi bukan dong! Mobilnya mobil biasa di jalan raya ya.'
              }
            ]}
            hasWonStar={hasWonStar}
            onEarnStar={onEarnStar}
          />
        </div>

        {/* Reset */}
        <div className="mt-3 pt-2 border-t border-slate-200 flex justify-end">
          <button
            onClick={() => {
              audio.playClick();
              setButtonPressed(false);
              setKidStep(0);
              setCarSpeed(60);
            }}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-slate-950 px-3 py-1.5 rounded border border-slate-900 bg-white pop-card-sm hover:bg-slate-50 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Simulasi</span>
          </button>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 5. SPREAD 2: IF - ELSE (VERIFIKASI MAGANG: RAPOR, JURUSAN, IJAZAH)
// ==========================================
function HrdRecruitmentSpread({
  hasWonStar,
  onEarnStar,
  onOpenPBLModal
}: {
  hasWonStar: boolean;
  onEarnStar: () => void;
  onOpenPBLModal: () => void;
}) {
  const [raporScore, setRaporScore] = useState<number>(85);
  const [isMajorMatch, setIsMajorMatch] = useState<boolean>(true);
  const [hasDiploma, setHasDiploma] = useState<boolean>(true);
  const [isVerified, setIsVerified] = useState<boolean>(false);
  const [codeLang, setCodeLang] = useState<'js' | 'indo'>('js');
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [minScore, setMinScore] = useState<number>(80);
  const [showCustomRules, setShowCustomRules] = useState<boolean>(false);

  // Evaluasi Logika IF-ELSE:
  const isAccepted = useMemo(() => {
    return raporScore >= minScore && isMajorMatch && hasDiploma;
  }, [raporScore, isMajorMatch, hasDiploma, minScore]);

  const handleVerify = () => {
    audio.playClick();
    setIsVerified(true);
    if (isAccepted) {
      audio.playSuccess();
    } else {
      audio.playBuzzer();
    }
  };

  const handleCopyCode = () => {
    audio.playClick();
    const codeString = `// Logika Percabangan IF-ELSE Seleksi Magang HRD
let nilaiRapor = ${raporScore};
let jurusanCocok = ${isMajorMatch};
let ijazahAsli = ${hasDiploma};

if (nilaiRapor >= ${minScore} && jurusanCocok === true && ijazahAsli === true) {
  status = "LOLOS SELEKSI";
  stempel("HIJAU DITERIMA");
  taburKonfeti();
} else {
  status = "PERBAIKI BERKAS";
  stempel("ORANYE BELUM LENGKAP");
  tampilkanKekurangan();
}`;
    navigator.clipboard?.writeText(codeString);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const runSimulation = () => {
    audio.playClick();
    setIsSimulating(true);
    setTimeout(() => {
      handleVerify();
      setIsSimulating(false);
    }, 700);
  };

  const handleRandomScore = () => {
    audio.playClick();
    const scores = [65, 72, 78, 82, 86, 92, 95];
    const picked = scores[Math.floor(Math.random() * scores.length)];
    setRaporScore(picked);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 h-full w-full">
      {/* ========================================================= */}
      {/* SISI KIRI: ATAS = CONTOH KODING, BAWAH = LAB COBA SENDIRI */}
      {/* ========================================================= */}
      <div className="relative p-5 lg:p-7 flex flex-col justify-between border-b lg:border-b-0 lg:border-r-2 border-slate-900 bg-slate-100 overflow-y-auto">
        <div>
          {/* Header */}
          <div className="flex items-center justify-between text-xs font-bold mb-1">
            <span className="bg-emerald-600 text-white px-2.5 py-0.5 rounded pop-card-sm uppercase">
              BAB 02 // DUA PERCABANGAN PASTI (IF - ELSE)
            </span>
            <span className="font-mono text-slate-700 font-bold bg-white px-2 py-0.5 rounded border border-slate-900">
              KODE & LAB MANDIRI
            </span>
          </div>
          <h2 className="text-xl lg:text-2xl font-black text-slate-950 uppercase tracking-tight mb-3">
            Logika IF-ELSE & Playground
          </h2>

          {/* ALUR PROBLEM-BASED LEARNING (PBL) */}
          <PBLStepBar chapterNum={2} onOpenPBLModal={onOpenPBLModal} />

          {/* --------------------------------------------------------- */}
          {/* SISI KIRI ATAS: CONTOH KODING INTERAKTIF                   */}
          {/* --------------------------------------------------------- */}
          <div className="bg-slate-950 text-slate-100 rounded-xl border-2 border-slate-900 pop-card overflow-hidden mb-4 shadow-lg">
            {/* Window Bar */}
            <div className="bg-slate-900 px-3 py-2 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                </div>
                <div className="flex items-center gap-1.5 ml-2 font-mono text-xs font-bold text-slate-300">
                  <Code2 className="w-3.5 h-3.5 text-sky-400" />
                  <span>seleksi_magang.js</span>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <div className="flex bg-slate-800 rounded p-0.5 border border-slate-700 text-[10px] font-bold">
                  <button
                    onClick={() => setCodeLang('js')}
                    className={`px-1.5 py-0.5 rounded cursor-pointer ${codeLang === 'js' ? 'bg-sky-500 text-slate-950 font-black' : 'text-slate-400 hover:text-white'}`}
                  >
                    JavaScript
                  </button>
                  <button
                    onClick={() => setCodeLang('indo')}
                    className={`px-1.5 py-0.5 rounded cursor-pointer ${codeLang === 'indo' ? 'bg-amber-400 text-slate-950 font-black' : 'text-slate-400 hover:text-white'}`}
                  >
                    Bahasa Logika
                  </button>
                </div>
                <button
                  onClick={handleCopyCode}
                  className="flex items-center gap-1 px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 text-[10px] font-bold cursor-pointer"
                  title="Salin Kode"
                >
                  {copiedCode ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-400" />
                      <span className="text-emerald-400">Tersalin!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>Salin</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Live Variable Indicator */}
            <div className="px-3.5 py-1.5 bg-slate-900/60 border-b border-slate-800/80 flex items-center justify-between text-[11px] font-mono">
              <div className="flex items-center gap-1.5 text-slate-300">
                <span>Rapor:</span>
                <span className={`px-1.5 py-0.2 rounded font-bold ${raporScore >= minScore ? 'text-emerald-300' : 'text-rose-300'}`}>{raporScore}</span>
                <span>· Jurusan:</span>
                <span className={`px-1.5 py-0.2 rounded font-bold ${isMajorMatch ? 'text-emerald-300' : 'text-rose-300'}`}>{isMajorMatch ? '✓' : '✕'}</span>
                <span>· Ijazah:</span>
                <span className={`px-1.5 py-0.2 rounded font-bold ${hasDiploma ? 'text-emerald-300' : 'text-rose-300'}`}>{hasDiploma ? '✓' : '✕'}</span>
              </div>
              <span className={`px-2 py-0.5 rounded font-black text-[10px] border ${isAccepted ? 'bg-emerald-400 text-slate-950 border-emerald-600' : 'bg-rose-400 text-white border-rose-600'}`}>
                {isAccepted ? 'CABANG: IF' : 'CABANG: ELSE'}
              </span>
            </div>

            {/* Code Body */}
            <div className="p-3 font-mono text-[11px] leading-relaxed select-text space-y-1">
              {/* CABANG IF (LOLOS) */}
              <div className={`p-1.5 rounded transition-all duration-300 ${isAccepted ? 'bg-emerald-950/80 border-l-4 border-emerald-400 text-emerald-100 shadow-md font-bold' : 'opacity-60 text-slate-400'}`}>
                <div className="flex items-center justify-between">
                  <span>
                    <span className="text-purple-400">{codeLang === 'js' ? 'if' : 'JIKA'}</span>
                    {' (rapor >= '}<span className="text-amber-300">{minScore}</span>{' && jurusan && ijazah) {'}
                  </span>
                  {isAccepted && (
                    <span className="text-[10px] bg-emerald-400 text-slate-950 px-1.5 py-0.2 rounded font-black tracking-wider animate-pulse">
                      👉 CABANG IF (LOLOS)
                    </span>
                  )}
                </div>
                <div className="pl-4">
                  <span className="text-sky-300">status</span> = <span className="text-emerald-300">"LOLOS SELEKSI MAGANG"</span>;
                </div>
                <div className="pl-4">
                  <span className="text-yellow-300">stempel</span>(<span className="text-emerald-300">"HIJAU DITERIMA"</span>);
                </div>
                <div>{'}'}</div>
              </div>

              {/* CABANG ELSE (PERBAIKI BERKAS) */}
              <div className={`p-1.5 rounded transition-all duration-300 ${!isAccepted ? 'bg-amber-950/80 border-l-4 border-amber-400 text-amber-100 shadow-md font-bold' : 'opacity-60 text-slate-400'}`}>
                <div className="flex items-center justify-between">
                  <span>
                    <span className="text-purple-400">{codeLang === 'js' ? '} else {' : '} LAINNYA {'}</span>
                  </span>
                  {!isAccepted && (
                    <span className="text-[10px] bg-amber-400 text-slate-950 px-1.5 py-0.2 rounded font-black tracking-wider animate-pulse">
                      👉 CABANG ELSE (PERBAIKI BERKAS)
                    </span>
                  )}
                </div>
                <div className="pl-4">
                  <span className="text-sky-300">status</span> = <span className="text-amber-300">"PERBAIKI PORTOFOLIO"</span>;
                </div>
                <div className="pl-4">
                  <span className="text-yellow-300">stempel</span>(<span className="text-amber-300">"ORANYE BELUM LENGKAP"</span>);
                </div>
                <div>{'}'}</div>
              </div>
            </div>

            {/* Micro Callout */}
            <div className="p-2.5 bg-slate-900 border-t border-slate-800 text-[10px] text-slate-300 flex items-center gap-2">
              <Lightbulb className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>
                <strong>Cara Komputer Berpikir:</strong> Pada IF-ELSE, komputer memiliki 2 jalur tegas. Jika semua syarat lengkap, komputer masuk ke jalur <strong className="text-emerald-300">IF</strong>. Jika ada 1 syarat saja yang belum lengkap, otomatis masuk ke jalur <strong className="text-amber-300">ELSE</strong>!
              </span>
            </div>
          </div>

          {/* --------------------------------------------------------- */}
          {/* SISI KIRI BAWAH: FITUR COBA SENDIRI (LAB REACT JS)        */}
          {/* --------------------------------------------------------- */}
          <div className="bg-white rounded-xl border-2 border-slate-900 p-4 pop-card shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="p-1 bg-emerald-400 rounded border border-slate-900 text-slate-950">
                  <Sparkles className="w-3.5 h-3.5" />
                </span>
                <div>
                  <div className="text-[10px] font-black uppercase text-emerald-700 tracking-wider">
                    SISI KIRI BAWAH // LAB COBA SENDIRI
                  </div>
                  <h3 className="text-sm font-black text-slate-950 uppercase">
                    Eksplorasi 3 Berkas & Keputusan HRD
                  </h3>
                </div>
              </div>

              <span className={`text-[10px] font-mono font-black px-2 py-0.5 rounded border border-slate-900 ${isAccepted ? 'bg-emerald-400 text-slate-950' : 'bg-amber-400 text-slate-950'}`}>
                {isAccepted ? 'HASIL: LOLOS' : 'HASIL: REVISI'}
              </span>
            </div>

            <p className="text-xs text-slate-600 mb-3">
              Ubah skor nilai rapor dan saklar berkas atau coba 4 skenario cepat pelamar di bawah ini:
            </p>

            {/* 1. Kontrol Nilai Rapor */}
            <div className="p-3 bg-slate-50 rounded-lg border-2 border-slate-900 pop-card-sm mb-2.5">
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-xs font-bold text-slate-800">
                  1. Nilai Rata-Rata Rapor Siswa:
                </span>
                <span className="font-mono text-xs font-black bg-slate-950 text-amber-400 px-2 py-0.5 rounded">
                  {raporScore} (Min: {minScore})
                </span>
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="number"
                  min={50}
                  max={100}
                  value={raporScore}
                  onChange={(e) => {
                    setRaporScore(Number(e.target.value));
                    setIsVerified(false);
                  }}
                  className="w-20 px-2 py-1.5 bg-white border-2 border-slate-900 rounded font-mono text-sm font-black text-center pop-card-sm"
                />
                <div className="flex items-center gap-1 flex-1">
                  <button
                    onClick={() => {
                      audio.playClick();
                      setRaporScore((p) => Math.max(50, p - 5));
                      setIsVerified(false);
                    }}
                    className="px-2 py-1 bg-slate-200 hover:bg-slate-300 rounded border border-slate-900 text-xs font-bold pop-card-sm cursor-pointer"
                  >
                    -5
                  </button>
                  <button
                    onClick={() => {
                      audio.playClick();
                      setRaporScore((p) => Math.min(100, p + 5));
                      setIsVerified(false);
                    }}
                    className="px-2 py-1 bg-slate-200 hover:bg-slate-300 rounded border border-slate-900 text-xs font-bold pop-card-sm cursor-pointer"
                  >
                    +5
                  </button>
                  <button
                    onClick={handleRandomScore}
                    className="flex-1 py-1 bg-amber-300 hover:bg-amber-400 text-slate-950 rounded border border-slate-900 text-xs font-black pop-card-sm flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <span>🎲 Acak Nilai</span>
                  </button>
                </div>
              </div>
            </div>

            {/* 2. Saklar Jurusan & Ijazah */}
            <div className="grid grid-cols-2 gap-2 mb-3">
              <button
                onClick={() => {
                  audio.playClick();
                  setIsMajorMatch(!isMajorMatch);
                  setIsVerified(false);
                }}
                className={`p-2 rounded border border-slate-900 text-left pop-card-sm transition-all cursor-pointer ${
                  isMajorMatch ? 'bg-emerald-100 text-emerald-950 font-bold' : 'bg-rose-100 text-rose-950 font-bold'
                }`}
              >
                <div className="text-[10px] text-slate-600 font-bold">2. Jurusan Sekolah:</div>
                <div className="text-xs">{isMajorMatch ? '✅ RPL / Desain' : '❌ Kuliner (Beda)'}</div>
              </button>

              <button
                onClick={() => {
                  audio.playClick();
                  setHasDiploma(!hasDiploma);
                  setIsVerified(false);
                }}
                className={`p-2 rounded border border-slate-900 text-left pop-card-sm transition-all cursor-pointer ${
                  hasDiploma ? 'bg-emerald-100 text-emerald-950 font-bold' : 'bg-rose-100 text-rose-950 font-bold'
                }`}
              >
                <div className="text-[10px] text-slate-600 font-bold">3. Ijazah / Sertifikat:</div>
                <div className="text-xs">{hasDiploma ? '✅ Ijazah Asli' : '❌ Belum Ada'}</div>
              </button>
            </div>

            {/* 4 Pilihan Skenario Uji Cepat */}
            <div className="mb-3">
              <div className="text-[11px] font-bold text-slate-700 mb-1.5">
                3. Atau Pilih 4 Skenario Cepat Pelamar:
              </div>
              <div className="grid grid-cols-2 gap-1.5 text-xs font-black">
                <button
                  onClick={() => {
                    audio.playClick();
                    setRaporScore(90);
                    setIsMajorMatch(true);
                    setHasDiploma(true);
                    setIsVerified(false);
                  }}
                  className="p-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-950 rounded border border-slate-900 pop-card-sm cursor-pointer text-left"
                >
                  🌟 Pelamar Juara (90, RPL, Ijazah)
                </button>
                <button
                  onClick={() => {
                    audio.playClick();
                    setRaporScore(72);
                    setIsMajorMatch(true);
                    setHasDiploma(true);
                    setIsVerified(false);
                  }}
                  className="p-1.5 bg-amber-100 hover:bg-amber-200 text-amber-950 rounded border border-slate-900 pop-card-sm cursor-pointer text-left"
                >
                  ⚠️ Rapor Kurang (72, RPL, Ijazah)
                </button>
                <button
                  onClick={() => {
                    audio.playClick();
                    setRaporScore(88);
                    setIsMajorMatch(false);
                    setHasDiploma(true);
                    setIsVerified(false);
                  }}
                  className="p-1.5 bg-amber-100 hover:bg-amber-200 text-amber-950 rounded border border-slate-900 pop-card-sm cursor-pointer text-left"
                >
                  ❌ Jurusan Beda (88, Kuliner)
                </button>
                <button
                  onClick={() => {
                    audio.playClick();
                    setRaporScore(85);
                    setIsMajorMatch(true);
                    setHasDiploma(false);
                    setIsVerified(false);
                  }}
                  className="p-1.5 bg-amber-100 hover:bg-amber-200 text-amber-950 rounded border border-slate-900 pop-card-sm cursor-pointer text-left"
                >
                  📄 Tanpa Ijazah (85, RPL, ✕)
                </button>
              </div>
            </div>

            {/* Tombol Eksekusi Step-by-Step */}
            <button
              onClick={runSimulation}
              disabled={isSimulating}
              className={`w-full py-2.5 px-3 rounded-lg border-2 border-slate-900 font-black text-xs uppercase tracking-wider pop-card-sm flex items-center justify-center gap-2 cursor-pointer transition-all ${
                isSimulating ? 'bg-amber-300 animate-pulse text-slate-950' : 'bg-slate-900 hover:bg-slate-800 text-amber-300 active:translate-y-0.5'
              }`}
            >
              <Zap className="w-4 h-4 text-amber-400" />
              <span>{isSimulating ? '⚡ MENGEVALUASI 3 BERKAS...' : '⚡ TEST & JALANKAN VERIFIKASI (STEP-BY-STEP)'}</span>
            </button>

            {/* Terminal Output */}
            <div className="mt-2.5 p-2.5 bg-slate-950 rounded-lg border border-slate-900 text-[10px] font-mono text-emerald-400">
              <div className="flex items-center gap-1.5 text-slate-400 border-b border-slate-800 pb-1 mb-1 font-bold">
                <Terminal className="w-3 h-3 text-emerald-400" />
                <span>TERMINAL HASIL EKSEKUSI REACT JS:</span>
              </div>
              <div className="text-slate-300">
                &gt; Evaluasi Rapor: {raporScore} &gt;= {minScore} ? <span className={raporScore >= minScore ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>{raporScore >= minScore ? 'LOLOS (TRUE)' : 'KURANG (FALSE)'}</span>
              </div>
              <div className="text-slate-300">
                &gt; Evaluasi Jurusan: <span className={isMajorMatch ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>{isMajorMatch ? 'SESUAI RPL (TRUE)' : 'TIDAK SESUAI (FALSE)'}</span>
              </div>
              <div className="text-slate-300">
                &gt; Evaluasi Ijazah: <span className={hasDiploma ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>{hasDiploma ? 'ADA ASLI (TRUE)' : 'BELUM ADA (FALSE)'}</span>
              </div>
              <div className={isAccepted ? 'text-emerald-300 font-bold' : 'text-amber-300 font-bold'}>
                &gt; KEPUTUSAN AKHIR: {isAccepted ? 'MEMASUKI JALUR IF -> STEMPEL LOLOS SELEKSI! 🎉' : 'MEMASUKI JALUR ELSE -> STEMPEL PERBAIKI PORTOFOLIO! ⚠️'}
              </div>
            </div>

            {/* Kustomisasi Batas Minimal Nilai Rapor */}
            <div className="mt-3 pt-2 border-t border-slate-200">
              <button
                onClick={() => {
                  audio.playClick();
                  setShowCustomRules(!showCustomRules);
                }}
                className="w-full flex items-center justify-between text-xs font-bold text-slate-700 p-1.5 rounded bg-slate-50 border border-slate-300 cursor-pointer"
              >
                <span>🛠️ Kustomisasi Batas Nilai Rapor Minimal (Default: 80)</span>
                <span className="text-[10px] bg-slate-200 px-1.5 rounded">{showCustomRules ? '▲' : '▼'}</span>
              </button>

              {showCustomRules && (
                <div className="mt-2 p-2 bg-amber-50 rounded border border-amber-300 text-xs flex items-center justify-between">
                  <span>Ubah Batas Kelulusan:</span>
                  <div className="flex gap-1">
                    {[75, 80, 85].map((val) => (
                      <button
                        key={val}
                        onClick={() => {
                          audio.playClick();
                          setMinScore(val);
                        }}
                        className={`px-2 py-0.5 rounded border border-slate-900 text-xs font-bold ${minScore === val ? 'bg-amber-400 text-slate-950' : 'bg-white'}`}
                      >
                        {val}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Reset */}
        <div className="mt-3 pt-2 border-t border-slate-200 flex justify-end">
          <button
            onClick={() => {
              audio.playClick();
              setRaporScore(85);
              setIsMajorMatch(true);
              setHasDiploma(true);
              setMinScore(80);
              setIsVerified(false);
            }}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-slate-950 px-3 py-1.5 rounded border border-slate-900 bg-white pop-card-sm hover:bg-slate-50 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Bab 2</span>
          </button>
        </div>
      </div>

      {/* ========================================================= */}
      {/* SISI KANAN: PANGGUNG VISUAL MEJA HRD & MISI DETEKTIF      */}
      {/* ========================================================= */}
      <div className="relative p-5 lg:p-7 flex flex-col justify-between bg-white text-slate-900 paper-bg overflow-y-auto">
        <div>
          {/* Header Panggung Kanan */}
          <div className="flex items-center justify-between text-xs font-bold mb-1">
            <span className="bg-emerald-600 text-white px-2.5 py-0.5 rounded pop-card-sm uppercase">
              SISI KANAN // PANGGUNG VISUAL
            </span>
            <span className="font-mono text-slate-700 font-bold">
              100% GAMBAR BERGERAK
            </span>
          </div>
          <h2 className="text-xl lg:text-2xl font-black text-slate-950 uppercase tracking-tight mb-3">
            Verifikasi 3 Berkas & Stempel Slam
          </h2>

          {/* Meja Kerja HRD dengan 3 Dokumen Fisik Bergambar */}
          <div className="relative w-full p-4 bg-amber-50 rounded-xl border-2 border-slate-950 pop-card mb-3.5">
            <div className="flex items-center justify-between border-b-2 border-slate-900 pb-2 mb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 bg-sky-200 border-2 border-slate-950 rounded-md flex items-center justify-center text-lg shadow-inner">
                  👨‍🎓
                </div>
                <div>
                  <div className="text-xs font-black text-slate-950">BUDI PRATAMA (16 TAHUN)</div>
                  <div className="text-[10px] text-slate-600 font-bold">Kandidat Magang: Junior Game Developer</div>
                </div>
              </div>
              <span className="text-[9px] font-mono font-bold bg-white px-2 py-0.5 rounded border border-slate-950">
                BERKAS #KOMPAS-2026
              </span>
            </div>

            {/* 3 KARTU DOKUMEN VISUAL DI ATAS MEJA */}
            <div className="space-y-2 text-xs">
              {/* Dokumen 1: Buku Rapor Siswa */}
              <div className={`p-2.5 rounded-lg border-2 transition-all flex items-center justify-between ${
                raporScore >= minScore ? 'bg-emerald-50 border-emerald-600' : 'bg-rose-50 border-rose-400'
              }`}>
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded bg-white border border-slate-900 flex items-center justify-center text-base shadow-sm">
                    📚
                  </div>
                  <div>
                    <div className="font-black text-slate-950 flex items-center gap-1.5">
                      <span>1. Rata-Rata Nilai Rapor</span>
                      <span className="text-[10px] text-slate-500 font-mono font-normal">(Batas: {minScore})</span>
                    </div>
                    <div className="text-[11px] text-slate-600 font-medium">
                      Matematika: 85 · Komputer: 90 · Rata-rata:{' '}
                      <strong className={raporScore >= minScore ? 'text-emerald-700 font-black' : 'text-rose-700 font-black'}>
                        {raporScore}
                      </strong>
                    </div>
                  </div>
                </div>
                <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                  raporScore >= minScore ? 'bg-emerald-200 text-emerald-950 border-emerald-500' : 'bg-rose-200 text-rose-950 border-rose-500'
                }`}>
                  {raporScore >= minScore ? '✅ LOLOS' : '❌ KURANG'}
                </span>
              </div>

              {/* Dokumen 2: Kartu Jurusan Kejuruan */}
              <div className={`p-2.5 rounded-lg border-2 transition-all flex items-center justify-between ${
                isMajorMatch ? 'bg-emerald-50 border-emerald-600' : 'bg-rose-50 border-rose-400'
              }`}>
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded bg-white border border-slate-900 flex items-center justify-center text-base shadow-sm">
                    💻
                  </div>
                  <div>
                    <div className="font-black text-slate-950">2. Kesesuaian Jurusan Sekolah</div>
                    <div className="text-[11px] text-slate-600 font-medium">
                      {isMajorMatch ? 'Jurusan RPL / Desain Grafis (Cocok dengan Magang)' : 'Jurusan Kuliner (Belum Cocok untuk Game Dev)'}
                    </div>
                  </div>
                </div>
                <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                  isMajorMatch ? 'bg-emerald-200 text-emerald-950 border-emerald-500' : 'bg-rose-200 text-rose-950 border-rose-500'
                }`}>
                  {isMajorMatch ? '✅ SESUAI' : '❌ TIDAK'}
                </span>
              </div>

              {/* Dokumen 3: Lembar Ijazah / Sertifikat Resmi */}
              <div className={`p-2.5 rounded-lg border-2 transition-all flex items-center justify-between ${
                hasDiploma ? 'bg-emerald-50 border-emerald-600' : 'bg-rose-50 border-rose-400'
              }`}>
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded bg-white border border-slate-900 flex items-center justify-center text-base shadow-sm">
                    📜
                  </div>
                  <div>
                    <div className="font-black text-slate-950">3. Ijazah / Sertifikat Asli</div>
                    <div className="text-[11px] text-slate-600 font-medium">
                      {hasDiploma ? 'Ijazah & Sertifikasi Resmi dengan Stempel Emas' : 'Belum Melampirkan Ijazah Asli'}
                    </div>
                  </div>
                </div>
                <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold border ${
                  hasDiploma ? 'bg-emerald-200 text-emerald-950 border-emerald-500' : 'bg-rose-200 text-rose-950 border-rose-500'
                }`}>
                  {hasDiploma ? '✅ ASLI' : '❌ BELUM'}
                </span>
              </div>
            </div>

            {/* Tombol Eksekusi Verifikasi Meja */}
            <div className="mt-3 pt-2.5 border-t border-slate-300">
              <button
                onClick={handleVerify}
                className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-black text-xs uppercase tracking-wider rounded-lg pop-card-sm transition-all active:translate-y-0.5 cursor-pointer flex items-center justify-center gap-2"
              >
                <span>🔍 [ EKSEKUSI STEMPEL MEJA HRD ]</span>
              </button>
            </div>

            {/* STEMPEL VISUAL SLAM YANG MENDARAT MEMBAL */}
            {isVerified && (
              <div className="mt-3 pt-2 border-t border-slate-300 flex justify-center">
                {isAccepted ? (
                  <div className="animate-stamp-in bg-emerald-500 text-slate-950 font-black px-5 py-2.5 rounded-xl border-4 border-slate-950 shadow-2xl text-center rotate-[-4deg]">
                    <div className="text-xl lg:text-2xl tracking-widest font-black uppercase flex items-center justify-center gap-2">
                      <span>🎉</span>
                      <span>LOLOS SELEKSI</span>
                      <span>🎉</span>
                    </div>
                    <div className="text-[10px] text-slate-900 font-bold uppercase mt-0.5">
                      ★ DITERIMA SEBAGAI JUNIOR GAME DEVELOPER ★
                    </div>
                  </div>
                ) : (
                  <div className="animate-stamp-in bg-amber-400 text-slate-950 font-black px-5 py-2.5 rounded-xl border-4 border-slate-950 shadow-2xl text-center rotate-[3deg]">
                    <div className="text-xl lg:text-2xl tracking-widest font-black uppercase flex items-center justify-center gap-2">
                      <span>⚠️</span>
                      <span>PERBAIKI PORTOFOLIO</span>
                      <span>⚠️</span>
                    </div>
                    <div className="text-[10px] text-slate-900 font-bold uppercase mt-0.5">
                      Lengkapi syarat: {raporScore < minScore ? `[Rapor < ${minScore}] ` : ''}{!isMajorMatch ? '[Jurusan Beda] ' : ''}{!hasDiploma ? '[Ijazah Belum Ada]' : ''}
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* MISI & SOAL DETEKTIF CILIK */}
          <KidMissionBox
            chapterId={2}
            missionTitle="Verifikasi Berkas Magang Budi & Beri Stempel yang Tepat!"
            analogy="Sama seperti pintu bioskop: JIKA kamu punya tiket nonton, kamu masuk ke ruang teater (IF). ELSE (kalau tidak punya tiket), kamu disuruh beli tiket dulu di loket (ELSE)!"
            steps={[
              'Lihat sisi kiri atas: Perhatikan koding IF-ELSE dengan 2 cabang tegas yang otomatis menyala!',
              'Coba sisi kiri bawah: Naikkan/turunkan nilai rapor, atau klik tombol skenario pelamar!',
              'Perhatikan sisi kanan: Tekan tombol stempel meja HRD dan saksikan stempel besar membal mendarat!'
            ]}
            question="Jika nilai rapor Budi 75 (syarat minimal 80), cabang mana yang akan dipilih komputer?"
            options={[
              {
                text: 'Cabang IF (karena selisih 5 poin itu sedikit)',
                correct: false,
                explanation: 'Kurang tepat! Komputer sangat teliti, 75 itu lebih kecil dari 80.'
              },
              {
                text: 'Cabang ELSE (karena syarat nilai rapor belum terpenuhi)',
                correct: true,
                explanation: 'HEBAT BANGET! ⭐ Komputer langsung melompat ke blok ELSE karena kondisi rapor >= 80 bernilai FALSE!'
              },
              {
                text: 'Komputer meledak karena pusing menghitung',
                correct: false,
                explanation: 'Hihi salah ya! Komputer sangat tenang memilih jalur ELSE.'
              }
            ]}
            hasWonStar={hasWonStar}
            onEarnStar={onEarnStar}
          />
        </div>

        {/* Reset */}
        <div className="mt-3 pt-2 border-t border-slate-200 flex justify-end">
          <button
            onClick={() => {
              audio.playClick();
              setRaporScore(85);
              setIsMajorMatch(true);
              setHasDiploma(true);
              setMinScore(80);
              setIsVerified(false);
            }}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-slate-950 px-3 py-1.5 rounded border border-slate-900 bg-white pop-card-sm hover:bg-slate-50 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset 3 Berkas</span>
          </button>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 6. SPREAD 3: ELSE IF BERTINGKAT (MESIN PERMAINAN ARCADE BERHADIAH)
// ==========================================
function SmartWeatherSpread({
  hasWonStar,
  onEarnStar,
  onOpenPBLModal
}: {
  hasWonStar: boolean;
  onEarnStar: () => void;
  onOpenPBLModal: () => void;
}) {
  const [score, setScore] = useState<number>(78);
  const [codeLang, setCodeLang] = useState<'js' | 'indo'>('js');
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simStep, setSimStep] = useState<number>(0);
  const [showCustomRules, setShowCustomRules] = useState<boolean>(false);
  const [joystickDir, setJoystickDir] = useState<'center' | 'left' | 'right' | 'up' | 'down'>('center');
  const [smashPressed, setSmashPressed] = useState<boolean>(false);

  // Ambang batas skor (bisa dikustomisasi di fitur coba sendiri)
  const [threshJackpot, setThreshJackpot] = useState<number>(90);
  const [threshSilver, setThreshSilver] = useState<number>(70);
  const [threshBronze, setThreshBronze] = useState<number>(40);

  // Evaluasi Logika Percabangan Bertingkat ELSE IF Mesin Permainan
  const arcade = useMemo(() => {
    if (score >= threshJackpot) {
      return {
        level: 1,
        tierKey: 'jackpot',
        name: 'JACKPOT EMAS SUPER',
        badge: `🏆 TINGKAT 1: SKOR >= ${threshJackpot}`,
        accentColor: 'bg-amber-400',
        textColor: 'text-amber-950',
        borderColor: 'border-amber-600',
        prizeTitle: '1.000 Tiket Emas + Boneka Beruang Raksasa',
        prizeIcon: '🧸',
        subPrize: 'Sirene Emas & Piala Juara 1',
        actionAdvice: 'Sirene berputar kencang, dispenser tiket menyemburkan 1.000 tiket emas!',
        conditionCheck: `skor (${score}) >= ${threshJackpot} : BENAR (TRUE)`
      };
    } else if (score >= threshSilver) {
      return {
        level: 2,
        tierKey: 'silver',
        name: 'TIKET PERAK SUPER (MASTER)',
        badge: `🥈 TINGKAT 2: SKOR >= ${threshSilver}`,
        accentColor: 'bg-purple-400',
        textColor: 'text-purple-950',
        borderColor: 'border-purple-600',
        prizeTitle: '500 Tiket Perak + Pedang Laser LED Neon',
        prizeIcon: '⚔️',
        subPrize: 'Pedang Laser Cyberpunk & 500 Tiket',
        actionAdvice: 'Lampu LED neon berdengung, dispenser memuntahkan 500 tiket perak!',
        conditionCheck: `skor (${score}) >= ${threshSilver} : BENAR (TRUE)`
      };
    } else if (score >= threshBronze) {
      return {
        level: 3,
        tierKey: 'bronze',
        name: 'TIKET PERUNGGU (ROOKIE)',
        badge: `🥉 TINGKAT 3: SKOR >= ${threshBronze}`,
        accentColor: 'bg-emerald-400',
        textColor: 'text-emerald-950',
        borderColor: 'border-emerald-600',
        prizeTitle: '200 Tiket Perunggu + Gantungan Kunci Pixel',
        prizeIcon: '⭐',
        subPrize: 'Gantungan Kunci Bintang 8-Bit & 200 Tiket',
        actionAdvice: 'Lampu hijau berkedip gembira, dispenser mengeluarkan 200 tiket perunggu!',
        conditionCheck: `skor (${score}) >= ${threshBronze} : BENAR (TRUE)`
      };
    } else {
      return {
        level: 4,
        tierKey: 'consolation',
        name: 'TIKET HIBURAN (PEMULA)',
        badge: `🎪 TINGKAT 4: SKOR < ${threshBronze}`,
        accentColor: 'bg-rose-300',
        textColor: 'text-rose-950',
        borderColor: 'border-rose-600',
        prizeTitle: '50 Tiket Hiburan + Permen Lolipop Pelangi',
        prizeIcon: '🍭',
        subPrize: 'Permen Lolipop Segar & 50 Tiket',
        actionAdvice: 'Semua syarat di atas tidak lolos -> Masuk ke ELSE: Permen manis & 50 tiket hiburan!',
        conditionCheck: `Semua syarat di atas SALAH -> Masuk ke ELSE (Default)`
      };
    }
  }, [score, threshJackpot, threshSilver, threshBronze]);

  const handleScoreChange = (newVal: number) => {
    const clamped = Math.max(0, Math.min(100, newVal));
    setScore(clamped);
    if (clamped >= threshJackpot) {
      audio.playJackpot();
    } else {
      audio.playArcadeBeep(500 + clamped * 5);
    }
  };

  const handleCopyCode = () => {
    audio.playClick();
    const codeString = `// Kode Logika Percabangan ELSE IF Mesin Permainan Arcade
let skorPemain = ${score};
let hadiah = "";

if (skorPemain >= ${threshJackpot}) {
  hadiah = "1.000 Tiket Emas & Boneka Beruang Raksasa";
  nyalakanSirene("EMAS");
} else if (skorPemain >= ${threshSilver}) {
  hadiah = "500 Tiket Perak & Pedang Laser LED";
  nyalakanLampu("CYAN_NEON");
} else if (skorPemain >= ${threshBronze}) {
  hadiah = "200 Tiket Perunggu & Gantungan Kunci Pixel";
  nyalakanLampu("HIJAU");
} else {
  hadiah = "50 Tiket Hiburan & Permen Lolipop";
  keluarkanPermen();
}`;
    navigator.clipboard?.writeText(codeString);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const runSimulation = () => {
    audio.playClick();
    setIsSimulating(true);
    setSimStep(1);

    setTimeout(() => {
      audio.playArcadeBeep(600);
      setSimStep(2);
    }, 400);

    setTimeout(() => {
      audio.playArcadeBeep(800);
      setSimStep(3);
    }, 800);

    setTimeout(() => {
      if (score >= threshJackpot) {
        audio.playJackpot();
      } else {
        audio.playSuccess();
      }
      setIsSimulating(false);
      setSimStep(4);
    }, 1250);
  };

  const handleRandomScore = () => {
    const randomVals = [25, 38, 45, 55, 68, 75, 82, 92, 98];
    const picked = randomVals[Math.floor(Math.random() * randomVals.length)];
    handleScoreChange(picked);
  };

  const handleSmashButton = () => {
    setSmashPressed(true);
    audio.playArcadeBeep(900);
    // Tambah skor kecil saat dipukul atau beri efek haptic
    setTimeout(() => setSmashPressed(false), 200);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 h-full w-full">
      {/* ========================================================= */}
      {/* SISI KIRI: ATAS = CONTOH KODING, BAWAH = LAB COBA SENDIRI */}
      {/* ========================================================= */}
      <div className="relative p-5 lg:p-7 flex flex-col justify-between border-b lg:border-b-0 lg:border-r-2 border-slate-900 bg-slate-100 overflow-y-auto">
        <div>
          {/* Header Spread Bab 3 */}
          <div className="flex items-center justify-between text-xs font-bold mb-1">
            <span className="bg-amber-600 text-white px-2.5 py-0.5 rounded pop-card-sm uppercase flex items-center gap-1.5">
              <Gamepad2 className="w-3.5 h-3.5" />
              <span>BAB 03 // BANYAK KONDISI BERTINGKAT (ELSE IF)</span>
            </span>
            <span className="font-mono text-slate-700 font-bold bg-white px-2 py-0.5 rounded border border-slate-900">
              MESIN PERMAINAN
            </span>
          </div>
          <h2 className="text-xl lg:text-2xl font-black text-slate-950 uppercase tracking-tight mb-3">
            Logika Bertingkat Mesin Arcade & Hadiah
          </h2>

          {/* ALUR PROBLEM-BASED LEARNING (PBL) */}
          <PBLStepBar chapterNum={3} onOpenPBLModal={onOpenPBLModal} />

          {/* --------------------------------------------------------- */}
          {/* SISI KIRI ATAS: CONTOH KODING INTERAKTIF (logika_arcade)  */}
          {/* --------------------------------------------------------- */}
          <div className="bg-slate-950 text-slate-100 rounded-xl border-2 border-slate-900 pop-card overflow-hidden mb-4 shadow-lg">
            {/* Window Title Bar */}
            <div className="bg-slate-900 px-3 py-2 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                </div>
                <div className="flex items-center gap-1.5 ml-2 font-mono text-xs font-bold text-slate-300">
                  <Code2 className="w-3.5 h-3.5 text-amber-400" />
                  <span>logika_mesin_arcade.js</span>
                </div>
              </div>

              {/* Controls Header: Toggle Bahasa & Salin */}
              <div className="flex items-center gap-1.5">
                <div className="flex bg-slate-800 rounded p-0.5 border border-slate-700 text-[10px] font-bold">
                  <button
                    onClick={() => setCodeLang('js')}
                    className={`px-1.5 py-0.5 rounded cursor-pointer ${codeLang === 'js' ? 'bg-amber-400 text-slate-950 font-black' : 'text-slate-400 hover:text-white'}`}
                  >
                    JavaScript
                  </button>
                  <button
                    onClick={() => setCodeLang('indo')}
                    className={`px-1.5 py-0.5 rounded cursor-pointer ${codeLang === 'indo' ? 'bg-amber-400 text-slate-950 font-black' : 'text-slate-400 hover:text-white'}`}
                  >
                    Bahasa Logika
                  </button>
                </div>
                <button
                  onClick={handleCopyCode}
                  className="flex items-center gap-1 px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 text-[10px] font-bold cursor-pointer"
                  title="Salin Kode"
                >
                  {copiedCode ? (
                    <>
                      <Check className="w-3 h-3 text-emerald-400" />
                      <span className="text-emerald-400">Tersalin!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3 h-3" />
                      <span>Salin</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Live Variable Indicator Bar */}
            <div className="px-3.5 py-1.5 bg-slate-900/60 border-b border-slate-800/80 flex items-center justify-between text-[11px] font-mono">
              <div className="flex items-center gap-2">
                <span className="text-slate-400">Variabel:</span>
                <span className="px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 font-bold">
                  let skorPemain = {score}; // 🎮 Skor Mesin Permainan
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] text-slate-400 uppercase">Cabang Aktif:</span>
                <span className={`px-2 py-0.5 rounded font-black text-[10px] border ${arcade.accentColor} ${arcade.textColor} border-slate-900`}>
                  TINGKAT {arcade.level}
                </span>
              </div>
            </div>

            {/* Code Body with Real-time Branch Highlighting */}
            <div className="p-3 font-mono text-[11px] leading-relaxed select-text space-y-1">
              {/* TINGKAT 1: IF (JACKPOT EMAS >= 90) */}
              <div className={`p-1.5 rounded transition-all duration-300 ${arcade.level === 1 ? 'bg-amber-950/80 border-l-4 border-amber-400 text-amber-100 shadow-md font-bold' : 'opacity-60 text-slate-400'}`}>
                <div className="flex items-center justify-between">
                  <span>
                    <span className="text-purple-400">{codeLang === 'js' ? 'if' : 'JIKA'}</span>
                    {' (skorPemain >= '}<span className="text-amber-300">{threshJackpot}</span>{') {'}
                  </span>
                  {arcade.level === 1 && (
                    <span className="text-[10px] bg-amber-400 text-slate-950 px-1.5 py-0.2 rounded font-black tracking-wider animate-pulse">
                      👉 DIEKSEKUSI (TRUE)
                    </span>
                  )}
                </div>
                <div className="pl-4">
                  <span className="text-sky-300">hadiah</span> = <span className="text-emerald-300">"1.000 TIKET & BONEKA RAKSASA"</span>;
                </div>
                <div className="pl-4">
                  <span className="text-yellow-300">{codeLang === 'js' ? 'putarSirene' : 'nyalakanLampu'}</span>(<span className="text-amber-300">"EMAS_JUARA"</span>);
                </div>
                <div>{'}'}</div>
              </div>

              {/* TINGKAT 2: ELSE IF (TIKET PERAK >= 70) */}
              <div className={`p-1.5 rounded transition-all duration-300 ${arcade.level === 2 ? 'bg-purple-950/80 border-l-4 border-purple-400 text-purple-100 shadow-md font-bold' : 'opacity-60 text-slate-400'}`}>
                <div className="flex items-center justify-between">
                  <span>
                    <span className="text-purple-400">{codeLang === 'js' ? '} else if' : '} LAIN JIKA'}</span>
                    {' (skorPemain >= '}<span className="text-amber-300">{threshSilver}</span>{') {'}
                  </span>
                  {arcade.level === 2 && (
                    <span className="text-[10px] bg-purple-400 text-slate-950 px-1.5 py-0.2 rounded font-black tracking-wider animate-pulse">
                      👉 DIEKSEKUSI (TRUE)
                    </span>
                  )}
                </div>
                <div className="pl-4">
                  <span className="text-sky-300">hadiah</span> = <span className="text-emerald-300">"500 TIKET & PEDANG LASER NEON"</span>;
                </div>
                <div className="pl-4">
                  <span className="text-yellow-300">{codeLang === 'js' ? 'keluarkanTiket' : 'beriTiket'}</span>(<span className="text-amber-300">500</span>);
                </div>
                <div>{'}'}</div>
              </div>

              {/* TINGKAT 3: ELSE IF (TIKET PERUNGGU >= 40) */}
              <div className={`p-1.5 rounded transition-all duration-300 ${arcade.level === 3 ? 'bg-emerald-950/80 border-l-4 border-emerald-400 text-emerald-100 shadow-md font-bold' : 'opacity-60 text-slate-400'}`}>
                <div className="flex items-center justify-between">
                  <span>
                    <span className="text-purple-400">{codeLang === 'js' ? '} else if' : '} LAIN JIKA'}</span>
                    {' (skorPemain >= '}<span className="text-amber-300">{threshBronze}</span>{') {'}
                  </span>
                  {arcade.level === 3 && (
                    <span className="text-[10px] bg-emerald-400 text-slate-950 px-1.5 py-0.2 rounded font-black tracking-wider animate-pulse">
                      👉 DIEKSEKUSI (TRUE)
                    </span>
                  )}
                </div>
                <div className="pl-4">
                  <span className="text-sky-300">hadiah</span> = <span className="text-emerald-300">"200 TIKET & GANTUNGAN PIXEL"</span>;
                </div>
                <div className="pl-4">
                  <span className="text-yellow-300">{codeLang === 'js' ? 'keluarkanTiket' : 'beriTiket'}</span>(<span className="text-amber-300">200</span>);
                </div>
                <div>{'}'}</div>
              </div>

              {/* TINGKAT 4: ELSE (TIKET HIBURAN RAMAH) */}
              <div className={`p-1.5 rounded transition-all duration-300 ${arcade.level === 4 ? 'bg-rose-950/80 border-l-4 border-rose-400 text-rose-100 shadow-md font-bold' : 'opacity-60 text-slate-400'}`}>
                <div className="flex items-center justify-between">
                  <span>
                    <span className="text-purple-400">{codeLang === 'js' ? '} else' : '} LAINNYA'}</span> {'{'}
                  </span>
                  {arcade.level === 4 && (
                    <span className="text-[10px] bg-rose-300 text-slate-950 px-1.5 py-0.2 rounded font-black tracking-wider animate-pulse">
                      👉 DIEKSEKUSI (DEFAULT)
                    </span>
                  )}
                </div>
                <div className="pl-4">
                  <span className="text-sky-300">hadiah</span> = <span className="text-emerald-300">"50 TIKET & PERMEN LOLIPOP"</span>;
                </div>
                <div className="pl-4">
                  <span className="text-yellow-300">{codeLang === 'js' ? 'keluarkanPermen' : 'beriPermen'}</span>();
                </div>
                <div>{'}'}</div>
              </div>
            </div>

            {/* Micro Callout Bar */}
            <div className="p-2.5 bg-slate-900 border-t border-slate-800 text-[10px] text-slate-300 flex items-center gap-2">
              <Lightbulb className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>
                <strong>Cara Komputer Berpikir di Mesin Permainan:</strong> Komputer menguji dari skor terbesar ke terkecil. Karena sekarang skor pemain adalah <span className="text-amber-400 font-bold">{score} Poin</span>, komputer masuk ke <strong className="text-amber-300">Tingkat {arcade.level} ({arcade.name})</strong> dan langsung mengeluarkan hadiahnya, mengabaikan baris di bawahnya!
              </span>
            </div>
          </div>

          {/* --------------------------------------------------------- */}
          {/* SISI KIRI BAWAH: FITUR COBA SENDIRI (LAB INTERAKTIF)     */}
          {/* --------------------------------------------------------- */}
          <div className="bg-white rounded-xl border-2 border-slate-900 p-4 pop-card shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="p-1 bg-amber-400 rounded border border-slate-900 text-slate-950">
                  <Sparkles className="w-3.5 h-3.5" />
                </span>
                <div>
                  <div className="text-[10px] font-black uppercase text-amber-700 tracking-wider">
                    SISI KIRI BAWAH // LAB COBA SENDIRI
                  </div>
                  <h3 className="text-sm font-black text-slate-950 uppercase">
                    Eksplorasi Skor & Uji Logika Arcade!
                  </h3>
                </div>
              </div>

              {/* Status Badge */}
              <span className={`text-[10px] font-mono font-black px-2 py-0.5 rounded border border-slate-900 ${arcade.accentColor} ${arcade.textColor}`}>
                HADIAH: TK. {arcade.level}
              </span>
            </div>

            <p className="text-xs text-slate-600 mb-3">
              Masukkan angka skor pemain, tekan tombol acak, atau klik 4 tombol skenario pemain untuk menguji kode di atas!
            </p>

            {/* Kontrol Input Nilai Skor Sendiri */}
            <div className="p-3 bg-slate-50 rounded-lg border-2 border-slate-900 pop-card-sm mb-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-800">
                  1. Masukkan Angka Skor Pemain Sendiri (0 - 100):
                </span>
                <span className="font-mono text-sm font-black bg-slate-950 text-amber-400 px-2 py-0.5 rounded">
                  {score} POIN
                </span>
              </div>

              <div className="flex items-center gap-2">
                {/* Input Angka Mandiri */}
                <input
                  type="number"
                  min={0}
                  max={100}
                  value={score}
                  onChange={(e) => handleScoreChange(Number(e.target.value))}
                  className="w-20 px-2 py-1.5 bg-white border-2 border-slate-900 rounded font-mono text-sm font-black text-center pop-card-sm focus:outline-none focus:ring-2 focus:ring-amber-500"
                />

                {/* Tombol Cepat Stepper */}
                <div className="flex items-center gap-1 flex-1">
                  <button
                    onClick={() => handleScoreChange(score - 10)}
                    className="px-2 py-1.5 bg-slate-200 hover:bg-slate-300 rounded border border-slate-900 text-xs font-black pop-card-sm cursor-pointer"
                    title="Turunkan 10 Poin"
                  >
                    -10
                  </button>
                  <button
                    onClick={() => handleScoreChange(score - 5)}
                    className="px-2 py-1.5 bg-slate-200 hover:bg-slate-300 rounded border border-slate-900 text-xs font-black pop-card-sm cursor-pointer"
                    title="Turunkan 5 Poin"
                  >
                    -5
                  </button>
                  <button
                    onClick={() => handleScoreChange(score + 5)}
                    className="px-2 py-1.5 bg-slate-200 hover:bg-slate-300 rounded border border-slate-900 text-xs font-black pop-card-sm cursor-pointer"
                    title="Naikkan 5 Poin"
                  >
                    +5
                  </button>
                  <button
                    onClick={() => handleScoreChange(score + 10)}
                    className="px-2 py-1.5 bg-slate-200 hover:bg-slate-300 rounded border border-slate-900 text-xs font-black pop-card-sm cursor-pointer"
                    title="Naikkan 10 Poin"
                  >
                    +10
                  </button>
                  <button
                    onClick={handleRandomScore}
                    className="flex-1 py-1.5 bg-amber-300 hover:bg-amber-400 text-slate-950 rounded border border-slate-900 text-xs font-black pop-card-sm flex items-center justify-center gap-1 cursor-pointer"
                    title="Pilih Skor Acak"
                  >
                    <span>🎲 Acak</span>
                  </button>
                </div>
              </div>
            </div>

            {/* 4 Pilihan Uji Kasus Skenario Nyata */}
            <div className="mb-3">
              <div className="text-[11px] font-bold text-slate-700 mb-1.5">
                2. Atau Pilih Uji Coba Cepat 4 Level Pemain:
              </div>
              <div className="grid grid-cols-2 gap-1.5 text-xs font-black">
                <button
                  onClick={() => handleScoreChange(95)}
                  className={`p-2 rounded border border-slate-900 text-left pop-card-sm transition-all cursor-pointer flex items-center justify-between ${score >= threshJackpot ? 'bg-amber-300 text-slate-950 font-black ring-2 ring-amber-500' : 'bg-amber-100 hover:bg-amber-200 text-slate-800'}`}
                >
                  <span>🏆 95 Poin: Juara Jackpot</span>
                  <span className="text-[10px] font-mono bg-white px-1 rounded">TK. 1</span>
                </button>
                <button
                  onClick={() => handleScoreChange(78)}
                  className={`p-2 rounded border border-slate-900 text-left pop-card-sm transition-all cursor-pointer flex items-center justify-between ${score >= threshSilver && score < threshJackpot ? 'bg-purple-300 text-slate-950 font-black ring-2 ring-purple-500' : 'bg-purple-100 hover:bg-purple-200 text-slate-800'}`}
                >
                  <span>🥈 78 Poin: Pro Perak</span>
                  <span className="text-[10px] font-mono bg-white px-1 rounded">TK. 2</span>
                </button>
                <button
                  onClick={() => handleScoreChange(52)}
                  className={`p-2 rounded border border-slate-900 text-left pop-card-sm transition-all cursor-pointer flex items-center justify-between ${score >= threshBronze && score < threshSilver ? 'bg-emerald-300 text-slate-950 font-black ring-2 ring-emerald-500' : 'bg-emerald-100 hover:bg-emerald-200 text-slate-800'}`}
                >
                  <span>🥉 52 Poin: Rookie Perunggu</span>
                  <span className="text-[10px] font-mono bg-white px-1 rounded">TK. 3</span>
                </button>
                <button
                  onClick={() => handleScoreChange(25)}
                  className={`p-2 rounded border border-slate-900 text-left pop-card-sm transition-all cursor-pointer flex items-center justify-between ${score < threshBronze ? 'bg-rose-300 text-slate-950 font-black ring-2 ring-rose-500' : 'bg-rose-100 hover:bg-rose-200 text-slate-800'}`}
                >
                  <span>🍭 25 Poin: Tiket Hiburan</span>
                  <span className="text-[10px] font-mono bg-white px-1 rounded">TK. 4</span>
                </button>
              </div>
            </div>

            {/* Tombol Eksekusi Simulasi Langkah-demi-Langkah */}
            <button
              onClick={runSimulation}
              disabled={isSimulating}
              className={`w-full py-2.5 px-3 rounded-lg border-2 border-slate-900 font-black text-xs uppercase tracking-wider pop-card-sm flex items-center justify-center gap-2 cursor-pointer transition-all ${isSimulating ? 'bg-amber-300 animate-pulse text-slate-950' : 'bg-slate-900 hover:bg-slate-800 text-amber-300 active:translate-y-0.5'}`}
            >
              <Zap className="w-4 h-4 text-amber-400" />
              <span>{isSimulating ? '⚡ SEDANG MENGEVALUASI TINGKAT HADIAH...' : '⚡ TEST & JALANKAN LOGIKA ARCADE (STEP-BY-STEP)'}</span>
            </button>

            {/* Terminal Output Interaktif */}
            <div className="mt-2.5 p-2.5 bg-slate-950 rounded-lg border border-slate-900 text-[10px] font-mono text-emerald-400">
              <div className="flex items-center gap-1.5 text-slate-400 border-b border-slate-800 pb-1 mb-1 font-bold">
                <Terminal className="w-3 h-3 text-emerald-400" />
                <span>TERMINAL HASIL EKSEKUSI REACT JS:</span>
              </div>
              <div className="text-slate-300">
                &gt; Input Skor: <span className="text-amber-300 font-bold">{score} Poin</span>
              </div>
              <div className="text-slate-300">
                &gt; Cabang Terpilih: <span className="text-white font-bold">{arcade.name} (Tingkat {arcade.level})</span>
              </div>
              <div className="text-emerald-300">
                &gt; Status Evaluasi: {arcade.conditionCheck}
              </div>
              <div className="text-amber-300 font-bold">
                &gt; Hadiah Dikeluarkan: {arcade.prizeIcon} {arcade.prizeTitle}
              </div>
            </div>

            {/* Toggle Mode Ubah Aturan Ambang Batas (Custom Rules) */}
            <div className="mt-3 pt-2.5 border-t border-slate-200">
              <button
                onClick={() => {
                  audio.playClick();
                  setShowCustomRules(!showCustomRules);
                }}
                className="w-full flex items-center justify-between text-xs font-bold text-slate-700 hover:text-slate-950 p-1.5 rounded bg-slate-50 border border-slate-300 cursor-pointer"
              >
                <span className="flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-amber-600" />
                  <span>Fitur Lanjutan: Kustomisasi Angka Ambang Batas Skor</span>
                </span>
                <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-slate-200">
                  {showCustomRules ? 'TUTUP ▲' : 'UBAH BATAS ▼'}
                </span>
              </button>

              {showCustomRules && (
                <div className="mt-2 p-2.5 bg-amber-50 rounded-lg border border-amber-300 text-xs space-y-2 animate-fadeIn">
                  <div className="text-[11px] font-bold text-amber-950">
                    🛠️ Coba Ubah Angka Ambang Batas Skor di Mesin Arcade:
                  </div>
                  <div className="grid grid-cols-3 gap-2 text-[10px]">
                    <div>
                      <span className="block font-bold text-slate-700 mb-1">Batas Emas (default: 90):</span>
                      <input
                        type="number"
                        value={threshJackpot}
                        onChange={(e) => setThreshJackpot(Number(e.target.value))}
                        className="w-full p-1 bg-white border border-slate-900 rounded font-mono font-bold text-center"
                      />
                    </div>
                    <div>
                      <span className="block font-bold text-slate-700 mb-1">Batas Perak (default: 70):</span>
                      <input
                        type="number"
                        value={threshSilver}
                        onChange={(e) => setThreshSilver(Number(e.target.value))}
                        className="w-full p-1 bg-white border border-slate-900 rounded font-mono font-bold text-center"
                      />
                    </div>
                    <div>
                      <span className="block font-bold text-slate-700 mb-1">Batas Perunggu (default: 40):</span>
                      <input
                        type="number"
                        value={threshBronze}
                        onChange={(e) => setThreshBronze(Number(e.target.value))}
                        className="w-full p-1 bg-white border border-slate-900 rounded font-mono font-bold text-center"
                      />
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      audio.playClick();
                      setThreshJackpot(90);
                      setThreshSilver(70);
                      setThreshBronze(40);
                    }}
                    className="text-[10px] font-bold text-amber-900 underline cursor-pointer"
                  >
                    Reset Batas Standar (90, 70, 40)
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Reset Keseluruhan Sisi Kiri */}
        <div className="mt-3 pt-2 border-t border-slate-200 flex justify-end">
          <button
            onClick={() => {
              audio.playClick();
              setScore(78);
              setThreshJackpot(90);
              setThreshSilver(70);
              setThreshBronze(40);
              setShowCustomRules(false);
            }}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-slate-950 px-3 py-1.5 rounded border border-slate-900 bg-white pop-card-sm hover:bg-slate-50 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Setelan Awal (78 Poin)</span>
          </button>
        </div>
      </div>

      {/* ========================================================= */}
      {/* SISI KANAN: PANGGUNG VISUAL MESIN PERMAINAN ARCADE BERGERAK */}
      {/* ========================================================= */}
      <div className="relative p-5 lg:p-7 flex flex-col justify-between bg-white text-slate-900 paper-bg overflow-y-auto">
        <div>
          {/* Header Panggung Kanan */}
          <div className="flex items-center justify-between text-xs font-bold mb-1">
            <span className="bg-amber-600 text-white px-2.5 py-0.5 rounded pop-card-sm uppercase flex items-center gap-1">
              <Gamepad2 className="w-3.5 h-3.5" />
              <span>SISI KANAN // PANGGUNG VISUAL PERMAINAN</span>
            </span>
            <span className="font-mono text-slate-700 font-bold">
              100% GAMBAR BERGERAK
            </span>
          </div>
          <h2 className="text-xl lg:text-2xl font-black text-slate-950 uppercase tracking-tight mb-3">
            Mesin Arcade Retro & Reaksi Hadiah Nyata
          </h2>

          {/* KABINET MESIN PERMAINAN ARCADE */}
          <div className="relative w-full rounded-2xl border-4 border-slate-950 pop-card overflow-hidden shadow-2xl flex flex-col justify-between p-4 transition-all duration-500 bg-gradient-to-b from-slate-950 via-slate-900 to-indigo-950 text-white mb-3.5">
            {/* Top Marquee Neon Header */}
            <div className="relative z-20 flex items-center justify-between bg-slate-900/90 border-2 border-amber-500/80 px-3 py-2 rounded-xl pop-card-sm shadow-[0_0_15px_rgba(245,158,11,0.3)] mb-2.5">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
                <span className="text-xs font-black tracking-widest text-amber-300 uppercase">
                  ★ ARCADE JACKPOT PRIZE ARENA ★
                </span>
              </div>
              <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-black border border-slate-900 ${arcade.accentColor} ${arcade.textColor}`}>
                {arcade.badge}
              </span>
            </div>

            {/* Display Matriks Skor Digital Besar */}
            <div className="relative z-20 flex items-center justify-between bg-slate-950 px-4 py-2 rounded-xl border-2 border-slate-800 mb-2">
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono font-bold text-slate-400">SKOR DIGITAL:</span>
                <span className="text-2xl font-mono font-black text-amber-400 tracking-wider bg-slate-900 px-3 py-0.5 rounded border border-amber-600/60 shadow-inner">
                  {score < 10 ? `00${score}` : score < 100 ? `0${score}` : `${score}`}
                </span>
              </div>
              <div className="text-right">
                <div className="text-[9px] font-mono uppercase text-slate-400">STATUS CABANG:</div>
                <div className="text-xs font-black text-emerald-400">{arcade.name}</div>
              </div>
            </div>

            {/* AREA PANGGUNG VISUAL ELEMEN-ELEMEN BERGERAK ARCADE */}
            <div className="relative min-h-[170px] bg-slate-950/80 rounded-xl border-2 border-slate-800 p-3 flex items-center justify-around my-1 overflow-hidden">
              {/* KONDISI 1: JACKPOT EMAS (Sirene Emas 360°, Konfeti, 1000 Tiket, Boneka Raksasa Bermahkota) */}
              {arcade.level === 1 && (
                <div className="flex items-center justify-around w-full animate-fadeIn">
                  {/* 1. Sirene Emas Berputar 360 Derajat */}
                  <div className="flex flex-col items-center">
                    <div className="relative w-16 h-16 animate-spin-slow">
                      <svg viewBox="0 0 80 80" className="w-full h-full drop-shadow-[0_0_12px_#f59e0b]">
                        <circle cx="40" cy="40" r="24" fill="#fbbf24" stroke="#0f172a" strokeWidth="3" />
                        {[0, 60, 120, 180, 240, 300].map((deg) => (
                          <line
                            key={deg}
                            x1="40"
                            y1="10"
                            x2="40"
                            y2="2"
                            stroke="#f59e0b"
                            strokeWidth="4"
                            strokeLinecap="round"
                            transform={`rotate(${deg} 40 40)`}
                          />
                        ))}
                      </svg>
                      <div className="absolute inset-0 flex items-center justify-center text-lg animate-ping">
                        🚨
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-slate-950 bg-amber-400 px-2 py-0.5 rounded border border-slate-900 pop-card-sm mt-1">
                      Sirene Emas Putar
                    </span>
                  </div>

                  {/* 2. Dispenser Tiket Menyemburkan Gulungan 1.000 Tiket Emas */}
                  <div className="flex flex-col items-center">
                    <div className="relative w-20 h-20 flex flex-col items-center justify-center">
                      <div className="w-16 h-8 bg-amber-500 rounded-t-md border-2 border-slate-950 flex items-center justify-center font-black text-[10px] text-slate-950 shadow-md">
                        DISPENSER
                      </div>
                      {/* Pita Tiket Emas Meluncur */}
                      <div className="w-14 h-12 bg-amber-300 border-2 border-slate-950 border-t-0 flex flex-col justify-around px-1 animate-bounce">
                        <div className="text-[7px] font-mono font-black text-slate-950 text-center border-b border-dashed border-slate-900">
                          🎟️ TIKET #1000
                        </div>
                        <div className="text-[7px] font-mono font-black text-slate-950 text-center">
                          GOLD JACKPOT
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-slate-950 bg-amber-400 px-2 py-0.5 rounded border border-slate-900 pop-card-sm mt-1">
                      1.000 Tiket Meluncur!
                    </span>
                  </div>

                  {/* 3. Boneka Beruang Raksasa Bermahkota Juara Melompat */}
                  <div className="flex flex-col items-center animate-bounce-gentle">
                    <div className="relative w-16 h-20 flex flex-col items-center">
                      <div className="text-base absolute -top-2 animate-bounce">👑</div>
                      <div className="w-12 h-12 rounded-full bg-amber-600 border-2 border-slate-950 flex items-center justify-center text-2xl shadow-md">
                        🧸
                      </div>
                      <div className="w-10 h-7 bg-amber-400 rounded-b-lg border-2 border-slate-950 flex items-center justify-center text-[10px] font-black text-slate-950">
                        JUARA 1
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-slate-950 bg-amber-400 px-2 py-0.5 rounded border border-slate-900 pop-card-sm mt-1">
                      Boneka Beruang Raksasa
                    </span>
                  </div>
                </div>
              )}

              {/* KONDISI 2: TIKET PERAK SUPER (Pedang Laser Berdengung, 500 Tiket, Gamer Pro) */}
              {arcade.level === 2 && (
                <div className="flex items-center justify-around w-full animate-fadeIn">
                  {/* 1. Pedang Laser LED Neon Berdengung */}
                  <div className="flex flex-col items-center">
                    <div className="relative w-16 h-20 flex flex-col items-center justify-center">
                      <div className="w-3 h-14 bg-purple-400 rounded-t-full border-2 border-white shadow-[0_0_15px_#c084fc] animate-pulse" />
                      <div className="w-6 h-3 bg-slate-700 rounded-sm border border-white" />
                      <div className="w-2.5 h-4 bg-slate-900 border border-slate-700" />
                    </div>
                    <span className="text-[10px] font-bold text-slate-950 bg-purple-300 px-2 py-0.5 rounded border border-slate-900 pop-card-sm mt-1">
                      Pedang Laser Neon
                    </span>
                  </div>

                  {/* 2. Dispenser Tiket Perak 500 Lembar */}
                  <div className="flex flex-col items-center">
                    <div className="relative w-20 h-20 flex flex-col items-center justify-center">
                      <div className="w-16 h-8 bg-slate-700 rounded-t-md border-2 border-slate-950 flex items-center justify-center font-black text-[10px] text-white shadow-md">
                        DISPENSER
                      </div>
                      <div className="w-14 h-12 bg-slate-200 border-2 border-slate-950 border-t-0 flex flex-col justify-around px-1 animate-bounce">
                        <div className="text-[7px] font-mono font-black text-slate-950 text-center border-b border-dashed border-slate-900">
                          🎟️ TIKET #500
                        </div>
                        <div className="text-[7px] font-mono font-black text-slate-950 text-center">
                          SILVER PRO
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-slate-950 bg-purple-300 px-2 py-0.5 rounded border border-slate-900 pop-card-sm mt-1">
                      500 Tiket Perak
                    </span>
                  </div>

                  {/* 3. Karakter Gamer VR Pro Merayakan */}
                  <div className="flex flex-col items-center animate-bounce-gentle">
                    <div className="relative w-16 h-20 flex flex-col items-center">
                      <div className="w-10 h-10 rounded-full bg-amber-200 border-2 border-slate-950 flex items-center justify-center text-sm shadow-md">
                        🥽
                      </div>
                      <div className="w-9 h-8 bg-purple-600 rounded-t border-2 border-slate-950 flex items-center justify-center text-[10px] font-black text-white">
                        PRO
                      </div>
                      <div className="flex gap-1">
                        <div className="w-2 h-3 bg-slate-900" />
                        <div className="w-2 h-3 bg-slate-900" />
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-slate-950 bg-purple-300 px-2 py-0.5 rounded border border-slate-900 pop-card-sm mt-1">
                      Karakter Pro Gamer
                    </span>
                  </div>
                </div>
              )}

              {/* KONDISI 3: TIKET PERUNGGU ROOKIE (Bintang Pixel 8-Bit, Gantungan Kunci, 200 Tiket) */}
              {arcade.level === 3 && (
                <div className="flex items-center justify-around w-full animate-fadeIn">
                  {/* 1. Bintang Pixel 8-Bit Bersinar */}
                  <div className="flex flex-col items-center">
                    <div className="relative w-16 h-20 flex items-center justify-center">
                      <div className="text-4xl animate-bounce drop-shadow-[0_0_10px_#4ade80]">
                        ⭐
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-slate-950 bg-emerald-400 px-2 py-0.5 rounded border border-slate-900 pop-card-sm mt-1">
                      Bintang Pixel 8-Bit
                    </span>
                  </div>

                  {/* 2. Dispenser Tiket Perunggu 200 Lembar */}
                  <div className="flex flex-col items-center">
                    <div className="relative w-20 h-20 flex flex-col items-center justify-center">
                      <div className="w-16 h-8 bg-amber-800 rounded-t-md border-2 border-slate-950 flex items-center justify-center font-black text-[10px] text-amber-200 shadow-md">
                        DISPENSER
                      </div>
                      <div className="w-14 h-12 bg-amber-100 border-2 border-slate-900 border-t-0 flex flex-col justify-around px-1 animate-bounce">
                        <div className="text-[7px] font-mono font-black text-slate-950 text-center border-b border-dashed border-slate-900">
                          🎟️ TIKET #200
                        </div>
                        <div className="text-[7px] font-mono font-black text-slate-950 text-center">
                          BRONZE TIER
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-slate-950 bg-emerald-400 px-2 py-0.5 rounded border border-slate-900 pop-card-sm mt-1">
                      200 Tiket Perunggu
                    </span>
                  </div>

                  {/* 3. Gantungan Kunci Joystick Pixel */}
                  <div className="flex flex-col items-center animate-bounce-gentle">
                    <div className="relative w-16 h-20 flex flex-col items-center justify-center">
                      <div className="w-2.5 h-4 border-2 border-slate-300 rounded-full" />
                      <div className="w-10 h-7 bg-emerald-600 rounded-md border-2 border-slate-950 flex items-center justify-center text-sm shadow-md">
                        🕹️
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-slate-950 bg-emerald-400 px-2 py-0.5 rounded border border-slate-900 pop-card-sm mt-1">
                      Gantungan Kunci Pixel
                    </span>
                  </div>
                </div>
              )}

              {/* KONDISI 4: TIKET HIBURAN RAMAH (Permen Lolipop Raksasa, 50 Tiket) */}
              {arcade.level === 4 && (
                <div className="flex items-center justify-around w-full animate-fadeIn">
                  {/* 1. Permen Lolipop Pelangi Berputar */}
                  <div className="flex flex-col items-center">
                    <div className="relative w-16 h-20 flex flex-col items-center justify-center">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-rose-400 via-amber-300 to-sky-400 border-2 border-slate-950 flex items-center justify-center text-xl animate-spin-slow shadow-md">
                        🍭
                      </div>
                      <div className="w-1.5 h-6 bg-white border border-slate-900" />
                    </div>
                    <span className="text-[10px] font-bold text-slate-950 bg-rose-300 px-2 py-0.5 rounded border border-slate-900 pop-card-sm mt-1">
                      Permen Lolipop Segar
                    </span>
                  </div>

                  {/* 2. Dispenser Tiket 50 Lembar */}
                  <div className="flex flex-col items-center">
                    <div className="relative w-20 h-20 flex flex-col items-center justify-center">
                      <div className="w-16 h-8 bg-rose-800 rounded-t-md border-2 border-slate-950 flex items-center justify-center font-black text-[10px] text-rose-200 shadow-md">
                        DISPENSER
                      </div>
                      <div className="w-14 h-12 bg-rose-100 border-2 border-slate-950 border-t-0 flex flex-col justify-around px-1 animate-bounce">
                        <div className="text-[7px] font-mono font-black text-slate-950 text-center border-b border-dashed border-slate-900">
                          🎟️ TIKET #50
                        </div>
                        <div className="text-[7px] font-mono font-black text-slate-950 text-center">
                          HIBURAN CERIA
                        </div>
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-slate-950 bg-rose-300 px-2 py-0.5 rounded border border-slate-900 pop-card-sm mt-1">
                      50 Tiket Hiburan
                    </span>
                  </div>

                  {/* 3. Karakter Tersenyum Senang */}
                  <div className="flex flex-col items-center animate-bounce-gentle">
                    <div className="relative w-16 h-20 flex flex-col items-center">
                      <div className="w-10 h-10 rounded-full bg-amber-200 border-2 border-slate-950 flex items-center justify-center text-sm shadow-md">
                        😊
                      </div>
                      <div className="w-9 h-8 bg-rose-500 rounded-t border-2 border-slate-950 flex items-center justify-center text-[10px] font-black text-white">
                        Ceria!
                      </div>
                      <div className="flex gap-1">
                        <div className="w-2 h-3 bg-slate-900" />
                        <div className="w-2 h-3 bg-slate-900" />
                      </div>
                    </div>
                    <span className="text-[10px] font-bold text-slate-950 bg-rose-300 px-2 py-0.5 rounded border border-slate-900 pop-card-sm mt-1">
                      Tetap Senang Belajar
                    </span>
                  </div>
                </div>
              )}
            </div>

            {/* KONTROL FISIK INTERAKTIF ARCADE: JOYSTICK & SMASH BUTTON */}
            <div className="relative z-20 bg-slate-950 p-2.5 rounded-xl border border-slate-800 flex items-center justify-between gap-3 mt-1.5">
              {/* Interactive Joystick */}
              <div className="flex items-center gap-2">
                <div className="flex flex-col items-center">
                  <div
                    onClick={() => {
                      audio.playClick();
                      const dirs: Array<'left' | 'right' | 'up' | 'down'> = ['left', 'right', 'up', 'down'];
                      const d = dirs[Math.floor(Math.random() * dirs.length)];
                      setJoystickDir(d);
                      setTimeout(() => setJoystickDir('center'), 300);
                    }}
                    className={`w-9 h-9 rounded-full bg-red-600 border-2 border-slate-950 cursor-pointer transition-transform shadow-md flex items-center justify-center text-xs font-black text-white active:scale-95 ${
                      joystickDir === 'left' ? '-translate-x-2' : joystickDir === 'right' ? 'translate-x-2' : joystickDir === 'up' ? '-translate-y-2' : joystickDir === 'down' ? 'translate-y-2' : ''
                    }`}
                    title="Klik untuk Goyang Joystick"
                  >
                    🕹️
                  </div>
                  <span className="text-[8px] font-mono text-slate-400 mt-0.5">JOYSTICK</span>
                </div>
                <div className="text-[10px] text-slate-300 hidden sm:block">
                  <div className="font-bold text-amber-300">PENGENDALI GAME:</div>
                  <div className="text-[9px] text-slate-400">Tekan tombol merah untuk hit!</div>
                </div>
              </div>

              {/* Big Red Smash / Play Button */}
              <button
                onClick={handleSmashButton}
                className={`py-2 px-4 rounded-xl border-2 border-slate-950 font-black text-xs uppercase tracking-wider pop-card-sm transition-all flex items-center gap-1.5 cursor-pointer ${
                  smashPressed ? 'bg-red-400 scale-95' : 'bg-red-600 hover:bg-red-500 text-white shadow-[0_0_12px_#ef4444]'
                }`}
              >
                <span>🔴</span>
                <span>HIT / MAINKAN!</span>
              </button>
            </div>

            {/* Kotak Panduan Aksi Bawah */}
            <div className="relative z-20 bg-white/95 text-slate-950 p-2 rounded-xl border border-slate-900 text-center mt-2">
              <span className="text-xs font-black">
                👉 {arcade.actionAdvice}
              </span>
            </div>
          </div>

          {/* Slider Skor Gauge Analog */}
          <div className="p-3 bg-slate-50 border-2 border-slate-950 rounded-lg pop-card-sm mb-3">
            <div className="flex items-center justify-between mb-1.5 text-xs font-bold text-slate-700">
              <span>GESER GAUGE SKOR PERMAINAN:</span>
              <span className="font-mono font-black text-slate-950 bg-amber-300 px-2 py-0.5 rounded border border-slate-900">
                {score} POIN
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={score}
              onChange={(e) => handleScoreChange(Number(e.target.value))}
              className="w-full accent-amber-500 cursor-pointer h-2 bg-slate-200 rounded-lg"
            />
          </div>

          {/* Tangga Keputusan ELSE IF Mesin Permainan */}
          <div className="space-y-1 mb-3 text-[11px] font-mono">
            <div className={`p-1.5 rounded border border-slate-950 flex justify-between ${arcade.level === 1 ? 'bg-amber-300 font-bold pop-card-sm' : 'bg-slate-100 opacity-60'}`}>
              <span>1. if (skor &gt;= {threshJackpot})</span>
              <span>👉 🏆 JACKPOT EMAS (1000 Tiket & Boneka)</span>
            </div>
            <div className={`p-1.5 rounded border border-slate-950 flex justify-between ${arcade.level === 2 ? 'bg-purple-300 font-bold pop-card-sm' : 'bg-slate-100 opacity-60'}`}>
              <span>2. else if (skor &gt;= {threshSilver})</span>
              <span>👉 🥈 TIKET PERAK (500 Tiket & Pedang Laser)</span>
            </div>
            <div className={`p-1.5 rounded border border-slate-950 flex justify-between ${arcade.level === 3 ? 'bg-emerald-300 font-bold pop-card-sm' : 'bg-slate-100 opacity-60'}`}>
              <span>3. else if (skor &gt;= {threshBronze})</span>
              <span>👉 🥉 TIKET PERUNGGU (200 Tiket & Gantungan)</span>
            </div>
            <div className={`p-1.5 rounded border border-slate-950 flex justify-between ${arcade.level === 4 ? 'bg-rose-300 font-bold pop-card-sm' : 'bg-slate-100 opacity-60'}`}>
              <span>4. else (sisanya)</span>
              <span>👉 🎪 TIKET HIBURAN (50 Tiket & Permen Lolipop)</span>
            </div>
          </div>

          {/* MISI & SOAL DETEKTIF CILIK */}
          <KidMissionBox
            chapterId={3}
            missionTitle="Raih Skor Jackpot di Mesin Arcade & Bawa Pulang Boneka Raksasa!"
            analogy="Sama seperti mesin arcade tiket di tempat bermain: JIKA skor mencapai 90 ke atas -> Mesin mengeluarkan JACKPOT TIKET EMAS 1000 + Boneka Raksasa! ELSE IF skor mencapai 70 -> TIKET PERAK 500 + Pedang Laser. ELSE IF skor mencapai 40 -> TIKET PERUNGGU 200 + Gantungan Kunci. ELSE (skor di bawahnya) -> TIKET HIBURAN 50 + Permen Lolipop. Komputer mengecek dari tingkatan terbesar secara berurutan!"
            steps={[
              'Lihat sisi kiri atas: Perhatikan bagaimana baris koding menyala tepat di tingkat skor pemain yang kamu pilih!',
              'Coba sisi kiri bawah: Masukkan angka skormu sendiri (0-100) atau klik tombol [🎲 Acak] dan [⚡ Test Kode]!',
              'Perhatikan sisi kanan: Gambar mesin arcade bergerak otomatis (sirene emas berputar, gulungan tiket meluncur, pedang neon, boneka raksasa)!'
            ]}
            question="Jika seorang anak bermain mesin arcade dan mencetak skor 78 poin, cabang koding mana yang akan dipilih komputer dan hadiah apa yang keluar?"
            options={[
              {
                text: 'Cabang Jackpot Emas (karena 78 itu skor yang sangat tinggi)',
                correct: false,
                explanation: 'Kurang tepat! 78 poin belum mencapai syarat minimal 90 poin untuk mendapatkan Jackpot Emas.'
              },
              {
                text: 'Cabang Tiket Perak Super (Pedang Neon & 500 Tiket) karena 78 >= 70 pada baris ELSE IF ke-2!',
                correct: true,
                explanation: 'BENAR SEKALI! ⭐ Skor 78 belum cukup untuk Jackpot (>= 90), tetapi lolos di baris ELSE IF kedua (>= 70) sehingga komputer langsung mengeluarkan Tiket Perak Super dan menghentikan pengecekan!'
              },
              {
                text: 'Cabang Tiket Hiburan (karena mesin membagi hadiah secara acak)',
                correct: false,
                explanation: 'Salah ya! Komputer selalu memeriksa aturan bertingkat secara logis dan teratur, tidak pernah acak.'
              }
            ]}
            hasWonStar={hasWonStar}
            onEarnStar={onEarnStar}
          />
        </div>

        {/* Reset */}
        <div className="mt-3 pt-2 border-t border-slate-200 flex justify-end">
          <button
            onClick={() => handleScoreChange(78)}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-slate-950 px-3 py-1.5 rounded border border-slate-900 bg-white pop-card-sm hover:bg-slate-50 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Skor (78 Poin)</span>
          </button>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 7. SPREAD 4: SWITCH - CASE (VENDING MACHINE RETRO ASLI)
// ==========================================
function VendingMachineSpread({
  hasWonStar,
  onEarnStar,
  onOpenPBLModal
}: {
  hasWonStar: boolean;
  onEarnStar: () => void;
  onOpenPBLModal: () => void;
}) {
  const [selectedSlot, setSelectedSlot] = useState<number>(1);
  const [dispensedItem, setDispensedItem] = useState<{ name: string; price: string; icon: string; priceNum: number } | null>({
    name: 'Boba Milk Tea Dingin',
    price: 'Rp 12.000',
    icon: '🧋',
    priceNum: 12000
  });
  const [isDispensing, setIsDispensing] = useState<boolean>(false);
  const [coinsInserted, setCoinsInserted] = useState<number>(20000);
  const [coilAngle, setCoilAngle] = useState<number>(0);
  const [codeLang, setCodeLang] = useState<'js' | 'indo'>('js');
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [showCustomRules, setShowCustomRules] = useState<boolean>(false);
  const [coinDiscount, setCoinDiscount] = useState<number>(0);
  const [visualMode, setVisualMode] = useState<'2d' | '3d'>('2d');

  const ITEMS: Record<number, { name: string; price: string; icon: string; priceNum: number; desc: string }> = {
    1: { name: 'Boba Milk Tea Dingin', price: 'Rp 12.000', icon: '🧋', priceNum: 12000, desc: 'Boba manis kenyal dengan teh susu dingin segar' },
    2: { name: 'Roti Bakar Keju Cokelat', price: 'Rp 8.000', icon: '🥪', priceNum: 8000, desc: 'Roti bakar garing isi cokelat lumer & taburan keju' },
    3: { name: 'Es Krim Sundae Tiga Scoop', price: 'Rp 7.000', icon: '🍦', priceNum: 7000, desc: 'Es krim vanila-stroberi-cokelat dengan saus karamel' },
    4: { name: 'Susu Stroberi Kotak Dingin', price: 'Rp 5.000', icon: '🧃', priceNum: 5000, desc: 'Susu UHT segar rasa buah stroberi asli' }
  };

  const currentItem = ITEMS[selectedSlot] || null;

  const handleSelect = (slotNum: number) => {
    audio.playClick();
    setSelectedSlot(slotNum);
    setIsDispensing(true);
    setCoilAngle((prev) => prev + 360);

    setTimeout(() => {
      if (ITEMS[slotNum]) {
        audio.playVendingDrop();
        setDispensedItem(ITEMS[slotNum]);
      } else {
        audio.playBuzzer();
        setDispensedItem(null);
      }
      setIsDispensing(false);
    }, 600);
  };

  const handleCopyCode = () => {
    const codeText = codeLang === 'js'
      ? `// Logika Switch-Case Kantin Sekolah
let kode = ${selectedSlot};
let itemDipilih = "";

switch (kode) {
  case 1:
    itemDipilih = "Boba Milk Tea Dingin"; // Rp 12.000
    putarPegasSpiral(1);
    break;
  case 2:
    itemDipilih = "Roti Bakar Keju Cokelat"; // Rp 8.000
    putarPegasSpiral(2);
    break;
  case 3:
    itemDipilih = "Es Krim Sundae Tiga Scoop"; // Rp 7.000
    putarPegasSpiral(3);
    break;
  case 4:
    itemDipilih = "Susu Stroberi Kotak Dingin"; // Rp 5.000
    putarPegasSpiral(4);
    break;
  default:
    itemDipilih = "Kode Tidak Dikenal!";
    bunyikanAlarmError();
}`
      : `// Logika Percabangan Pemilih Langsung
ANGKA_KODE = ${selectedSlot};

PILIH_SESUAI (ANGKA_KODE) {
  JIKA_NOMOR 1:
    Keluar Makanan -> Boba Milk Tea Dingin
    SELESAI_KELUAR (BREAK);
  JIKA_NOMOR 2:
    Keluar Makanan -> Roti Bakar Keju
    SELESAI_KELUAR (BREAK);
  JIKA_NOMOR 3:
    Keluar Makanan -> Es Krim Sundae
    SELESAI_KELUAR (BREAK);
  JIKA_NOMOR 4:
    Keluar Makanan -> Susu Stroberi
    SELESAI_KELUAR (BREAK);
  NOMOR_LAINNYA:
    Alarm Bunyi -> Kode Tidak Terdaftar!
}`;

    navigator.clipboard?.writeText(codeText);
    setCopiedCode(true);
    audio.playClick();
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const runSimulation = () => {
    if (isSimulating) return;
    setIsSimulating(true);
    audio.playClick();

    setTimeout(() => {
      handleSelect(selectedSlot);
      setIsSimulating(false);
    }, 700);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 h-full w-full">
      {/* ========================================================= */}
      {/* SISI KIRI: CONTOH KODING INTERAKTIF & LAB COBA SENDIRI    */}
      {/* ========================================================= */}
      <div className="relative p-5 lg:p-7 flex flex-col justify-between border-b lg:border-b-0 lg:border-r-2 border-slate-900 bg-purple-50 text-slate-900 overflow-y-auto">
        <div>
          {/* Header Bab 4 */}
          <div className="flex items-center justify-between text-xs font-bold mb-1">
            <span className="bg-purple-600 text-white px-2.5 py-0.5 rounded pop-card-sm uppercase">
              BAB 04 // PEMILIHAN LANGSUNG (SWITCH - CASE)
            </span>
            <span className="font-mono text-purple-900 font-bold bg-purple-200/80 px-2 py-0.5 rounded border border-purple-400">
              KANTIN DIGITAL SEKOLAH
            </span>
          </div>

          <h2 className="text-xl lg:text-2xl font-black text-slate-950 uppercase tracking-tight mb-3">
            Koding Mesin Vending & Lab Coba Sendiri
          </h2>

          {/* ALUR PROBLEM-BASED LEARNING (PBL) */}
          <PBLStepBar chapterNum={4} onOpenPBLModal={onOpenPBLModal} />

          {/* --------------------------------------------------------- */}
          {/* SISI KIRI ATAS: CONTOH KODING INTERAKTIF (logika_vending) */}
          {/* --------------------------------------------------------- */}
          <div className="bg-slate-950 rounded-xl border-2 border-slate-900 pop-card text-white overflow-hidden mb-4 shadow-md">
            {/* Window Title Bar Mac/Terminal Style */}
            <div className="bg-slate-900 px-3 py-2 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                </div>
                <div className="flex items-center gap-1.5 ml-2 text-xs font-mono text-purple-300 font-bold">
                  <Code2 className="w-3.5 h-3.5" />
                  <span>logika_vending_machine.js</span>
                </div>
              </div>

              {/* Language Switcher & Copy Button */}
              <div className="flex items-center gap-1.5">
                <div className="flex bg-slate-950 p-0.5 rounded border border-slate-700 text-[10px] font-bold">
                  <button
                    onClick={() => {
                      audio.playClick();
                      setCodeLang('js');
                    }}
                    className={`px-2 py-0.5 rounded cursor-pointer transition-all ${
                      codeLang === 'js' ? 'bg-purple-500 text-slate-950 font-black' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    JavaScript
                  </button>
                  <button
                    onClick={() => {
                      audio.playClick();
                      setCodeLang('indo');
                    }}
                    className={`px-2 py-0.5 rounded cursor-pointer transition-all ${
                      codeLang === 'indo' ? 'bg-purple-500 text-slate-950 font-black' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Logika Manusia
                  </button>
                </div>

                <button
                  onClick={handleCopyCode}
                  className="flex items-center gap-1 text-[10px] font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 px-2 py-1 rounded border border-slate-700 cursor-pointer transition-all"
                  title="Salin Kodingan"
                >
                  <Copy className="w-3 h-3" />
                  <span>{copiedCode ? 'Tersalin! ✅' : 'Salin'}</span>
                </button>
              </div>
            </div>

            {/* Live Active Variable Indicator */}
            <div className="px-3.5 py-1.5 bg-slate-900/60 border-b border-slate-800/80 font-mono text-xs flex items-center justify-between">
              <span className="text-slate-400">
                Variabel Aktif: <span className="text-amber-400 font-bold">kodePilihan</span> ={' '}
                <span className="text-white font-black bg-purple-950 px-1.5 py-0.5 rounded border border-purple-500">
                  {selectedSlot}
                </span>
              </span>
              <span className="text-[11px] text-purple-300 font-bold">
                {selectedSlot in ITEMS ? `🎯 Ditemukan: ${ITEMS[selectedSlot].name}` : '❌ Kode Tidak Terdaftar (Default)'}
              </span>
            </div>

            {/* Code Syntax Highlight Block with Live Branch Indicator */}
            <div className="p-3 font-mono text-xs space-y-1 overflow-x-auto leading-relaxed">
              <div className="text-slate-400">
                <span className="text-purple-400">{codeLang === 'js' ? 'let' : 'VARIABEL'}</span>{' '}
                <span className="text-sky-300">kodeMakanan</span> ={' '}
                <span className="text-amber-300 font-bold">{selectedSlot}</span>;{' '}
                <span className="text-slate-500">// 🔘 Tombol Keypad Yang Ditekan</span>
              </div>

              <div className="text-purple-400 font-bold mt-1">
                {codeLang === 'js' ? 'switch (kodeMakanan) {' : 'PILIH_LANGSUNG (kodeMakanan) {'}
              </div>

              {/* CASE 1 */}
              <div
                className={`p-1.5 rounded transition-all duration-300 ${
                  selectedSlot === 1
                    ? 'bg-purple-950/90 border-l-4 border-purple-400 text-purple-100 shadow-md font-bold'
                    : 'opacity-55 text-slate-400'
                }`}
              >
                <div className="flex items-center justify-between pl-3">
                  <span>
                    <span className="text-amber-400">{codeLang === 'js' ? 'case 1:' : 'JIKA_KODE 1:'}</span>
                  </span>
                  {selectedSlot === 1 && (
                    <span className="text-[10px] bg-purple-400 text-slate-950 px-1.5 py-0.2 rounded font-black tracking-wider animate-pulse">
                      👉 DIEKSEKUSI (CASE 1)
                    </span>
                  )}
                </div>
                <div className="pl-6 text-emerald-300">
                  keluarkanMakanan(<span className="text-amber-300">"🧋 Boba Milk Tea Dingin"</span>);
                </div>
                <div className="pl-6 text-rose-400">
                  {codeLang === 'js' ? 'break;' : 'SELESAI_KELUAR (BREAK);'}
                </div>
              </div>

              {/* CASE 2 */}
              <div
                className={`p-1.5 rounded transition-all duration-300 ${
                  selectedSlot === 2
                    ? 'bg-purple-950/90 border-l-4 border-amber-400 text-purple-100 shadow-md font-bold'
                    : 'opacity-55 text-slate-400'
                }`}
              >
                <div className="flex items-center justify-between pl-3">
                  <span>
                    <span className="text-amber-400">{codeLang === 'js' ? 'case 2:' : 'JIKA_KODE 2:'}</span>
                  </span>
                  {selectedSlot === 2 && (
                    <span className="text-[10px] bg-amber-400 text-slate-950 px-1.5 py-0.2 rounded font-black tracking-wider animate-pulse">
                      👉 DIEKSEKUSI (CASE 2)
                    </span>
                  )}
                </div>
                <div className="pl-6 text-emerald-300">
                  keluarkanMakanan(<span className="text-amber-300">"🥪 Roti Bakar Cokelat"</span>);
                </div>
                <div className="pl-6 text-rose-400">
                  {codeLang === 'js' ? 'break;' : 'SELESAI_KELUAR (BREAK);'}
                </div>
              </div>

              {/* CASE 3 */}
              <div
                className={`p-1.5 rounded transition-all duration-300 ${
                  selectedSlot === 3
                    ? 'bg-purple-950/90 border-l-4 border-pink-400 text-purple-100 shadow-md font-bold'
                    : 'opacity-55 text-slate-400'
                }`}
              >
                <div className="flex items-center justify-between pl-3">
                  <span>
                    <span className="text-amber-400">{codeLang === 'js' ? 'case 3:' : 'JIKA_KODE 3:'}</span>
                  </span>
                  {selectedSlot === 3 && (
                    <span className="text-[10px] bg-pink-400 text-slate-950 px-1.5 py-0.2 rounded font-black tracking-wider animate-pulse">
                      👉 DIEKSEKUSI (CASE 3)
                    </span>
                  )}
                </div>
                <div className="pl-6 text-emerald-300">
                  keluarkanMakanan(<span className="text-amber-300">"🍦 Es Krim Sundae Tiga Scoop"</span>);
                </div>
                <div className="pl-6 text-rose-400">
                  {codeLang === 'js' ? 'break;' : 'SELESAI_KELUAR (BREAK);'}
                </div>
              </div>

              {/* CASE 4 */}
              <div
                className={`p-1.5 rounded transition-all duration-300 ${
                  selectedSlot === 4
                    ? 'bg-purple-950/90 border-l-4 border-sky-400 text-purple-100 shadow-md font-bold'
                    : 'opacity-55 text-slate-400'
                }`}
              >
                <div className="flex items-center justify-between pl-3">
                  <span>
                    <span className="text-amber-400">{codeLang === 'js' ? 'case 4:' : 'JIKA_KODE 4:'}</span>
                  </span>
                  {selectedSlot === 4 && (
                    <span className="text-[10px] bg-sky-400 text-slate-950 px-1.5 py-0.2 rounded font-black tracking-wider animate-pulse">
                      👉 DIEKSEKUSI (CASE 4)
                    </span>
                  )}
                </div>
                <div className="pl-6 text-emerald-300">
                  keluarkanMakanan(<span className="text-amber-300">"🧃 Susu Stroberi Kotak"</span>);
                </div>
                <div className="pl-6 text-rose-400">
                  {codeLang === 'js' ? 'break;' : 'SELESAI_KELUAR (BREAK);'}
                </div>
              </div>

              {/* DEFAULT */}
              <div
                className={`p-1.5 rounded transition-all duration-300 ${
                  !(selectedSlot in ITEMS)
                    ? 'bg-rose-950/90 border-l-4 border-rose-500 text-rose-100 shadow-md font-bold'
                    : 'opacity-55 text-slate-400'
                }`}
              >
                <div className="flex items-center justify-between pl-3">
                  <span>
                    <span className="text-purple-400">{codeLang === 'js' ? 'default:' : 'NOMOR_LAINNYA:'}</span>
                  </span>
                  {!(selectedSlot in ITEMS) && (
                    <span className="text-[10px] bg-rose-500 text-white px-1.5 py-0.2 rounded font-black tracking-wider animate-pulse">
                      👉 DIEKSEKUSI (DEFAULT CASE)
                    </span>
                  )}
                </div>
                <div className="pl-6 text-rose-300">
                  bunyikanAlarm(<span className="text-amber-300">"❌ Kode Tidak Ditemukan!"</span>);
                </div>
              </div>

              <div className="text-purple-400 font-bold">{'}'}</div>
            </div>

            {/* Micro Callout Bar */}
            <div className="p-2.5 bg-slate-900 border-t border-slate-800 text-[10px] text-slate-300 flex items-center gap-2">
              <Lightbulb className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>
                <strong>Keunggulan SWITCH - CASE:</strong> Komputer tidak perlu mengecek satu per satu secara berurutan. Ia langsung melompat (*direct jump*) secepat kilat ke label <code className="text-amber-300 font-bold">case {selectedSlot}</code>!
              </span>
            </div>
          </div>

          {/* --------------------------------------------------------- */}
          {/* SISI KIRI BAWAH: FITUR COBA SENDIRI (INTERAKTIF REACT JS) */}
          {/* --------------------------------------------------------- */}
          <div className="bg-white rounded-xl border-2 border-slate-900 p-4 pop-card shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="p-1 bg-purple-400 rounded border border-slate-900 text-slate-950">
                  <Sparkles className="w-3.5 h-3.5" />
                </span>
                <div>
                  <div className="text-[10px] font-black uppercase text-purple-700 tracking-wider">
                    SISI KIRI BAWAH // LAB COBA SENDIRI
                  </div>
                  <h3 className="text-sm font-black text-slate-950 uppercase">
                    Eksplorasi Keypad & Test Logika Vending!
                  </h3>
                </div>
              </div>

              {/* Status Badge */}
              <span className="text-[10px] font-mono font-black px-2 py-0.5 rounded border border-slate-900 bg-purple-200 text-purple-950">
                SLOT #{selectedSlot}
              </span>
            </div>

            <p className="text-xs text-slate-600 mb-3">
              Tekan angka tombol keypad, pilih salah satu dari 4 pesanan cepat, lalu klik tombol uji eksekusi langkah demi langkah!
            </p>

            {/* Kontrol 1: Keypad Angka & Stepper Langsung */}
            <div className="p-3 bg-purple-50 rounded-lg border-2 border-slate-900 pop-card-sm mb-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-800">
                  1. Masukkan Angka Keypad (1 - 4 atau Kode Acak):
                </span>
                <span className="font-mono text-sm font-black bg-slate-950 text-amber-300 px-2 py-0.5 rounded">
                  [ {selectedSlot} ]
                </span>
              </div>

              <div className="grid grid-cols-5 gap-1.5 mb-2">
                {[1, 2, 3, 4].map((slot) => (
                  <button
                    key={slot}
                    onClick={() => handleSelect(slot)}
                    className={`py-2 rounded font-black text-xs border-2 border-slate-900 pop-card-sm cursor-pointer transition-all flex flex-col items-center justify-center ${
                      selectedSlot === slot
                        ? 'bg-purple-600 text-white scale-105 ring-2 ring-purple-400'
                        : 'bg-white hover:bg-slate-100 text-slate-950'
                    }`}
                  >
                    <span>{ITEMS[slot].icon}</span>
                    <span className="text-[10px] mt-0.5">[ {slot} ]</span>
                  </button>
                ))}

                {/* Tombol Kode Uji Salah 9 */}
                <button
                  onClick={() => handleSelect(9)}
                  className={`py-2 rounded font-black text-xs border-2 border-slate-900 pop-card-sm cursor-pointer transition-all flex flex-col items-center justify-center ${
                    selectedSlot === 9
                      ? 'bg-rose-600 text-white scale-105 ring-2 ring-rose-400'
                      : 'bg-rose-100 hover:bg-rose-200 text-rose-950'
                  }`}
                  title="Uji Kode Salah (Memicu Default)"
                >
                  <span>⚠️</span>
                  <span className="text-[10px] mt-0.5">[ 9 ]</span>
                </button>
              </div>

              {/* Stepper & Acak */}
              <div className="flex items-center gap-1.5 pt-1 border-t border-purple-200">
                <button
                  onClick={() => handleSelect(Math.max(1, selectedSlot - 1))}
                  className="px-2 py-1 bg-white hover:bg-slate-100 rounded border border-slate-900 text-xs font-black pop-card-sm cursor-pointer"
                >
                  ◀ Slot Mundur
                </button>
                <button
                  onClick={() => handleSelect(Math.min(4, selectedSlot + 1))}
                  className="px-2 py-1 bg-white hover:bg-slate-100 rounded border border-slate-900 text-xs font-black pop-card-sm cursor-pointer"
                >
                  Slot Maju ▶
                </button>
                <button
                  onClick={() => {
                    const randomSlots = [1, 2, 3, 4, 9];
                    const picked = randomSlots[Math.floor(Math.random() * randomSlots.length)];
                    handleSelect(picked);
                  }}
                  className="flex-1 py-1 bg-amber-300 hover:bg-amber-400 text-slate-950 rounded border border-slate-900 text-xs font-black pop-card-sm flex items-center justify-center gap-1 cursor-pointer"
                >
                  <span>🎲 Pilih Acak</span>
                </button>
              </div>
            </div>

            {/* 4 Pilihan Skenario Cepat */}
            <div className="mb-3">
              <div className="text-[11px] font-bold text-slate-700 mb-1.5">
                2. Atau Pilih Uji Coba Cepat 4 Skenario Siswa:
              </div>
              <div className="grid grid-cols-2 gap-1.5 text-xs font-black">
                <button
                  onClick={() => handleSelect(1)}
                  className={`p-2 rounded border border-slate-900 text-left pop-card-sm transition-all cursor-pointer flex items-center justify-between ${
                    selectedSlot === 1 ? 'bg-purple-300 text-slate-950 font-black ring-2 ring-purple-600' : 'bg-purple-50 hover:bg-purple-100 text-slate-800'
                  }`}
                >
                  <span>🧋 1. Haus Siang (Boba Tea)</span>
                  <span className="text-[10px] font-mono bg-white px-1 rounded">CASE 1</span>
                </button>

                <button
                  onClick={() => handleSelect(2)}
                  className={`p-2 rounded border border-slate-900 text-left pop-card-sm transition-all cursor-pointer flex items-center justify-between ${
                    selectedSlot === 2 ? 'bg-amber-300 text-slate-950 font-black ring-2 ring-amber-600' : 'bg-amber-50 hover:bg-amber-100 text-slate-800'
                  }`}
                >
                  <span>🥪 2. Lapar Istirahat (Roti Keju)</span>
                  <span className="text-[10px] font-mono bg-white px-1 rounded">CASE 2</span>
                </button>

                <button
                  onClick={() => handleSelect(3)}
                  className={`p-2 rounded border border-slate-900 text-left pop-card-sm transition-all cursor-pointer flex items-center justify-between ${
                    selectedSlot === 3 ? 'bg-pink-300 text-slate-950 font-black ring-2 ring-pink-600' : 'bg-pink-50 hover:bg-pink-100 text-slate-800'
                  }`}
                >
                  <span>🍦 3. Manis Dingin (Sundae)</span>
                  <span className="text-[10px] font-mono bg-white px-1 rounded">CASE 3</span>
                </button>

                <button
                  onClick={() => handleSelect(9)}
                  className={`p-2 rounded border border-slate-900 text-left pop-card-sm transition-all cursor-pointer flex items-center justify-between ${
                    selectedSlot === 9 ? 'bg-rose-300 text-slate-950 font-black ring-2 ring-rose-600' : 'bg-rose-50 hover:bg-rose-100 text-slate-800'
                  }`}
                >
                  <span>❌ 4. Tombol Rusak (Kode [9])</span>
                  <span className="text-[10px] font-mono bg-white px-1 rounded">DEFAULT</span>
                </button>
              </div>
            </div>

            {/* Tombol Eksekusi Step-by-Step */}
            <button
              onClick={runSimulation}
              disabled={isSimulating}
              className={`w-full py-2.5 px-3 rounded-lg border-2 border-slate-900 font-black text-xs uppercase tracking-wider pop-card-sm flex items-center justify-center gap-2 cursor-pointer transition-all ${
                isSimulating ? 'bg-amber-300 animate-pulse text-slate-950' : 'bg-slate-900 hover:bg-slate-800 text-amber-300 active:translate-y-0.5'
              }`}
            >
              <Zap className="w-4 h-4 text-amber-400" />
              <span>{isSimulating ? '⚡ SEDANG MENJALANKAN SWITCH-CASE...' : '⚡ TEST & JALANKAN SWITCH-CASE (STEP-BY-STEP)'}</span>
            </button>

            {/* Terminal Output */}
            <div className="mt-2.5 p-2.5 bg-slate-950 rounded-lg border border-slate-900 text-[10px] font-mono text-emerald-400">
              <div className="flex items-center gap-1.5 text-slate-400 border-b border-slate-800 pb-1 mb-1 font-bold">
                <Terminal className="w-3 h-3 text-purple-400" />
                <span>TERMINAL HASIL EKSEKUSI REACT JS:</span>
              </div>
              <div className="text-slate-300">
                &gt; Input Kode: <span className="text-amber-300 font-bold">kodeMakanan = {selectedSlot}</span>
              </div>
              <div className="text-slate-300">
                &gt; Pencocokan Case: {selectedSlot in ITEMS ? (
                  <span className="text-emerald-400 font-bold">LOMPAT LANGSUNG KE case {selectedSlot} (MATCH FOUND)</span>
                ) : (
                  <span className="text-rose-400 font-bold">TIDAK ADA MATCH -&gt; JALANKAN BLOK default:</span>
                )}
              </div>
              <div className="text-purple-300">
                &gt; Aksi Mesin: {selectedSlot in ITEMS ? `Pegas rak #${selectedSlot} berputar 360° -> Makanan jatuh!` : 'Lampu merah berkedip & buzzer berbunyi!'}
              </div>
              <div className="text-amber-300 font-bold">
                &gt; Output: {currentItem ? `${currentItem.icon} ${currentItem.name} (${currentItem.price})` : '❌ Kode Tidak Terdaftar! Silakan tekan nomor lain.'}
              </div>
            </div>

            {/* Fitur Kustomisasi Saldo & Diskon */}
            <div className="mt-3 pt-2.5 border-t border-slate-200">
              <button
                onClick={() => {
                  audio.playClick();
                  setShowCustomRules(!showCustomRules);
                }}
                className="w-full flex items-center justify-between text-xs font-bold text-slate-700 hover:text-slate-950 p-1.5 rounded bg-slate-50 border border-slate-300 cursor-pointer"
              >
                <span className="flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-purple-600" />
                  <span>Fitur Lanjutan: Kustomisasi Saldo Koin & Promo Kantin</span>
                </span>
                <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-slate-200">
                  {showCustomRules ? 'TUTUP ▲' : 'PENGATURAN ▼'}
                </span>
              </button>

              {showCustomRules && (
                <div className="mt-2 p-2.5 bg-purple-50 rounded-lg border border-purple-300 text-xs space-y-2">
                  <div className="text-[11px] font-bold text-purple-950">
                    🛠️ Tambah Saldo atau Berikan Diskon Siswa:
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-[10px]">
                    <div>
                      <span className="block font-bold text-slate-700 mb-1">Saldo Koin Saat Ini:</span>
                      <div className="flex gap-1">
                        <button
                          onClick={() => {
                            audio.playCoinInsert();
                            setCoinsInserted((prev) => prev + 5000);
                          }}
                          className="flex-1 py-1 bg-amber-300 hover:bg-amber-400 text-slate-950 rounded font-black border border-slate-900 cursor-pointer"
                        >
                          +Rp 5.000
                        </button>
                        <button
                          onClick={() => {
                            audio.playCoinInsert();
                            setCoinsInserted((prev) => prev + 10000);
                          }}
                          className="flex-1 py-1 bg-amber-300 hover:bg-amber-400 text-slate-950 rounded font-black border border-slate-900 cursor-pointer"
                        >
                          +Rp 10.000
                        </button>
                      </div>
                    </div>
                    <div>
                      <span className="block font-bold text-slate-700 mb-1">Diskon Kupon Pelajar:</span>
                      <div className="flex gap-1">
                        <button
                          onClick={() => setCoinDiscount(0)}
                          className={`flex-1 py-1 rounded font-black border border-slate-900 cursor-pointer ${coinDiscount === 0 ? 'bg-purple-600 text-white' : 'bg-white'}`}
                        >
                          0%
                        </button>
                        <button
                          onClick={() => setCoinDiscount(2000)}
                          className={`flex-1 py-1 rounded font-black border border-slate-900 cursor-pointer ${coinDiscount === 2000 ? 'bg-purple-600 text-white' : 'bg-white'}`}
                        >
                          Rp 2.000
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Reset Bab 4 */}
        <div className="mt-3 pt-2 border-t border-slate-200 flex justify-end">
          <button
            onClick={() => {
              audio.playClick();
              setSelectedSlot(1);
              setCoinsInserted(20000);
              setCoinDiscount(0);
              handleSelect(1);
            }}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-slate-950 px-3 py-1.5 rounded border border-slate-900 bg-white pop-card-sm hover:bg-slate-50 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Bab 4</span>
          </button>
        </div>
      </div>

      {/* ========================================================= */}
      {/* SISI KANAN: PANGGUNG VISUAL RETRO VENDING MACHINE         */}
      {/* ========================================================= */}
      <div className="relative p-5 lg:p-7 flex flex-col justify-between bg-white text-slate-900 paper-bg overflow-y-auto">
        <div>
          {/* Header Panggung Kanan & Mode Switcher */}
          <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-bold mb-2">
            <span className="bg-purple-600 text-white px-2.5 py-0.5 rounded pop-card-sm uppercase">
              SISI KANAN // PANGGUNG VISUAL
            </span>

            {/* Toggle Mode: 2D Arcade Visual (Rekomendasi) vs 3D */}
            <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-lg border border-slate-950 text-[11px] font-mono shadow-sm">
              <button
                type="button"
                onClick={() => {
                  audio.playClick();
                  setVisualMode('2d');
                }}
                className={`px-2.5 py-1 rounded cursor-pointer transition-all flex items-center gap-1.5 font-black ${
                  visualMode === '2d'
                    ? 'bg-amber-400 text-slate-950 shadow-sm'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <span>🖼️ Visual 2D Arcade</span>
                <span className="text-[9px] bg-slate-950/20 px-1 rounded uppercase">Jelas & Besar</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  audio.playClick();
                  setVisualMode('3d');
                }}
                className={`px-2.5 py-1 rounded cursor-pointer transition-all flex items-center gap-1.5 font-black ${
                  visualMode === '3d'
                    ? 'bg-purple-500 text-white shadow-sm'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <span>🧊 Mode 3D Realistis</span>
              </button>
            </div>
          </div>

          <h2 className="text-xl lg:text-2xl font-black text-slate-950 uppercase tracking-tight mb-3">
            {visualMode === '2d'
              ? 'Mesin Vending 2D Interaktif & Visual Makanan Besar'
              : '3D Mesin Vending Realistis & Struk Kantin'}
          </h2>

          {/* RENDER MESIN VENDING (2D JELAS & BESAR SECARA DEFAULT ATAU 3D) */}
          <div className="mb-3.5">
            {visualMode === '2d' ? (
              <VendingMachine2D
                selectedSlot={selectedSlot}
                isDispensing={isDispensing}
                onSelectSlot={handleSelect}
                items={ITEMS}
                dispensedItem={dispensedItem}
                coinsInserted={coinsInserted}
                coinDiscount={coinDiscount}
                onInsertCoin={(amt) => {
                  audio.playCoinInsert();
                  setCoinsInserted((prev) => prev + amt);
                }}
              />
            ) : (
              <VendingMachine3D
                selectedSlot={selectedSlot}
                isDispensing={isDispensing}
                onSelectSlot={handleSelect}
                items={ITEMS}
                dispensedItem={dispensedItem}
                coinsInserted={coinsInserted}
              />
            )}
          </div>

          {/* Struk Kasir Thermal Cetak */}
          {dispensedItem && (
            <div className="p-3 bg-amber-50 border-2 border-slate-950 rounded-lg pop-card-sm mb-3.5 font-mono text-xs">
              <div className="flex justify-between border-b-2 border-dashed border-slate-400 pb-1.5 mb-1.5 font-black text-slate-950">
                <span>🧾 STRUK RESMI KANTIN DIGITAL</span>
                <span>KODE #{selectedSlot}</span>
              </div>
              <div className="flex justify-between text-slate-800">
                <span>Item: {dispensedItem.name}</span>
                <span className="font-bold">{dispensedItem.price}</span>
              </div>
              {coinDiscount > 0 && (
                <div className="flex justify-between text-rose-600 font-bold">
                  <span>Diskon Kupon Pelajar:</span>
                  <span>-Rp {coinDiscount.toLocaleString('id-ID')}</span>
                </div>
              )}
              <div className="flex justify-between text-emerald-700 font-bold border-t border-slate-300 pt-1 mt-1">
                <span>Kembalian Koin:</span>
                <span>Rp {(coinsInserted - (dispensedItem.priceNum - coinDiscount)).toLocaleString('id-ID')}</span>
              </div>
            </div>
          )}

          {/* MISI & SOAL DETEKTIF CILIK */}
          <KidMissionBox
            chapterId={4}
            missionTitle="Pesan Boba Dingin Menggunakan Tombol Keypad!"
            analogy="Sama seperti tombol lift gedung bertingkat: Jika mau ke lantai 3, kamu tekan tombol [ 3 ] dan lift langsung meluncur ke lantai 3 tanpa berhenti mengecek lantai 1 dan 2 dulu! SWITCH-CASE melompat seketika ke case nomor tujuan!"
            steps={[
              'Lihat sisi kiri atas: Perhatikan baris koding switch-case yang menyala persis di nomor case yang kamu tekan!',
              'Coba sisi kiri bawah: Tekan angka keypad [ 1 ] sampai [ 4 ] atau klik tombol [ 9 ] untuk melihat default case!',
              'Perhatikan sisi kanan: Mesin vending interaktif dengan etalase kaca, pegas berputar, makanan meluncur jatuh ke nampan dengan visual & tulisan besar, serta struk kasir thermal!'
            ]}
            question="Mengapa kita lebih memilih SWITCH-CASE daripada IF-ELSE saat membuat menu pilihan tombol angka makanan?"
            options={[
              {
                text: 'Karena komputer bisa melompat langsung ke nomor case yang ditekan tanpa mengecek satu per satu',
                correct: true,
                explanation: 'TEPAT SEKALI! ⭐ SWITCH-CASE langsung melompat tepat ke label CASE yang cocok sehingga program berjalan sangat cepat, rapi, dan mudah dibaca!'
              },
              {
                text: 'Karena SWITCH-CASE membuat jajanannya jadi gratis tanpa bayar koin',
                correct: false,
                explanation: 'Hihi salah ya! Jajanannya tetap bayar di kantin sekolah.'
              },
              {
                text: 'Karena SWITCH-CASE hanya bisa dipakai kalau cuaca sedang hujan salju',
                correct: false,
                explanation: 'Kurang tepat! SWITCH-CASE bisa dipakai kapan saja untuk menu tombol angka.'
              }
            ]}
            hasWonStar={hasWonStar}
            onEarnStar={onEarnStar}
          />
        </div>

        {/* Reset */}
        <div className="mt-3 pt-2 border-t border-slate-200 flex justify-end">
          <button
            onClick={() => handleSelect(1)}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-slate-950 px-3 py-1.5 rounded border border-slate-900 bg-white pop-card-sm hover:bg-slate-50 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset ke Slot 1</span>
          </button>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 8. SPREAD 5: MULTI-KONDISI (ROLLER COASTER)
// ==========================================
function RollerCoasterGateSpread({
  hasWonStar,
  onEarnStar,
  onOpenPBLModal
}: {
  hasWonStar: boolean;
  onEarnStar: () => void;
  onOpenPBLModal: () => void;
}) {
  const [height, setHeight] = useState<number>(128);
  const [hasTicket, setHasTicket] = useState<boolean>(true);
  const [operatorMode, setOperatorMode] = useState<'AND' | 'OR'>('AND');
  const [cartLaunched, setCartLaunched] = useState<boolean>(false);
  const [codeLang, setCodeLang] = useState<'js' | 'indo'>('js');
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [minHeight, setMinHeight] = useState<number>(120);
  const [showCustomRules, setShowCustomRules] = useState<boolean>(false);

  const isHeightValid = height >= minHeight;

  const isApproved = useMemo(() => {
    if (operatorMode === 'AND') {
      return isHeightValid && hasTicket;
    } else {
      return isHeightValid || hasTicket;
    }
  }, [isHeightValid, hasTicket, operatorMode]);

  const handleTestRide = () => {
    if (isApproved) {
      audio.playCoaster();
      setCartLaunched(true);
      setTimeout(() => setCartLaunched(false), 2400);
    } else {
      audio.playBuzzer();
    }
  };

  const handleCopyCode = () => {
    const codeText = codeLang === 'js'
      ? `// Logika Gerbang Roller Coaster Multi-Syarat
let tinggiBadan = ${height}; // cm
let punyaTiket = ${hasTicket};
let batasTinggi = ${minHeight};

if (tinggiBadan >= batasTinggi ${operatorMode === 'AND' ? '&&' : '||'} punyaTiket === true) {
  // Gerbang Terbuka Hijau!
  bukaGerbangTurnstile();
  luncurkanKeretaWahana();
} else {
  // Gerbang Terkunci Merah!
  kunciGerbangTurnstile();
  tampilkanPeringatan("Syarat belum cukup!");
}`
      : `// Logika Multi-Syarat Wahana Roller Coaster
TINGGI_BADAN = ${height} cm;
PUNYA_TIKET = ${hasTicket ? 'BENAR (ADA)' : 'SALAH (TIDAK ADA)'};

JIKA (TINGGI_BADAN >= ${minHeight} ${operatorMode === 'AND' ? 'DAN' : 'ATAU'} PUNYA_TIKET == BENAR) MAKA:
  Buka Gerbang Hijau & Kereta Meluncur Wuuusshh!
SELAIN ITU (ELSE):
  Kunci Gerbang Merah & Bunyikan Buzzer!`;

    navigator.clipboard?.writeText(codeText);
    setCopiedCode(true);
    audio.playClick();
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const runSimulation = () => {
    if (isSimulating) return;
    setIsSimulating(true);
    audio.playClick();

    setTimeout(() => {
      handleTestRide();
      setIsSimulating(false);
    }, 700);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 h-full w-full">
      {/* ========================================================= */}
      {/* SISI KIRI: CONTOH KODING INTERAKTIF & LAB COBA SENDIRI    */}
      {/* ========================================================= */}
      <div className="relative p-5 lg:p-7 flex flex-col justify-between border-b lg:border-b-0 lg:border-r-2 border-slate-900 bg-rose-50 text-slate-900 overflow-y-auto">
        <div>
          {/* Header Bab 5 */}
          <div className="flex items-center justify-between text-xs font-bold mb-1">
            <span className="bg-rose-600 text-white px-2.5 py-0.5 rounded pop-card-sm uppercase">
              BAB 05 // LOGIKA MULTI-SYARAT (&& DAN ||)
            </span>
            <span className="font-mono text-rose-900 font-bold bg-rose-200/80 px-2 py-0.5 rounded border border-rose-400">
              DUFAN THRILL PARK
            </span>
          </div>

          <h2 className="text-xl lg:text-2xl font-black text-slate-950 uppercase tracking-tight mb-3">
            Koding Gerbang Wahana & Lab Coba Sendiri
          </h2>

          {/* ALUR PROBLEM-BASED LEARNING (PBL) */}
          <PBLStepBar chapterNum={5} onOpenPBLModal={onOpenPBLModal} />

          {/* --------------------------------------------------------- */}
          {/* SISI KIRI ATAS: CONTOH KODING INTERAKTIF (logika_coaster) */}
          {/* --------------------------------------------------------- */}
          <div className="bg-slate-950 rounded-xl border-2 border-slate-900 pop-card text-white overflow-hidden mb-4 shadow-md">
            {/* Window Title Bar */}
            <div className="bg-slate-900 px-3 py-2 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <div className="flex gap-1.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-500" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                </div>
                <div className="flex items-center gap-1.5 ml-2 text-xs font-mono text-rose-300 font-bold">
                  <Code2 className="w-3.5 h-3.5" />
                  <span>logika_roller_coaster.js</span>
                </div>
              </div>

              {/* Language Switcher & Copy */}
              <div className="flex items-center gap-1.5">
                <div className="flex bg-slate-950 p-0.5 rounded border border-slate-700 text-[10px] font-bold">
                  <button
                    onClick={() => {
                      audio.playClick();
                      setCodeLang('js');
                    }}
                    className={`px-2 py-0.5 rounded cursor-pointer transition-all ${
                      codeLang === 'js' ? 'bg-rose-500 text-white font-black' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    JavaScript
                  </button>
                  <button
                    onClick={() => {
                      audio.playClick();
                      setCodeLang('indo');
                    }}
                    className={`px-2 py-0.5 rounded cursor-pointer transition-all ${
                      codeLang === 'indo' ? 'bg-rose-500 text-white font-black' : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Logika Manusia
                  </button>
                </div>

                <button
                  onClick={handleCopyCode}
                  className="flex items-center gap-1 text-[10px] font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 px-2 py-1 rounded border border-slate-700 cursor-pointer transition-all"
                  title="Salin Kodingan"
                >
                  <Copy className="w-3 h-3" />
                  <span>{copiedCode ? 'Tersalin! ✅' : 'Salin'}</span>
                </button>
              </div>
            </div>

            {/* Live Active Variables Indicator */}
            <div className="px-3.5 py-1.5 bg-slate-900/60 border-b border-slate-800/80 font-mono text-xs flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-slate-400">
                  tinggi: <span className={isHeightValid ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>{height}cm</span>
                </span>
                <span className="text-slate-400">
                  tiket: <span className={hasTicket ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>{hasTicket ? 'true' : 'false'}</span>
                </span>
                <span className="text-slate-400">
                  op: <span className="text-amber-400 font-bold">{operatorMode === 'AND' ? '&& (DAN)' : '|| (ATAU)'}</span>
                </span>
              </div>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded border ${
                isApproved ? 'bg-emerald-950 text-emerald-300 border-emerald-500' : 'bg-rose-950 text-rose-300 border-rose-500'
              }`}>
                {isApproved ? '✅ LOLOS MASUK' : '🛑 GERBANG TERKUNCI'}
              </span>
            </div>

            {/* Code Syntax Highlight Block */}
            <div className="p-3 font-mono text-xs space-y-1 overflow-x-auto leading-relaxed">
              <div className="text-slate-400">
                <span className="text-purple-400">{codeLang === 'js' ? 'const' : 'ATURAN'}</span>{' '}
                <span className="text-sky-300">tinggiBadan</span> ={' '}
                <span className="text-amber-300 font-bold">{height}</span>;{' '}
                <span className="text-slate-500">// cm</span>
              </div>
              <div className="text-slate-400">
                <span className="text-purple-400">{codeLang === 'js' ? 'const' : 'ATURAN'}</span>{' '}
                <span className="text-sky-300">punyaTiket</span> ={' '}
                <span className="text-emerald-300 font-bold">{hasTicket ? 'true' : 'false'}</span>;
              </div>

              {/* JALUR IF (LOLOS) */}
              <div
                className={`p-2 rounded transition-all duration-300 mt-1 ${
                  isApproved
                    ? 'bg-emerald-950/90 border-l-4 border-emerald-400 text-emerald-100 shadow-md font-bold'
                    : 'opacity-55 text-slate-400'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span>
                    <span className="text-purple-400">{codeLang === 'js' ? 'if (' : 'JIKA ('}</span>
                    <span className={isHeightValid ? 'text-emerald-300 font-bold' : 'text-rose-300 font-bold'}>
                      tinggiBadan &gt;= {minHeight}
                    </span>{' '}
                    <span className="text-amber-400 font-black">
                      {codeLang === 'js' ? (operatorMode === 'AND' ? '&&' : '||') : (operatorMode === 'AND' ? 'DAN' : 'ATAU')}
                    </span>{' '}
                    <span className={hasTicket ? 'text-emerald-300 font-bold' : 'text-rose-300 font-bold'}>
                      punyaTiket === true
                    </span>
                    <span className="text-purple-400">) {'{'}</span>
                  </span>
                  {isApproved && (
                    <span className="text-[10px] bg-emerald-400 text-slate-950 px-1.5 py-0.2 rounded font-black tracking-wider animate-pulse">
                      👉 DIEKSEKUSI (TRUE)
                    </span>
                  )}
                </div>
                <div className="pl-4 text-emerald-300">
                  bukaGerbangTurnstile();
                </div>
                <div className="pl-4 text-amber-300">
                  luncurkanKeretaRollerCoaster(<span className="text-emerald-300">"Wuuusshh! 🎢"</span>);
                </div>
                <div>{'}'}</div>
              </div>

              {/* JALUR ELSE (DITOLAK) */}
              <div
                className={`p-2 rounded transition-all duration-300 ${
                  !isApproved
                    ? 'bg-rose-950/90 border-l-4 border-rose-400 text-rose-100 shadow-md font-bold'
                    : 'opacity-55 text-slate-400'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span>
                    <span className="text-purple-400">{codeLang === 'js' ? '} else {' : '} SELAIN ITU {'}</span>
                  </span>
                  {!isApproved && (
                    <span className="text-[10px] bg-rose-400 text-white px-1.5 py-0.2 rounded font-black tracking-wider animate-pulse">
                      👉 DIEKSEKUSI (FALSE)
                    </span>
                  )}
                </div>
                <div className="pl-4 text-rose-300">
                  kunciGerbangMerah();
                </div>
                <div className="pl-4 text-rose-300">
                  bunyikanBuzzer(<span className="text-amber-300">"🛑 Syarat Masuk Belum Terpenuhi!"</span>);
                </div>
                <div>{'}'}</div>
              </div>
            </div>

            {/* Micro Callout Bar */}
            <div className="p-2.5 bg-slate-900 border-t border-slate-800 text-[10px] text-slate-300 flex items-center gap-2">
              <Lightbulb className="w-3.5 h-3.5 text-amber-400 shrink-0" />
              <span>
                <strong>Aturan Logika:</strong> Operator <strong className="text-rose-400">&& (DAN)</strong> mewajibkan <em>KEDUA</em> syarat bernilai BENAR. Sedangkan operator <strong className="text-sky-400">|| (ATAU)</strong> cukup jika <em>SALAH SATU</em> bernilai BENAR!
              </span>
            </div>
          </div>

          {/* --------------------------------------------------------- */}
          {/* SISI KIRI BAWAH: FITUR COBA SENDIRI (INTERAKTIF REACT JS) */}
          {/* --------------------------------------------------------- */}
          <div className="bg-white rounded-xl border-2 border-slate-900 p-4 pop-card shadow-sm">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="p-1 bg-rose-400 rounded border border-slate-900 text-slate-950">
                  <Sparkles className="w-3.5 h-3.5" />
                </span>
                <div>
                  <div className="text-[10px] font-black uppercase text-rose-700 tracking-wider">
                    SISI KIRI BAWAH // LAB COBA SENDIRI
                  </div>
                  <h3 className="text-sm font-black text-slate-950 uppercase">
                    Eksplorasi Syarat Tinggi & Operator Logika!
                  </h3>
                </div>
              </div>

              {/* Status Badge */}
              <span className={`text-[10px] font-mono font-black px-2 py-0.5 rounded border border-slate-900 ${
                isApproved ? 'bg-emerald-300 text-emerald-950' : 'bg-rose-300 text-rose-950'
              }`}>
                STATUS: {isApproved ? 'TERBUKA' : 'TERKUNCI'}
              </span>
            </div>

            <p className="text-xs text-slate-600 mb-3">
              Ubah tinggi badan, nyalakan tiket, pilih operator && atau ||, lalu klik tombol uji eksekusi langkah demi langkah!
            </p>

            {/* Kontrol 1: Input Tinggi & Stepper */}
            <div className="p-3 bg-rose-50 rounded-lg border-2 border-slate-900 pop-card-sm mb-3">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-bold text-slate-800">
                  1. Masukkan Tinggi Anak Sendiri (Batas: {minHeight} cm):
                </span>
                <span className={`font-mono text-sm font-black px-2 py-0.5 rounded border ${
                  isHeightValid ? 'bg-emerald-100 text-emerald-800 border-emerald-400' : 'bg-rose-100 text-rose-800 border-rose-400'
                }`}>
                  {height} cm {isHeightValid ? '✅' : '❌'}
                </span>
              </div>

              <div className="flex items-center gap-2 mb-2">
                <input
                  type="number"
                  min={80}
                  max={170}
                  value={height}
                  onChange={(e) => setHeight(Number(e.target.value))}
                  className="w-20 px-2 py-1.5 bg-white border-2 border-slate-900 rounded font-mono text-sm font-black text-center pop-card-sm focus:outline-none focus:ring-2 focus:ring-rose-500"
                />

                <div className="flex items-center gap-1 flex-1">
                  <button
                    onClick={() => setHeight((h) => Math.max(80, h - 5))}
                    className="px-2 py-1.5 bg-slate-200 hover:bg-slate-300 rounded border border-slate-900 text-xs font-black pop-card-sm cursor-pointer"
                    title="Turunkan 5 cm"
                  >
                    -5cm
                  </button>
                  <button
                    onClick={() => setHeight((h) => Math.max(80, h - 1))}
                    className="px-2 py-1.5 bg-slate-200 hover:bg-slate-300 rounded border border-slate-900 text-xs font-black pop-card-sm cursor-pointer"
                    title="Turunkan 1 cm"
                  >
                    -1cm
                  </button>
                  <button
                    onClick={() => setHeight((h) => Math.min(170, h + 1))}
                    className="px-2 py-1.5 bg-slate-200 hover:bg-slate-300 rounded border border-slate-900 text-xs font-black pop-card-sm cursor-pointer"
                    title="Naikkan 1 cm"
                  >
                    +1cm
                  </button>
                  <button
                    onClick={() => setHeight((h) => Math.min(170, h + 5))}
                    className="px-2 py-1.5 bg-slate-200 hover:bg-slate-300 rounded border border-slate-900 text-xs font-black pop-card-sm cursor-pointer"
                    title="Naikkan 5 cm"
                  >
                    +5cm
                  </button>
                  <button
                    onClick={() => {
                      const randomHeights = [95, 115, 122, 135, 145];
                      setHeight(randomHeights[Math.floor(Math.random() * randomHeights.length)]);
                    }}
                    className="flex-1 py-1.5 bg-amber-300 hover:bg-amber-400 text-slate-950 rounded border border-slate-900 text-xs font-black pop-card-sm flex items-center justify-center gap-1 cursor-pointer"
                  >
                    <span>🎲 Acak</span>
                  </button>
                </div>
              </div>

              {/* Kontrol 2: Saklar Tiket & Pilihan Operator */}
              <div className="grid grid-cols-2 gap-2 pt-2 border-t border-rose-200">
                <button
                  onClick={() => {
                    audio.playClick();
                    setHasTicket(!hasTicket);
                  }}
                  className={`p-2 rounded border-2 border-slate-900 font-bold text-xs pop-card-sm cursor-pointer transition-all flex items-center justify-between ${
                    hasTicket ? 'bg-emerald-100 text-emerald-950 font-black' : 'bg-rose-100 text-rose-950 font-black'
                  }`}
                >
                  <span>2. Tiket Gelang:</span>
                  <span>{hasTicket ? '🎟️ ADA (TRUE)' : '❌ TIDAK ADA'}</span>
                </button>

                <div className="flex bg-slate-100 p-0.5 rounded-lg border-2 border-slate-900">
                  <button
                    onClick={() => {
                      audio.playClick();
                      setOperatorMode('AND');
                    }}
                    className={`flex-1 py-1.5 text-xs font-black rounded cursor-pointer transition-all ${
                      operatorMode === 'AND'
                        ? 'bg-slate-900 text-amber-300 pop-card-sm'
                        : 'text-slate-700 hover:text-slate-950'
                    }`}
                  >
                    && (DAN)
                  </button>
                  <button
                    onClick={() => {
                      audio.playClick();
                      setOperatorMode('OR');
                    }}
                    className={`flex-1 py-1.5 text-xs font-black rounded cursor-pointer transition-all ${
                      operatorMode === 'OR'
                        ? 'bg-slate-900 text-amber-300 pop-card-sm'
                        : 'text-slate-700 hover:text-slate-950'
                    }`}
                  >
                    || (ATAU)
                  </button>
                </div>
              </div>
            </div>

            {/* 4 Pilihan Skenario Uji Cepat */}
            <div className="mb-3">
              <div className="text-[11px] font-bold text-slate-700 mb-1.5">
                3. Atau Pilih Uji Coba Cepat 4 Skenario Pengunjung:
              </div>
              <div className="grid grid-cols-2 gap-1.5 text-xs font-black">
                <button
                  onClick={() => {
                    audio.playClick();
                    setHeight(135);
                    setHasTicket(true);
                    setOperatorMode('AND');
                  }}
                  className="p-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-950 rounded border border-slate-900 pop-card-sm cursor-pointer text-left"
                >
                  🌟 1. Lolos Penuh (135cm, Tiket Ada)
                </button>
                <button
                  onClick={() => {
                    audio.playClick();
                    setHeight(108);
                    setHasTicket(true);
                    setOperatorMode('AND');
                  }}
                  className="p-1.5 bg-amber-100 hover:bg-amber-200 text-amber-950 rounded border border-slate-900 pop-card-sm cursor-pointer text-left"
                >
                  ⚠️ 2. Kurang Tinggi (108cm, Ada Tiket)
                </button>
                <button
                  onClick={() => {
                    audio.playClick();
                    setHeight(132);
                    setHasTicket(false);
                    setOperatorMode('AND');
                  }}
                  className="p-1.5 bg-amber-100 hover:bg-amber-200 text-amber-950 rounded border border-slate-900 pop-card-sm cursor-pointer text-left"
                >
                  🎫 3. Tanpa Tiket (132cm, Tiket ✕)
                </button>
                <button
                  onClick={() => {
                    audio.playClick();
                    setHeight(132);
                    setHasTicket(false);
                    setOperatorMode('OR');
                  }}
                  className="p-1.5 bg-sky-100 hover:bg-sky-200 text-sky-950 rounded border border-slate-900 pop-card-sm cursor-pointer text-left"
                >
                  💡 4. Uji Operator || (Cukup 1 Syarat)
                </button>
              </div>
            </div>

            {/* Tombol Eksekusi Step-by-Step */}
            <button
              onClick={runSimulation}
              disabled={isSimulating}
              className={`w-full py-2.5 px-3 rounded-lg border-2 border-slate-900 font-black text-xs uppercase tracking-wider pop-card-sm flex items-center justify-center gap-2 cursor-pointer transition-all ${
                isSimulating ? 'bg-amber-300 animate-pulse text-slate-950' : 'bg-slate-900 hover:bg-slate-800 text-amber-300 active:translate-y-0.5'
              }`}
            >
              <Zap className="w-4 h-4 text-amber-400" />
              <span>{isSimulating ? '⚡ SEDANG MENGEVALUASI GERBANG...' : '⚡ TEST & JALANKAN GERBANG (STEP-BY-STEP)'}</span>
            </button>

            {/* Terminal Output */}
            <div className="mt-2.5 p-2.5 bg-slate-950 rounded-lg border border-slate-900 text-[10px] font-mono text-emerald-400">
              <div className="flex items-center gap-1.5 text-slate-400 border-b border-slate-800 pb-1 mb-1 font-bold">
                <Terminal className="w-3 h-3 text-rose-400" />
                <span>TERMINAL HASIL EKSEKUSI REACT JS:</span>
              </div>
              <div className="text-slate-300">
                &gt; Syarat 1 (Tinggi): {height} &gt;= {minHeight} ? <span className={isHeightValid ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>{isHeightValid ? 'LOLOS (TRUE)' : 'KURANG (FALSE)'}</span>
              </div>
              <div className="text-slate-300">
                &gt; Syarat 2 (Tiket): <span className={hasTicket ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>{hasTicket ? 'ADA GELANG (TRUE)' : 'TIDAK ADA (FALSE)'}</span>
              </div>
              <div className="text-slate-300">
                &gt; Operasi {operatorMode === 'AND' ? '&& (DAN)' : '|| (ATAU)'}: <span className={isApproved ? 'text-emerald-400 font-bold' : 'text-rose-400 font-bold'}>{isApproved ? 'HASIL KESELURUHAN: TRUE' : 'HASIL KESELURUHAN: FALSE'}</span>
              </div>
              <div className={isApproved ? 'text-emerald-300 font-bold' : 'text-rose-300 font-bold'}>
                &gt; KEPUTUSAN: {isApproved ? 'MEMASUKI BLOK IF -> GERBANG TERBUKA & KERETA MELUNCUR! 🎢' : 'MEMASUKI BLOK ELSE -> GERBANG TERKUNCI & BUZZER BERBUNYI! 🛑'}
              </div>
            </div>

            {/* Kustomisasi Batas Tinggi Minimal */}
            <div className="mt-3 pt-2.5 border-t border-slate-200">
              <button
                onClick={() => {
                  audio.playClick();
                  setShowCustomRules(!showCustomRules);
                }}
                className="w-full flex items-center justify-between text-xs font-bold text-slate-700 hover:text-slate-950 p-1.5 rounded bg-slate-50 border border-slate-300 cursor-pointer"
              >
                <span className="flex items-center gap-1.5">
                  <Sliders className="w-3.5 h-3.5 text-rose-600" />
                  <span>Fitur Lanjutan: Kustomisasi Standar Tinggi Wahana</span>
                </span>
                <span className="text-[10px] font-black px-1.5 py-0.5 rounded bg-slate-200">
                  {showCustomRules ? 'TUTUP ▲' : 'UBAH BATAS ▼'}
                </span>
              </button>

              {showCustomRules && (
                <div className="mt-2 p-2 bg-rose-50 rounded border border-rose-300 text-xs flex items-center justify-between">
                  <span>Pilih Batas Minimal Wahana:</span>
                  <div className="flex gap-1">
                    {[110, 120, 130].map((val) => (
                      <button
                        key={val}
                        onClick={() => {
                          audio.playClick();
                          setMinHeight(val);
                        }}
                        className={`px-2 py-0.5 rounded border border-slate-900 text-xs font-bold ${minHeight === val ? 'bg-rose-500 text-white' : 'bg-white'}`}
                      >
                        {val} cm
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Reset Bab 5 */}
        <div className="mt-3 pt-2 border-t border-slate-200 flex justify-end">
          <button
            onClick={() => {
              audio.playClick();
              setHeight(128);
              setHasTicket(true);
              setOperatorMode('AND');
              setMinHeight(120);
            }}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-slate-950 px-3 py-1.5 rounded border border-slate-900 bg-white pop-card-sm hover:bg-slate-50 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Bab 5</span>
          </button>
        </div>
      </div>

      {/* ========================================================= */}
      {/* SISI KANAN: PANGGUNG VISUAL ROLLER COASTER DUFAN          */}
      {/* ========================================================= */}
      <div className="relative p-5 lg:p-7 flex flex-col justify-between bg-white text-slate-900 paper-bg overflow-y-auto">
        <div>
          {/* Header Panggung Kanan */}
          <div className="flex items-center justify-between text-xs font-bold mb-1">
            <span className="bg-rose-600 text-white px-2.5 py-0.5 rounded pop-card-sm uppercase">
              SISI KANAN // PANGGUNG VISUAL
            </span>
            <span className="font-mono text-slate-700 font-bold">
              100% GAMBAR BERGERAK
            </span>
          </div>

          <h2 className="text-xl lg:text-2xl font-black text-slate-950 uppercase tracking-tight mb-3">
            Gerbang Halilintar Extreme & Lintasan 3D
          </h2>

          {/* Area Simulasi Grafis Roller Coaster */}
          <div className="relative w-full h-64 lg:h-72 bg-gradient-to-b from-sky-400 via-sky-200 to-emerald-200 rounded-xl border-3 border-slate-950 pop-card overflow-hidden mb-3.5">
            {/* Rel Roller Coaster SVG Vektor */}
            <svg className="absolute inset-0 w-full h-full pointer-events-none" viewBox="0 0 300 200">
              <line x1="40" y1="90" x2="40" y2="180" stroke="#0f172a" strokeWidth="2" />
              <line x1="120" y1="50" x2="120" y2="180" stroke="#0f172a" strokeWidth="2" />
              <line x1="200" y1="70" x2="200" y2="180" stroke="#0f172a" strokeWidth="2" />
              <line x1="280" y1="110" x2="280" y2="180" stroke="#0f172a" strokeWidth="2" />

              <path
                d="M 0 110 Q 70 30 130 60 T 260 80 Q 290 90 320 120"
                fill="none"
                stroke="#ef4444"
                strokeWidth="5"
              />
              <path
                d="M 0 114 Q 70 34 130 64 T 260 84 Q 290 94 320 124"
                fill="none"
                stroke="#0f172a"
                strokeWidth="1.5"
              />
            </svg>

            {/* Kereta Roller Coaster Meluncur */}
            <div
              className={`absolute top-8 transition-all duration-1000 ease-in-out ${
                cartLaunched ? 'left-[105%] scale-110' : 'left-[35%] scale-100'
              }`}
            >
              <div className="relative flex items-center">
                <div className="w-16 h-9 bg-amber-400 border-2 border-slate-950 rounded-lg flex items-center justify-around pop-card-sm text-xs font-black shadow-lg">
                  <span className="text-base">🎢</span>
                  <span className="text-[10px] bg-slate-950 text-amber-300 px-1 py-0.5 rounded">#01</span>
                </div>
                {cartLaunched && (
                  <div className="absolute -left-12 text-xs font-black text-red-600 animate-ping">
                    Wuuusshh! 💨
                  </div>
                )}
              </div>
            </div>

            {/* Lantai & Gerbang Antrean */}
            <div className="absolute bottom-0 left-0 right-0 h-28 bg-slate-200 border-t-2 border-slate-900 flex items-end justify-between px-4 pb-2">
              {/* Tiang Pengukur Tinggi & Avatar Anak */}
              <div className="relative flex items-end gap-2">
                <div className="w-7 h-24 bg-amber-300 border-2 border-slate-950 rounded-t flex flex-col justify-between py-1 items-center font-mono text-[8px] font-bold">
                  <span>160</span>
                  <div className="w-full h-1 bg-red-600 shadow-[0_0_6px_#ef4444]" />
                  <span>{minHeight}</span>
                  <span>80</span>
                </div>

                <div
                  className="relative flex flex-col items-center transition-all duration-200"
                  style={{
                    height: `${(height / 160) * 85}px`
                  }}
                >
                  {hasTicket && (
                    <div className="absolute top-8 -right-1.5 w-3 h-2 bg-emerald-500 rounded border border-slate-900 shadow-sm font-bold text-[6px] text-white flex items-center justify-center">
                      🎟️
                    </div>
                  )}
                  <div className="w-6 h-6 rounded-full bg-amber-200 border-2 border-slate-950 flex items-center justify-center text-[11px]">
                    {isApproved ? '🤩' : height < minHeight ? '🥺' : '😕'}
                  </div>
                  <div className="w-5 flex-1 bg-blue-500 border border-slate-950 rounded-t-sm" />
                  <div className="w-5 h-4 flex justify-between">
                    <div className="w-2 h-full bg-slate-900" />
                    <div className="w-2 h-full bg-slate-900" />
                  </div>
                </div>
              </div>

              {/* Gerbang Turnstile Besi */}
              <div className="flex flex-col items-center">
                <div className={`w-7 h-7 rounded-full border-2 border-slate-950 flex items-center justify-center font-bold text-xs ${
                  isApproved
                    ? 'bg-emerald-400 text-slate-950 shadow-[0_0_12px_#10b981] animate-pulse'
                    : 'bg-rose-500 text-white shadow-[0_0_12px_#ef4444]'
                }`}>
                  {isApproved ? '✓' : '✕'}
                </div>

                <div className="w-16 h-16 bg-slate-700 border-2 border-slate-950 rounded-t-md relative flex items-center justify-center shadow-md">
                  <div
                    className={`w-14 h-3 rounded border border-slate-950 transition-all duration-300 ${
                      isApproved
                        ? 'bg-emerald-400 rotate-45 translate-x-2'
                        : 'bg-rose-400 rotate-0'
                    }`}
                  />
                </div>
                <div className="text-[10px] font-black text-slate-800 uppercase mt-0.5">
                  {isApproved ? 'GERBANG DIBUKA' : 'GERBANG TERKUNCI'}
                </div>
              </div>
            </div>
          </div>

          {/* Tombol Aksi Cepat Luncurkan */}
          <button
            onClick={handleTestRide}
            className={`w-full py-2.5 px-4 font-black text-xs uppercase tracking-wider rounded-lg border-2 border-slate-950 pop-card transition-all active:translate-y-0.5 cursor-pointer mb-3.5 flex items-center justify-center gap-2 ${
              isApproved
                ? 'bg-emerald-400 hover:bg-emerald-300 text-slate-950'
                : 'bg-rose-500 hover:bg-rose-400 text-white'
            }`}
          >
            {isApproved ? '🎢 [ GERBANG DIBUKA: LUNCURKAN KERETA WUUUSSHH! ]' : '🛑 [ GERBANG TERKUNCI: SYARAT BELUM CUKUP ]'}
          </button>

          {/* MISI & SOAL DETEKTIF CILIK */}
          <KidMissionBox
            chapterId={5}
            missionTitle="Tembus Gerbang Roller Coaster Halilintar!"
            analogy="Operator && (DAN) itu seperti izin bermain game: PR harus selesai DAN kamar harus rapi (keduanya wajib). Sedangkan || (ATAU) seperti sarapan: boleh makan roti ATAU makan nasi goreng (satu saja sudah cukup)!"
            steps={[
              'Lihat sisi kiri atas: Perhatikan bagaimana baris koding IF mengevaluasi && (keduanya wajib) vs || (salah satu cukup)!',
              'Coba sisi kiri bawah: Masukkan angka tinggimu sendiri, nyalakan tiket gelang, atau coba tombol skenario cepat!',
              'Perhatikan sisi kanan: Badan avatar memanjang mengikuti slider tinggi dan gerbang turnstile berputar terbuka hijau!'
            ]}
            question="Jika tinggi anak 135 cm (SUDAH TINGGI) tapi dia LUPA membawa tiket gelang (FALSE), apakah gerbang terbuka jika memakai operator && (DAN)?"
            options={[
              {
                text: 'Gerbang TERBUKA karena badannya sudah cukup tinggi melebihi batas',
                correct: false,
                explanation: 'Belum tepat! Operator && mewajibkan KEDUA syarat terpenuhi, jadi tiket tetap wajib ada.'
              },
              {
                text: 'Gerbang TERKUNCI MERAH karena tiketnya belum ada!',
                correct: true,
                explanation: 'HEBAT LUAR BIASA! ⭐ Pada operator && (DAN), jika salah satu syarat bernilai FALSE, seluruh hasil menjadi FALSE dan gerbang tetap terkunci!'
              },
              {
                text: 'Gerbangnya berubah menjadi sepeda ontel',
                correct: false,
                explanation: 'Hihi salah ya! Gerbangnya tetap gerbang turnstile wahana.'
              }
            ]}
            hasWonStar={hasWonStar}
            onEarnStar={onEarnStar}
          />
        </div>

        {/* Reset */}
        <div className="mt-3 pt-2 border-t border-slate-200 flex justify-end">
          <button
            onClick={() => {
              audio.playClick();
              setHeight(128);
              setHasTicket(true);
              setOperatorMode('AND');
              setMinHeight(120);
            }}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-700 hover:text-slate-950 px-3 py-1.5 rounded border border-slate-900 bg-white pop-card-sm hover:bg-slate-50 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Bab 5</span>
          </button>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 8.5. KOMPONEN PROBLEM-BASED LEARNING (PBL)
// ==========================================
function PBLStepBar({
  chapterNum,
  onOpenPBLModal
}: {
  chapterNum: number;
  onOpenPBLModal: () => void;
}) {
  const [activeTip, setActiveTip] = useState<number | null>(null);

  const PHASES = [
    { num: 1, title: 'Orientasi Masalah', desc: 'Pahami dilema masalah nyata di panggung visual sebelah kanan.' },
    { num: 2, title: 'Identifikasi Syarat', desc: 'Kenali variabel data & aturan logika percabangan di editor kode.' },
    { num: 3, title: 'Penyelidikan Lab', desc: 'Eksperimen bebas & uji skenario ekstrem di Lab Coba Sendiri.' },
    { num: 4, title: 'Solusi Algoritma', desc: 'Jalankan eksekusi langkah kode & amati respon terminal sistem.' },
    { num: 5, title: 'Evaluasi & Refleksi', desc: 'Pecahkan kuis refleksi detektif & buktikan pemahaman logikamu!' },
  ];

  return (
    <div className="mb-3 p-2.5 bg-gradient-to-r from-amber-100 via-sky-50 to-emerald-100 rounded-xl border-2 border-slate-900 pop-card-sm shadow-sm">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 pb-1.5 border-b border-slate-300">
        <div className="flex items-center gap-1.5 text-[11px] font-black text-slate-950">
          <span className="p-1 bg-amber-400 rounded border border-slate-900 text-slate-950 text-xs leading-none shadow-xs">
            🧭
          </span>
          <span className="uppercase tracking-tight">ALUR PROBLEM-BASED LEARNING (PBL) // BAB {chapterNum}</span>
        </div>

        <button
          onClick={() => {
            audio.playClick();
            onOpenPBLModal();
          }}
          className="text-[10px] font-black bg-slate-950 hover:bg-slate-800 text-amber-300 px-2.5 py-1 rounded border border-slate-900 pop-card-sm cursor-pointer flex items-center gap-1.5 shrink-0 self-start sm:self-auto transition-transform active:scale-95"
        >
          <ClipboardList className="w-3 h-3 text-amber-400" />
          <span>Panduan Sintaks PBL & LKPD</span>
        </button>
      </div>

      <div className="mt-2 grid grid-cols-5 gap-1 text-[9px] font-mono font-bold">
        {PHASES.map((p) => (
          <button
            key={p.num}
            onClick={() => {
              audio.playClick();
              setActiveTip(activeTip === p.num ? null : p.num);
            }}
            className={`p-1 rounded border text-center transition-all cursor-pointer ${
              activeTip === p.num
                ? 'bg-amber-400 text-slate-950 border-slate-950 font-black shadow-sm scale-102 ring-2 ring-amber-500'
                : 'bg-white hover:bg-slate-100 border-slate-900 text-slate-800'
            }`}
            title={p.desc}
          >
            <div className="text-[7.5px] text-slate-500 font-sans font-bold">Fase {p.num}</div>
            <div className="truncate font-black">{p.title}</div>
          </button>
        ))}
      </div>

      {activeTip !== null && (
        <div className="mt-2 p-2 bg-white rounded-lg border-2 border-slate-900 text-[10px] font-sans font-semibold text-slate-800 flex items-center justify-between shadow-sm animate-fadeIn">
          <span>
            💡 <strong>Fase {activeTip} ({PHASES[activeTip - 1].title}):</strong> {PHASES[activeTip - 1].desc}
          </span>
          <button
            onClick={() => setActiveTip(null)}
            className="text-[9px] font-bold text-slate-500 hover:text-slate-950 ml-2 px-1 rounded hover:bg-slate-200 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}
    </div>
  );
}

function PBLModal({
  onClose,
  lkpdDone,
  onToggleLkpd
}: {
  onClose: () => void;
  lkpdDone: Record<string, boolean>;
  onToggleLkpd: (key: string) => void;
}) {
  const [activeTab, setActiveTab] = useState<'sintaks' | 'lkpd' | 'ct'>('sintaks');

  const totalTasks = 25;
  const completedTasks = Object.values(lkpdDone).filter(Boolean).length;
  const progressPercent = Math.round((completedTasks / totalTasks) * 100);

  const CHAPTER_PROBLEMS = [
    {
      id: 1,
      title: 'Bab 1: IF Tunggal (Lampu Merah Zebra Cross)',
      problem: 'Bagaimana membuat mobil berhenti tertib sebelum garis henti saat ada anak sekolah yang menekan tombol ingin menyeberang?',
      tasks: [
        { key: 'ch1_t1', text: 'Mengamati skenario mobil melaju dan anak menunggu di trotoar (Orientasi Masalah)' },
        { key: 'ch1_t2', text: 'Mengidentifikasi variabel: tombolDitekan (Boolean TRUE/FALSE)' },
        { key: 'ch1_t3', text: 'Melakukan eksperimen di Lab Coba Sendiri dengan 3 level kecepatan mobil' },
        { key: 'ch1_t4', text: 'Menguji tombol eksekusi: Mobil rem berdecit tertib sebelum garis putih' },
        { key: 'ch1_t5', text: 'Menuntaskan Kuis Detektif Cilik Bab 1 & mendapatkan Bintang Emas 1' }
      ]
    },
    {
      id: 2,
      title: 'Bab 2: IF - ELSE (Verifikasi Berkas Magang HRD)',
      problem: 'Bagaimana menyeleksi kandidat magang secara adil berdasarkan 3 syarat mutlak (Nilai Rapor >= 80, Jurusan RPL, dan Ijazah Asli)?',
      tasks: [
        { key: 'ch2_t1', text: 'Mempelajari 3 dokumen fisik pelamar Budi Pratama di meja kerja HRD' },
        { key: 'ch2_t2', text: 'Memahami dua cabang tegas: Jalur IF (Lolos) vs Jalur ELSE (Perbaiki Berkas)' },
        { key: 'ch2_t3', text: 'Mencoba 4 skenario cepat (Pelamar Juara, Rapor Kurang, Jurusan Beda, Tanpa Ijazah)' },
        { key: 'ch2_t4', text: 'Menjalankan eksekusi verifikasi & melihat stempel banting slam mendarat' },
        { key: 'ch2_t5', text: 'Menuntaskan Kuis Detektif Cilik Bab 2 & mendapatkan Bintang Emas 2' }
      ]
    },
    {
      id: 3,
      title: 'Bab 3: ELSE IF (Mesin Permainan Arcade & Hadiah Poin)',
      problem: 'Bagaimana mesin arcade permainan secara otomatis menentukan hadiah (Jackpot Emas >=90, Hadiah Perak >=70, Hadiah Perunggu >=40, Tiket Hiburan) sesuai perolehan skor pemain?',
      tasks: [
        { key: 'ch3_t1', text: 'Mengamati 4 tingkatan hadiah: Emas (>=90), Perak (>=70), Perunggu (>=40), Hiburan' },
        { key: 'ch3_t2', text: 'Memahami konsep tangga evaluasi berurutan dari skor tertinggi ke terendah' },
        { key: 'ch3_t3', text: 'Menggeser gauge skor, joystick arcade, & tombol acak skor di Lab Interaktif' },
        { key: 'ch3_t4', text: 'Mengamati highlight baris aktif koding dan animasi bergerak sirene, tiket, & boneka' },
        { key: 'ch3_t5', text: 'Menuntaskan Kuis Detektif Cilik Bab 3 & mendapatkan Bintang Emas 3' }
      ]
    },
    {
      id: 4,
      title: 'Bab 4: SWITCH - CASE (3D Vending Machine Kantin Sekolah Nyata)',
      problem: 'Bagaimana mesin otomatis 3D langsung melompat mengeluarkan camilan yang dipilih tombol keypad tanpa mengecek satu per satu?',
      tasks: [
        { key: 'ch4_t1', text: 'Mengamati mesin 3D vending machine nyata dengan kaca tembus pandang & rak 3 dimensi' },
        { key: 'ch4_t2', text: 'Memahami sintaks switch-case, keyword break, serta penanganan default case' },
        { key: 'ch4_t3', text: 'Menekan keypad tombol 1-4, memutar kamera 3D, dan menguji kode salah [ 9 ]' },
        { key: 'ch4_t4', text: 'Melihat pegas spiral kawat 3D berputar nyata, minuman jatuh dengan gravitasi & cetak struk' },
        { key: 'ch4_t5', text: 'Menuntaskan Kuis Detektif Cilik Bab 4 & mendapatkan Bintang Emas 4' }
      ]
    },
    {
      id: 5,
      title: 'Bab 5: Multi-Syarat && & || (Gerbang Roller Coaster)',
      problem: 'Bagaimana gerbang wahana memastikan keselamatan pengunjung dengan mewajibkan tinggi badan >= 120 cm DAN memiliki tiket gelang?',
      tasks: [
        { key: 'ch5_t1', text: 'Mengamati gerbang turnstile dan lintasan ekstrem Halilintar Dufan' },
        { key: 'ch5_t2', text: 'Membedakan sifat operator && (wajib dua-duanya) vs operator || (salah satu cukup)' },
        { key: 'ch5_t3', text: 'Mengatur tinggi anak, saklar tiket, dan menguji 4 skenario pengunjung' },
        { key: 'ch5_t4', text: 'Memicu luncuran kereta wuuusshh saat gerbang berputar terbuka hijau' },
        { key: 'ch5_t5', text: 'Menuntaskan Kuis Detektif Cilik Bab 5 & mendapatkan Bintang Emas 5' }
      ]
    }
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
      <div className="relative w-full max-w-4xl max-h-[92vh] bg-white rounded-2xl border-4 border-slate-950 pop-card-lg text-slate-950 flex flex-col overflow-hidden animate-stamp-in shadow-2xl">
        {/* Header Modal */}
        <div className="p-4 lg:p-5 bg-gradient-to-r from-amber-400 via-amber-300 to-sky-300 border-b-3 border-slate-950 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 bg-slate-950 text-amber-300 rounded-xl border-2 border-slate-950 flex items-center justify-center text-xl shadow-md">
              🧭
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="bg-slate-950 text-white text-[9px] font-mono font-black px-2 py-0.5 rounded uppercase tracking-wider">
                  MODEL PEMBELAJARAN INOVATIF
                </span>
                <span className="text-[10px] font-bold text-slate-800">
                  KURIKULUM BERPIKIR KOMPUTASIONAL
                </span>
              </div>
              <h2 className="text-xl lg:text-2xl font-black uppercase tracking-tight text-slate-950">
                E-Modul Berbasis Problem-Based Learning (PBL)
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-slate-950 hover:bg-slate-800 text-white flex items-center justify-center font-black text-sm border-2 border-slate-950 pop-card-sm cursor-pointer transition-transform active:scale-95"
            title="Tutup Modal"
          >
            ✕
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b-2 border-slate-900 bg-slate-100 px-4 pt-2 gap-2 shrink-0">
          <button
            onClick={() => setActiveTab('sintaks')}
            className={`px-4 py-2 text-xs font-black rounded-t-lg border-t-2 border-x-2 border-slate-900 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'sintaks' ? 'bg-white text-slate-950 -mb-[2px] pb-2.5' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
            }`}
          >
            <Compass className="w-3.5 h-3.5 text-amber-600" />
            <span>5 Sintaks PBL</span>
          </button>

          <button
            onClick={() => setActiveTab('lkpd')}
            className={`px-4 py-2 text-xs font-black rounded-t-lg border-t-2 border-x-2 border-slate-900 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'lkpd' ? 'bg-white text-slate-950 -mb-[2px] pb-2.5' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
            }`}
          >
            <ClipboardList className="w-3.5 h-3.5 text-sky-600" />
            <span>LKPD Digital ({completedTasks}/{totalTasks})</span>
          </button>

          <button
            onClick={() => setActiveTab('ct')}
            className={`px-4 py-2 text-xs font-black rounded-t-lg border-t-2 border-x-2 border-slate-900 transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === 'ct' ? 'bg-white text-slate-950 -mb-[2px] pb-2.5' : 'bg-slate-200 text-slate-700 hover:bg-slate-300'
            }`}
          >
            <Lightbulb className="w-3.5 h-3.5 text-emerald-600" />
            <span>4 Pilar Computational Thinking</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 lg:p-6 overflow-y-auto flex-1 paper-bg">
          {/* TAB 1: SINTAKS PBL */}
          {activeTab === 'sintaks' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-amber-50 rounded-xl border-2 border-slate-900 pop-card-sm text-xs font-medium text-slate-800 leading-relaxed">
                <strong className="text-slate-950 text-sm font-black block mb-1">
                  Apa itu Problem-Based Learning (PBL)?
                </strong>
                Problem-Based Learning adalah model pembelajaran yang memposisikan peserta didik sebagai <em>penyelesai masalah aktif</em> (*problem solver*). Belajar pemrograman dimulai dari <strong>masalah nyata kehidupan sehari-hari</strong>, bukan dari menghafal kode abstrak.
              </div>

              <div className="space-y-3">
                <div className="p-3 bg-white rounded-xl border-2 border-slate-900 pop-card-sm">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="w-6 h-6 rounded-full bg-red-500 text-white font-mono font-black text-xs flex items-center justify-center">
                      1
                    </span>
                    <h3 className="text-sm font-black text-slate-950 uppercase">
                      Fase 1: Orientasi Siswa pada Masalah Nyata
                    </h3>
                  </div>
                  <p className="text-xs text-slate-700 leading-snug">
                    Siswa dihadapkan pada situasi dilema konkret yang ditampilkan secara visual di <strong>Panggung Kanan</strong> (contoh: anak sekolah yang kesulitan menyeberang saat mobil melaju kencang, berkas pelamar kerja yang harus diverifikasi, atau gerbang roller coaster yang harus aman).
                  </p>
                </div>

                <div className="p-3 bg-white rounded-xl border-2 border-slate-900 pop-card-sm">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="w-6 h-6 rounded-full bg-amber-500 text-slate-950 font-mono font-black text-xs flex items-center justify-center">
                      2
                    </span>
                    <h3 className="text-sm font-black text-slate-950 uppercase">
                      Fase 2: Mengorganisasi Siswa untuk Belajar
                    </h3>
                  </div>
                  <p className="text-xs text-slate-700 leading-snug">
                    Siswa mengidentifikasi variabel yang terlibat (misal: suhu udara, status tombol, skor ujian, atau tinggi badan) melalui <strong>Contoh Koding Interaktif (Sisi Kiri Atas)</strong> yang dilengkapi penjelas logika bahasa manusia.
                  </p>
                </div>

                <div className="p-3 bg-white rounded-xl border-2 border-slate-950 pop-card-sm">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="w-6 h-6 rounded-full bg-sky-500 text-white font-mono font-black text-xs flex items-center justify-center">
                      3
                    </span>
                    <h3 className="text-sm font-black text-slate-950 uppercase">
                      Fase 3: Membimbing Penyelidikan Mandiri & Lab Interaktif
                    </h3>
                  </div>
                  <p className="text-xs text-slate-700 leading-snug">
                    Siswa melakukan eksplorasi aktif di <strong>Lab Coba Sendiri (Sisi Kiri Bawah)</strong> dengan mengubah-ubah parameter input, menguji 4 skenario ekstrem, dan mengamati apakah logika berjalan konsisten.
                  </p>
                </div>

                <div className="p-3 bg-white rounded-xl border-2 border-slate-950 pop-card-sm">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="w-6 h-6 rounded-full bg-emerald-500 text-slate-950 font-mono font-black text-xs flex items-center justify-center">
                      4
                    </span>
                    <h3 className="text-sm font-black text-slate-950 uppercase">
                      Fase 4: Mengembangkan dan Menyajikan Solusi Algoritma
                    </h3>
                  </div>
                  <p className="text-xs text-slate-700 leading-snug">
                    Siswa menekan tombol uji eksekusi langkah demi langkah. Sistem menyajikan hasil evaluasi berupa <strong>Terminal Hasil React JS</strong> dan respon animasi nyata (mobil mengerem, stempel terbanting, avatar bereaksi).
                  </p>
                </div>

                <div className="p-3 bg-white rounded-xl border-2 border-slate-950 pop-card-sm">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="w-6 h-6 rounded-full bg-purple-600 text-white font-mono font-black text-xs flex items-center justify-center">
                      5
                    </span>
                    <h3 className="text-sm font-black text-slate-950 uppercase">
                      Fase 5: Menganalisis dan Mengevaluasi Proses Pemecahan Masalah
                    </h3>
                  </div>
                  <p className="text-xs text-slate-700 leading-snug">
                    Siswa merefleksikan proses berpikir mereka melalui <strong>Misi Detektif Cilik & Kuis Tantangan Berhadiah Bintang Emas</strong> untuk memvalidasi pemahaman konseptual mereka secara tuntas.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: LKPD DIGITAL */}
          {activeTab === 'lkpd' && (
            <div className="space-y-4">
              {/* Progress Box */}
              <div className="p-3.5 bg-sky-50 rounded-xl border-2 border-slate-900 pop-card-sm">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-black uppercase text-slate-900">
                    Progres Penyelidikan Siswa: {completedTasks} dari {totalTasks} Aktivitas Selesai
                  </span>
                  <span className="font-mono text-xs font-black bg-slate-950 text-sky-300 px-2 py-0.5 rounded">
                    {progressPercent}%
                  </span>
                </div>
                <div className="w-full h-3 bg-slate-200 rounded-full border border-slate-900 overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-amber-400 to-emerald-500 transition-all duration-300"
                    style={{ width: `${progressPercent}%` }}
                  />
                </div>
                <div className="mt-2 text-[11px] text-slate-600">
                  Centang setiap aktivitas yang sudah kamu coba dan selidiki di e-modul ini!
                </div>
              </div>

              {/* 5 Chapters LKPD */}
              <div className="space-y-3.5">
                {CHAPTER_PROBLEMS.map((ch) => (
                  <div key={ch.id} className="p-3.5 bg-white rounded-xl border-2 border-slate-900 pop-card-sm">
                    <div className="border-b border-slate-200 pb-2 mb-2.5">
                      <h4 className="text-xs font-black uppercase text-slate-950 flex items-center gap-1.5">
                        <span className="w-4 h-4 rounded bg-slate-950 text-white font-mono text-[10px] flex items-center justify-center">
                          {ch.id}
                        </span>
                        <span>{ch.title}</span>
                      </h4>
                      <p className="text-[11px] font-bold text-amber-800 mt-1">
                        🎯 <em>Rumusan Masalah:</em> "{ch.problem}"
                      </p>
                    </div>

                    <div className="space-y-1.5">
                      {ch.tasks.map((task) => {
                        const isDone = !!lkpdDone[task.key];
                        return (
                          <button
                            key={task.key}
                            onClick={() => {
                              audio.playClick();
                              onToggleLkpd(task.key);
                            }}
                            className={`w-full p-2 rounded border text-left text-xs transition-all cursor-pointer flex items-center justify-between ${
                              isDone ? 'bg-emerald-50 border-emerald-500 font-bold text-emerald-950' : 'bg-slate-50 hover:bg-slate-100 border-slate-300 text-slate-800'
                            }`}
                          >
                            <span className="flex items-center gap-2">
                              <span className={`w-4 h-4 rounded border flex items-center justify-center text-[10px] ${
                                isDone ? 'bg-emerald-500 text-white border-emerald-700' : 'bg-white border-slate-400'
                              }`}>
                                {isDone ? '✓' : ''}
                              </span>
                              <span>{task.text}</span>
                            </span>
                            <span className="text-[9px] font-mono font-bold text-slate-500">
                              {isDone ? 'SELESAI' : 'BELUM'}
                            </span>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 3: COMPUTATIONAL THINKING */}
          {activeTab === 'ct' && (
            <div className="space-y-4">
              <div className="p-3.5 bg-emerald-50 rounded-xl border-2 border-slate-900 pop-card-sm text-xs font-medium text-slate-800 leading-relaxed">
                <strong className="text-slate-950 text-sm font-black block mb-1">
                  Integrasi Berpikir Komputasional (Computational Thinking / CT)
                </strong>
                Melalui petualangan logika percabangan berbasis PBL ini, siswa melatih 4 kemampuan berpikir esensial era digital:
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3.5 bg-white rounded-xl border-2 border-slate-900 pop-card-sm">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-xl">🧩</span>
                    <h4 className="font-black text-slate-950 uppercase">1. Dekomposisi</h4>
                  </div>
                  <p className="text-slate-700 leading-relaxed">
                    Memecah situasi kompleks (seperti keselamatan wahana atau verifikasi pelamar kerja) menjadi syarat-syarat logis yang lebih sederhana dan terukur.
                  </p>
                </div>

                <div className="p-3.5 bg-white rounded-xl border-2 border-slate-900 pop-card-sm">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-xl">🔍</span>
                    <h4 className="font-black text-slate-950 uppercase">2. Pengenalan Pola</h4>
                  </div>
                  <p className="text-slate-700 leading-relaxed">
                    Mengenali kesamaan situasi keputusan: kapan cukup menggunakan IF tunggal, kapan membutuhkan 2 cabang (IF-ELSE), tingkatan (ELSE IF), atau menu pilihan tombol (SWITCH-CASE).
                  </p>
                </div>

                <div className="p-3.5 bg-white rounded-xl border-2 border-slate-900 pop-card-sm">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-xl">🎯</span>
                    <h4 className="font-black text-slate-950 uppercase">3. Abstraksi</h4>
                  </div>
                  <p className="text-slate-700 leading-relaxed">
                    Menyaring detail yang tidak relevan dan memusatkan perhatian pada variabel penentu utama (misal: suhu dalam angka, status tiket dalam boolean true/false).
                  </p>
                </div>

                <div className="p-3.5 bg-white rounded-xl border-2 border-slate-900 pop-card-sm">
                  <div className="flex items-center gap-2 mb-1.5">
                    <span className="text-xl">⚙️</span>
                    <h4 className="font-black text-slate-950 uppercase">4. Perancangan Algoritma</h4>
                  </div>
                  <p className="text-slate-700 leading-relaxed">
                    Menyusun urutan instruksi langkah demi langkah yang logis, teratur, dan dapat dieksekusi oleh mesin komputer tanpa ambigu.
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Modal */}
        <div className="p-3.5 bg-slate-100 border-t-2 border-slate-900 flex items-center justify-between shrink-0">
          <div className="text-[11px] font-mono font-bold text-slate-600">
            E-Modul Inovatif VIK Kompas // Model Problem-Based Learning
          </div>
          <button
            onClick={onClose}
            className="px-5 py-2 bg-slate-950 hover:bg-slate-800 text-white font-black text-xs uppercase tracking-wider rounded-lg pop-card-sm transition-transform active:scale-95 cursor-pointer"
          >
            Tutup & Lanjutkan Eksplorasi
          </button>
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 9. MODAL SERTIFIKAT JUARA DETEKTIF LOGIKA
// ==========================================
function CertificateModal({
  starsCount,
  onClose
}: {
  starsCount: number;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="relative w-full max-w-lg bg-amber-400 p-6 lg:p-8 rounded-2xl border-4 border-slate-950 pop-card-lg text-slate-950 text-center animate-stamp-in">
        <div className="flex justify-center mb-3">
          <div className="w-16 h-16 bg-white rounded-full border-3 border-slate-950 flex items-center justify-center text-3xl pop-card-sm">
            🏆
          </div>
        </div>

        <div className="inline-block bg-slate-950 text-amber-300 font-mono text-xs font-black px-3 py-1 rounded pop-card-sm uppercase tracking-wider mb-2">
          SERTIFIKAT KELULUSAN RESMI
        </div>

        <h2 className="text-2xl lg:text-3xl font-black uppercase tracking-tight text-slate-950">
          DETEKTIF LOGIKA CILIK JUARA!
        </h2>

        <p className="mt-2 text-xs lg:text-sm font-bold text-slate-900 leading-relaxed max-w-md mx-auto">
          Diberikan kepada Petualang Muda Cerdas yang telah menuntaskan seluruh 5 Misi dan Tantangan Soal Logika Percabangan Pemrograman (IF, IF-ELSE, ELSE IF, SWITCH-CASE, dan MULTI-KONDISI).
        </p>

        <div className="my-4 p-3 bg-white rounded-xl border-2 border-slate-950 pop-card flex items-center justify-around">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="flex flex-col items-center">
              <span className="text-2xl">{i <= starsCount ? '⭐' : '☆'}</span>
              <span className="text-[10px] font-bold mt-1 text-slate-700">Misi {i}</span>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between text-[11px] font-mono font-bold text-slate-800 border-t-2 border-slate-950 pt-3">
          <span>KORAN VISUAL INTERAKTIF KOMPAS</span>
          <span>TAHUN AJARAN 2026</span>
        </div>

        <button
          onClick={onClose}
          className="mt-5 w-full py-3 bg-slate-950 hover:bg-slate-800 text-white font-black text-xs uppercase tracking-wider rounded-lg pop-card-sm transition-all cursor-pointer"
        >
          Tutup & Lanjutkan Eksplorasi
        </button>
      </div>
    </div>
  );
}

// ==========================================
// 9.5. WRAPPER SPREAD KOMBINASI (HAL 7-8, 13-14, 19-20, 21-22)
// ==========================================
function Spread3KB1Investigation({
  hasWonStar,
  onEarnStar,
  onOpenPBLModal
}: {
  hasWonStar: boolean;
  onEarnStar: () => void;
  onOpenPBLModal: () => void;
}) {
  const [fullLabMode, setFullLabMode] = useState<boolean>(false);

  if (fullLabMode) {
    return (
      <div className="relative h-full w-full flex flex-col">
        <div className="bg-slate-900 text-white px-4 py-1.5 flex items-center justify-between text-xs border-b border-slate-800 shrink-0">
          <span className="font-mono font-bold text-amber-300">
            🔍 MODE LAB PENUH 2 KOLOM // KB 1: SIMULASI SINGLE IF (HALAMAN 7 - 8)
          </span>
          <button
            type="button"
            onClick={() => {
              audio.playClick();
              setFullLabMode(false);
            }}
            className="px-2.5 py-0.5 bg-amber-400 text-slate-950 font-black rounded cursor-pointer"
          >
            ↩ Kembali ke Tampilan Hal. 7 (Flowchart) & Hal. 8 (Simulasi)
          </button>
        </div>
        <div className="flex-1 overflow-y-auto">
          <ZebraCrossSpread
            hasWonStar={hasWonStar}
            onEarnStar={onEarnStar}
            onOpenPBLModal={onOpenPBLModal}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 h-full w-full">
      {/* HALAMAN 7: KONSEP, FLOWCHART BERKODE WARNA & CODE TRACING SINGLE IF */}
      <KB1Page07FlowchartAndTracing onClickSound={() => audio.playClick()} />

      {/* HALAMAN 8: SIMULASI ALUR PERCABANGAN SINGLE IF (ZEBRA CROSS) */}
      <div className="flex flex-col h-full overflow-y-auto bg-white">
        <div className="px-5 pt-4 pb-1 bg-rose-50 border-b border-slate-200 flex items-center justify-between">
          <span className="text-[10px] font-mono font-black text-red-700 uppercase">
            KB 1 // SINTAKS PBL 3: SIMULASI INTERAKTIF SINGLE IF
          </span>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => {
                audio.playClick();
                setFullLabMode(true);
              }}
              className="px-2 py-0.5 bg-slate-950 text-amber-300 font-mono text-[10px] font-bold rounded cursor-pointer"
            >
              ⛶ Perbesar 2 Kolom
            </button>
            <span className="px-2.5 py-0.5 rounded-full bg-white text-slate-950 font-mono text-[11px] font-black border-2 border-slate-950 pop-card-sm">
              HALAMAN 8 / 30
            </span>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          <ZebraCrossSpread
            hasWonStar={hasWonStar}
            onEarnStar={onEarnStar}
            onOpenPBLModal={onOpenPBLModal}
          />
        </div>
      </div>
    </div>
  );
}

function Spread6KB2Investigation({
  hasWonStar,
  onEarnStar,
  onOpenPBLModal
}: {
  hasWonStar: boolean;
  onEarnStar: () => void;
  onOpenPBLModal: () => void;
}) {
  const [fullLabMode, setFullLabMode] = useState<boolean>(false);

  if (fullLabMode) {
    return (
      <div className="relative h-full w-full flex flex-col">
        <div className="bg-slate-900 text-white px-4 py-1.5 flex items-center justify-between text-xs border-b border-slate-800 shrink-0">
          <span className="font-mono font-bold text-emerald-300">
            🔍 MODE LAB PENUH 2 KOLOM // KB 2: SIMULASI IF-ELSE (HALAMAN 13 - 14)
          </span>
          <button
            type="button"
            onClick={() => {
              audio.playClick();
              setFullLabMode(false);
            }}
            className="px-2.5 py-0.5 bg-amber-400 text-slate-950 font-black rounded cursor-pointer"
          >
            ↩ Kembali ke Tampilan Hal. 13 (Flowchart) & Hal. 14 (Simulasi)
          </button>
        </div>
        <div className="flex-1 overflow-y-auto">
          <HrdRecruitmentSpread
            hasWonStar={hasWonStar}
            onEarnStar={onEarnStar}
            onOpenPBLModal={onOpenPBLModal}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 h-full w-full">
      {/* HALAMAN 13: KONSEP, FLOWCHART 2 JALUR BERKODE WARNA & CODE TRACING IF-ELSE */}
      <KB2Page13FlowchartAndTracing onClickSound={() => audio.playClick()} />

      {/* HALAMAN 14: SIMULASI INTERAKTIF VERIFIKASI BERKAS MAGANG HRD (IF-ELSE) */}
      <div className="flex flex-col h-full overflow-y-auto bg-white">
        <div className="px-5 pt-4 pb-1 bg-emerald-50 border-b border-slate-200 flex items-center justify-between">
          <span className="text-[10px] font-mono font-black text-emerald-800 uppercase">
            KB 2 // SINTAKS PBL 3: SIMULASI INTERAKTIF IF-ELSE
          </span>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => {
                audio.playClick();
                setFullLabMode(true);
              }}
              className="px-2 py-0.5 bg-slate-950 text-amber-300 font-mono text-[10px] font-bold rounded cursor-pointer"
            >
              ⛶ Perbesar 2 Kolom
            </button>
            <span className="px-2.5 py-0.5 rounded-full bg-white text-slate-950 font-mono text-[11px] font-black border-2 border-slate-950 pop-card-sm">
              HALAMAN 14 / 30
            </span>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          <HrdRecruitmentSpread
            hasWonStar={hasWonStar}
            onEarnStar={onEarnStar}
            onOpenPBLModal={onOpenPBLModal}
          />
        </div>
      </div>
    </div>
  );
}

function Spread9KB3InvestigationA({
  hasWonStar,
  onEarnStar,
  onOpenPBLModal
}: {
  hasWonStar: boolean;
  onEarnStar: () => void;
  onOpenPBLModal: () => void;
}) {
  const [showCoasterFull, setShowCoasterFull] = useState<boolean>(false);

  if (showCoasterFull) {
    return (
      <div className="relative h-full w-full flex flex-col">
        <div className="bg-slate-900 text-white px-4 py-1.5 flex items-center justify-between text-xs border-b border-slate-800 shrink-0">
          <span className="font-mono font-bold text-rose-300">
            🎢 SIMULASI GERBANG WAHANA MULTI-SYARAT (&& DAN ||) — HALAMAN 19 - 20
          </span>
          <button
            type="button"
            onClick={() => {
              audio.playClick();
              setShowCoasterFull(false);
            }}
            className="px-2.5 py-0.5 bg-amber-400 text-slate-950 font-black rounded cursor-pointer"
          >
            ↩ Kembali ke Flowchart & Simulator Nested IF Beasiswa SMK
          </button>
        </div>
        <div className="flex-1 overflow-y-auto">
          <RollerCoasterGateSpread
            hasWonStar={hasWonStar}
            onEarnStar={onEarnStar}
            onOpenPBLModal={onOpenPBLModal}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="relative h-full w-full flex flex-col">
      <div className="bg-purple-950 text-white px-4 py-1.5 flex flex-wrap items-center justify-between gap-2 text-xs border-b border-purple-800 shrink-0">
        <span className="font-mono font-bold text-amber-300">
          🪆 KB 3 // PENYELIDIKAN MANDIRI NESTED IF (HAL. 19 - 20)
        </span>
        <button
          type="button"
          onClick={() => {
            audio.playClick();
            setShowCoasterFull(true);
          }}
          className="px-2.5 py-0.5 bg-rose-500 hover:bg-rose-400 text-white font-black rounded border border-white cursor-pointer text-[11px]"
        >
          🎢 Buka Juga: Simulasi Gerbang Roller Coaster (&& / ||) & Misi Bintang 5 →
        </button>
      </div>
      <div className="flex-1 overflow-y-auto">
        <KB3Spread2NestedIfInvestigation
          onClickSound={() => audio.playClick()}
          onSuccessSound={() => audio.playSuccess()}
          onBuzzerSound={() => audio.playBuzzer()}
        />
      </div>
    </div>
  );
}

function Spread10KB3MajemukSimulations({
  hasWonStar3,
  onEarnStar3,
  hasWonStar4,
  onEarnStar4,
  onOpenPBLModal
}: {
  hasWonStar3: boolean;
  onEarnStar3: () => void;
  hasWonStar4: boolean;
  onEarnStar4: () => void;
  onOpenPBLModal: () => void;
}) {
  const [expandedSim, setExpandedSim] = useState<'none' | 'arcade' | 'vending'>('none');

  if (expandedSim === 'arcade') {
    return (
      <div className="relative h-full w-full flex flex-col">
        <div className="bg-slate-900 text-white px-4 py-1.5 flex items-center justify-between text-xs border-b border-slate-800 shrink-0">
          <span className="font-mono font-bold text-amber-300">
            🕹️ MODE LAB PENUH // HALAMAN 21: SIMULASI ELSE-IF MESIN ARCADE
          </span>
          <button
            type="button"
            onClick={() => {
              audio.playClick();
              setExpandedSim('none');
            }}
            className="px-2.5 py-0.5 bg-amber-400 text-slate-950 font-black rounded cursor-pointer"
          >
            ↩ Kembali ke Tampilan Hal. 21 & Hal. 22
          </button>
        </div>
        <div className="flex-1 overflow-y-auto">
          <SmartWeatherSpread
            hasWonStar={hasWonStar3}
            onEarnStar={onEarnStar3}
            onOpenPBLModal={onOpenPBLModal}
          />
        </div>
      </div>
    );
  }

  if (expandedSim === 'vending') {
    return (
      <div className="relative h-full w-full flex flex-col">
        <div className="bg-slate-900 text-white px-4 py-1.5 flex items-center justify-between text-xs border-b border-slate-800 shrink-0">
          <span className="font-mono font-bold text-purple-300">
            🧋 MODE LAB PENUH // HALAMAN 22: SIMULASI 2D & 3D VENDING MACHINE (SWITCH-CASE)
          </span>
          <button
            type="button"
            onClick={() => {
              audio.playClick();
              setExpandedSim('none');
            }}
            className="px-2.5 py-0.5 bg-amber-400 text-slate-950 font-black rounded cursor-pointer"
          >
            ↩ Kembali ke Tampilan Hal. 21 & Hal. 22
          </button>
        </div>
        <div className="flex-1 overflow-y-auto">
          <VendingMachineSpread
            hasWonStar={hasWonStar4}
            onEarnStar={onEarnStar4}
            onOpenPBLModal={onOpenPBLModal}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 h-full w-full">
      {/* HALAMAN 21: SIMULASI PERCABANGAN BERTINGKAT ELSE-IF (MESIN ARCADE) */}
      <div className="flex flex-col h-full overflow-y-auto border-b lg:border-b-0 lg:border-r-2 border-slate-900 bg-amber-50/40">
        <div className="px-5 pt-4 pb-2 bg-amber-100 border-b-2 border-slate-900 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono font-black text-amber-900 uppercase block">
              KB 3 // PENYELIDIKAN MANDIRI (C): PERCABANGAN BERTINGKAT (ELSE-IF)
            </span>
            <span className="text-xs font-black text-slate-950">
              Simulasi Mesin Arcade & Tangga Evaluasi Skor
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => {
                audio.playClick();
                setExpandedSim('arcade');
              }}
              className="px-2 py-0.5 bg-slate-950 text-amber-300 font-mono text-[10px] font-bold rounded cursor-pointer"
            >
              ⛶ Layar Penuh
            </button>
            <span className="px-2.5 py-0.5 rounded-full bg-white text-slate-950 font-mono text-[11px] font-black border-2 border-slate-950 pop-card-sm">
              HALAMAN 21 / 30
            </span>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          <SmartWeatherSpread
            hasWonStar={hasWonStar3}
            onEarnStar={onEarnStar3}
            onOpenPBLModal={onOpenPBLModal}
          />
        </div>
      </div>

      {/* HALAMAN 22: SIMULASI SWITCH-CASE (2D & 3D VENDING MACHINE) */}
      <div className="flex flex-col h-full overflow-y-auto bg-purple-50/40">
        <div className="px-5 pt-4 pb-2 bg-purple-100 border-b-2 border-slate-900 flex items-center justify-between">
          <div>
            <span className="text-[10px] font-mono font-black text-purple-900 uppercase block">
              KB 3 // PENYELIDIKAN MANDIRI (D): PEMILIHAN LANGSUNG (SWITCH-CASE)
            </span>
            <span className="text-xs font-black text-slate-950">
              Simulasi 2D & 3D Vending Machine Kantin SMK
            </span>
          </div>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => {
                audio.playClick();
                setExpandedSim('vending');
              }}
              className="px-2 py-0.5 bg-slate-950 text-amber-300 font-mono text-[10px] font-bold rounded cursor-pointer"
            >
              ⛶ Layar Penuh
            </button>
            <span className="px-2.5 py-0.5 rounded-full bg-white text-slate-950 font-mono text-[11px] font-black border-2 border-slate-950 pop-card-sm">
              HALAMAN 22 / 30
            </span>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto">
          <VendingMachineSpread
            hasWonStar={hasWonStar4}
            onEarnStar={onEarnStar4}
            onOpenPBLModal={onOpenPBLModal}
          />
        </div>
      </div>
    </div>
  );
}

// ==========================================
// 10. MAIN APP & 30-PAGE 3D FLIPBOOK CONTAINER
// ==========================================
export default function App() {
  const [currentSpread, setCurrentSpread] = useState<number>(0); // 0 to 14 (15 spreads = 30 pages)
  const [activeSinglePage, setActiveSinglePage] = useState<number>(1); // 1 to 30
  const [viewMode, setViewMode] = useState<'spread' | 'single'>('spread');
  const [isFlipping, setIsFlipping] = useState<boolean>(false);
  const [flipDirection, setFlipDirection] = useState<'next' | 'prev'>('next');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showSearchDropdown, setShowSearchDropdown] = useState<boolean>(false);
  const [showTocModal, setShowTocModal] = useState<boolean>(false);

  const [starsWon, setStarsWon] = useState<Record<number, boolean>>({
    1: false,
    2: false,
    3: false,
    4: false,
    5: false
  });
  const [showCertificate, setShowCertificate] = useState<boolean>(false);
  const [showPBLModal, setShowPBLModal] = useState<boolean>(false);
  const [lkpdDone, setLkpdDone] = useState<Record<string, boolean>>(() => {
    try {
      const saved = localStorage.getItem('pbl_lkpd_progress');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const handleToggleLkpd = (key: string) => {
    setLkpdDone((prev) => {
      const next = { ...prev, [key]: !prev[key] };
      try {
        localStorage.setItem('pbl_lkpd_progress', JSON.stringify(next));
      } catch {}
      return next;
    });
  };

  const completedLkpdCount = useMemo(() => {
    return Object.values(lkpdDone).filter(Boolean).length;
  }, [lkpdDone]);

  const totalStars = useMemo(() => {
    return Object.values(starsWon).filter(Boolean).length;
  }, [starsWon]);

  useEffect(() => {
    audio.enabled = soundEnabled;
  }, [soundEnabled]);

  // Search filter across all 30 pages
  const searchResults = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return [];
    return PAGES_CATALOG.filter(
      (p) =>
        p.title.toLowerCase().includes(q) ||
        p.subtitle.toLowerCase().includes(q) ||
        p.kb.toLowerCase().includes(q) ||
        (p.pblSyntax && p.pblSyntax.toLowerCase().includes(q)) ||
        p.keywords.some((k) => k.toLowerCase().includes(q)) ||
        `halaman ${p.pageNum}`.includes(q) ||
        `hal ${p.pageNum}`.includes(q) ||
        `${p.pageNum}` === q
    );
  }, [searchQuery]);

  const goToSpread = (targetSpreadIdx: number) => {
    if (
      targetSpreadIdx < 0 ||
      targetSpreadIdx >= SPREADS_CATALOG.length ||
      isFlipping
    )
      return;

    if (targetSpreadIdx === currentSpread) return;

    setFlipDirection(targetSpreadIdx > currentSpread ? 'next' : 'prev');
    setIsFlipping(true);
    audio.playPageFlip();

    setTimeout(() => {
      setCurrentSpread(targetSpreadIdx);
      setActiveSinglePage(targetSpreadIdx * 2 + 1);
      setIsFlipping(false);
    }, 320);
  };

  const goToPage = (pageNumber: number) => {
    const clampedPage = Math.max(1, Math.min(30, pageNumber));
    const targetSpread = Math.floor((clampedPage - 1) / 2);
    setActiveSinglePage(clampedPage);
    if (targetSpread !== currentSpread) {
      setFlipDirection(targetSpread > currentSpread ? 'next' : 'prev');
      setIsFlipping(true);
      audio.playPageFlip();
      setTimeout(() => {
        setCurrentSpread(targetSpread);
        setIsFlipping(false);
      }, 320);
    } else {
      audio.playClick();
    }
  };

  const handleNext = () => {
    if (viewMode === 'single') {
      if (activeSinglePage < 30) goToPage(activeSinglePage + 1);
    } else {
      if (currentSpread < SPREADS_CATALOG.length - 1) goToSpread(currentSpread + 1);
    }
  };

  const handlePrev = () => {
    if (viewMode === 'single') {
      if (activeSinglePage > 1) goToPage(activeSinglePage - 1);
    } else {
      if (currentSpread > 0) goToSpread(currentSpread - 1);
    }
  };

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (
        document.activeElement?.tagName === 'INPUT' ||
        document.activeElement?.tagName === 'SELECT' ||
        document.activeElement?.tagName === 'TEXTAREA'
      ) {
        return;
      }
      if (e.key === 'ArrowRight') {
        handleNext();
      } else if (e.key === 'ArrowLeft') {
        handlePrev();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  });

  const handleEarnStar = (chapId: number) => {
    setStarsWon((prev) => {
      const updated = { ...prev, [chapId]: true };
      const newTotal = Object.values(updated).filter(Boolean).length;
      if (newTotal === 5) {
        setTimeout(() => setShowCertificate(true), 1000);
      }
      return updated;
    });
  };

  const leftPageNum = currentSpread * 2 + 1;
  const rightPageNum = currentSpread * 2 + 2;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between selection:bg-amber-400 selection:text-slate-950">
      {showCertificate && (
        <CertificateModal
          starsCount={totalStars}
          onClose={() => setShowCertificate(false)}
        />
      )}

      {showPBLModal && (
        <PBLModal
          onClose={() => setShowPBLModal(false)}
          lkpdDone={lkpdDone}
          onToggleLkpd={handleToggleLkpd}
        />
      )}

      {/* MODAL DAFTAR ISI CEPAT (CLICKABLE TABLE OF CONTENTS 30 HALAMAN) */}
      {showTocModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-sm flex items-center justify-center p-3 sm:p-5">
          <div className="relative w-full max-w-4xl max-h-[90vh] bg-white rounded-2xl border-4 border-slate-950 pop-card-lg text-slate-950 flex flex-col overflow-hidden animate-stamp-in">
            <div className="p-4 bg-gradient-to-r from-sky-400 via-amber-300 to-emerald-300 border-b-3 border-slate-950 flex items-center justify-between">
              <div>
                <div className="text-[10px] font-mono font-black uppercase text-slate-900">
                  NAVIGASI CEPAT E-MODUL // CLICKABLE TABLE OF CONTENTS
                </div>
                <h2 className="text-lg sm:text-xl font-black uppercase text-slate-950">
                  Daftar Isi Interaktif 30 Halaman (Sintaks PBL & Bahan Penyerta)
                </h2>
              </div>
              <button
                type="button"
                onClick={() => setShowTocModal(false)}
                className="w-8 h-8 rounded-full bg-slate-950 text-white font-black text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="p-4 overflow-y-auto grid grid-cols-1 sm:grid-cols-2 gap-2 paper-bg">
              {PAGES_CATALOG.map((p) => {
                const isActive =
                  viewMode === 'single'
                    ? activeSinglePage === p.pageNum
                    : p.spreadIndex === currentSpread;
                return (
                  <button
                    key={p.pageNum}
                    type="button"
                    onClick={() => {
                      goToPage(p.pageNum);
                      setShowTocModal(false);
                    }}
                    className={`p-2.5 rounded-xl border-2 text-left cursor-pointer transition-all flex items-center justify-between gap-2 ${
                      isActive
                        ? 'bg-amber-300 border-slate-950 pop-card-sm font-black'
                        : 'bg-white hover:bg-sky-50 border-slate-900'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span className="w-7 h-7 rounded-lg bg-slate-950 text-amber-300 font-mono text-xs font-black flex items-center justify-center shrink-0">
                        {p.pageNum}
                      </span>
                      <div className="min-w-0">
                        <div className="text-[9px] font-mono font-bold text-sky-800 uppercase truncate">
                          {p.kb} {p.pblSyntax ? `• ${p.pblSyntax}` : ''}
                        </div>
                        <div className="text-xs font-black text-slate-950 truncate">{p.title}</div>
                      </div>
                    </div>
                    <span className="text-[10px] font-mono font-black text-slate-700 shrink-0">
                      Hal. {p.pageNum}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TOP NAVIGATION BAR (DENGAN CLICKABLE TOC, BILAH PENCARIAN, & LOMPAT HALAMAN 1-30) */}
      <header className="w-full bg-slate-900 border-b-2 border-slate-800 px-3 lg:px-6 py-2.5 flex flex-wrap items-center justify-between gap-3 shrink-0 z-40">
        {/* Brand & Judul */}
        <div className="flex items-center gap-2.5 whitespace-nowrap shrink-0">
          <div className="bg-amber-400 text-slate-950 font-black text-xs sm:text-sm px-2.5 py-1 rounded border-2 border-slate-950 pop-card-sm tracking-widest uppercase">
            E-MODUL PBL
          </div>
          <div>
            <div className="text-xs sm:text-sm font-black tracking-tight text-white leading-none">
              LOGIKA PERCABANGAN (30 HALAMAN)
            </div>
            <div className="text-[10px] font-mono text-amber-400 font-bold">
              Informatika Fase E (Kelas X SMK) • Single IF, IF-ELSE, Nested IF
            </div>
          </div>
        </div>

        {/* BILAH PENCARIAN INTERAKTIF (SEARCH BAR SESUAI TABEL 1.1) */}
        <div className="relative flex-1 max-w-xs sm:max-w-sm">
          <div className="flex items-center bg-slate-950 border-2 border-slate-700 focus-within:border-amber-400 rounded-lg px-2.5 py-1">
            <Search className="w-3.5 h-3.5 text-amber-400 mr-2 shrink-0" />
            <input
              type="text"
              value={searchQuery}
              onFocus={() => setShowSearchDropdown(true)}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setShowSearchDropdown(true);
              }}
              placeholder="Cari halaman/materi (mis: Nested IF, Flowchart, RPM)..."
              className="w-full bg-transparent text-xs text-white placeholder-slate-400 focus:outline-none"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setShowSearchDropdown(false);
                }}
                className="text-xs text-slate-400 hover:text-white ml-1 cursor-pointer"
              >
                ✕
              </button>
            )}
          </div>

          {/* Dropdown Hasil Pencarian Halaman */}
          {showSearchDropdown && searchQuery.trim() !== '' && (
            <div className="absolute left-0 right-0 mt-1 bg-slate-900 border-2 border-amber-400 rounded-xl shadow-2xl max-h-72 overflow-y-auto z-50 p-1.5">
              {searchResults.length > 0 ? (
                searchResults.map((res) => (
                  <button
                    key={res.pageNum}
                    type="button"
                    onClick={() => {
                      goToPage(res.pageNum);
                      setShowSearchDropdown(false);
                    }}
                    className="w-full text-left p-2 hover:bg-slate-800 rounded-lg flex items-center justify-between gap-2 cursor-pointer border-b border-slate-800 last:border-b-0"
                  >
                    <div className="min-w-0">
                      <div className="text-[9px] font-mono text-amber-300 uppercase">
                        {res.kb} {res.pblSyntax ? `// ${res.pblSyntax}` : ''}
                      </div>
                      <div className="text-xs font-bold text-white truncate">{res.title}</div>
                      <div className="text-[10px] text-slate-400 truncate">{res.subtitle}</div>
                    </div>
                    <span className="px-2 py-0.5 rounded bg-amber-400 text-slate-950 font-mono text-[10px] font-black shrink-0">
                      Hal. {res.pageNum}
                    </span>
                  </button>
                ))
              ) : (
                <div className="p-3 text-center text-xs text-slate-400">
                  Tidak ditemukan halaman untuk "{searchQuery}".
                </div>
              )}
            </div>
          )}
        </div>

        {/* Kontrol Navigasi Cepat: Daftar Isi (TOC), Pilih Halaman 1-30, Mode 1/2 Hal, PBL & Suara */}
        <div className="flex flex-wrap items-center gap-1.5 sm:gap-2 shrink-0">
          {/* Tombol Daftar Isi (Clickable TOC) */}
          <button
            type="button"
            onClick={() => {
              audio.playClick();
              setShowTocModal(true);
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-black bg-sky-400 hover:bg-sky-300 text-slate-950 rounded-lg border-2 border-slate-950 pop-card-sm cursor-pointer"
            title="Buka Daftar Isi Interaktif (30 Halaman)"
          >
            <BookOpen className="w-3.5 h-3.5" />
            <span>Daftar Isi</span>
          </button>

          {/* Dropdown Lompat Langsung ke Halaman 1 s.d. 30 */}
          <select
            aria-label="Pilih Halaman 1 sampai 30"
            value={viewMode === 'single' ? activeSinglePage : leftPageNum}
            onChange={(e) => goToPage(Number(e.target.value))}
            className="px-2 py-1.5 text-xs font-mono font-black bg-slate-800 text-amber-300 rounded-lg border-2 border-slate-700 cursor-pointer focus:outline-none focus:border-amber-400"
          >
            {PAGES_CATALOG.map((p) => (
              <option key={p.pageNum} value={p.pageNum}>
                Hal. {p.pageNum}/30 — {p.title.substring(0, 28)}
              </option>
            ))}
          </select>

          {/* Toggle Mode 2 Halaman (Spread) vs 1 Halaman (Fokus) */}
          <button
            type="button"
            onClick={() => {
              audio.playClick();
              setViewMode((prev) => (prev === 'spread' ? 'single' : 'spread'));
            }}
            className="px-2.5 py-1.5 text-xs font-bold bg-slate-800 hover:bg-slate-700 text-emerald-300 rounded-lg border border-slate-700 cursor-pointer"
            title="Ubah Mode Bukaan 2 Halaman atau Fokus 1 Halaman"
          >
            {viewMode === 'spread' ? '📖 2 Hal' : '📄 1 Hal'}
          </button>

          {/* Tombol Panduan Sintaks PBL & LKPD */}
          <button
            type="button"
            onClick={() => {
              audio.playClick();
              setShowPBLModal(true);
            }}
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-black bg-gradient-to-r from-amber-400 to-emerald-300 text-slate-950 rounded-lg border-2 border-slate-950 pop-card-sm cursor-pointer"
          >
            <Compass className="w-3.5 h-3.5" />
            <span className="hidden md:inline">LKPD</span>
            <span className="bg-slate-950 text-amber-300 text-[10px] font-mono px-1.5 rounded-full">
              {completedLkpdCount}/25
            </span>
          </button>

          {/* Tombol Bintang & Sertifikat */}
          <button
            type="button"
            onClick={() => setShowCertificate(true)}
            className="flex items-center gap-1 px-2.5 py-1.5 text-xs font-black bg-amber-400 hover:bg-amber-300 text-slate-950 rounded-lg border-2 border-slate-950 pop-card-sm cursor-pointer"
          >
            <span>⭐</span>
            <span>{totalStars}/5</span>
          </button>

          {/* Tombol Suara */}
          <button
            type="button"
            onClick={() => {
              const next = !soundEnabled;
              setSoundEnabled(next);
              if (next) audio.playClick();
            }}
            className="p-1.5 text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg border border-slate-700 cursor-pointer"
            title="Nyalakan / Matikan Suara"
          >
            {soundEnabled ? (
              <Volume2 className="w-4 h-4 text-emerald-400" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-400" />
            )}
          </button>
        </div>
      </header>

      {/* SUB-BAR SHORTCUT KEGIATAN BELAJAR & BAHAN PENYERTA */}
      <div className="w-full bg-slate-950 border-b border-slate-800 px-3 lg:px-6 py-1.5 flex items-center justify-between gap-2 overflow-x-auto text-[11px] font-bold shrink-0">
        <div className="flex items-center gap-1.5">
          {[
            { label: 'Sampul (Hal 1-2)', page: 1 },
            { label: 'Daftar Isi & CP (Hal 3-4)', page: 3 },
            { label: 'KB 1: Single IF (Hal 5-10)', page: 5 },
            { label: 'KB 2: IF-ELSE (Hal 11-16)', page: 11 },
            { label: 'KB 3: Nested IF (Hal 17-24)', page: 17 },
            { label: 'Evaluasi Sumatif (Hal 25-26)', page: 25 },
            { label: 'Modul Ajar / RPM (Hal 27-28)', page: 27 },
            { label: 'Buku Petunjuk (Hal 29-30)', page: 29 }
          ].map((nav) => {
            const isCurr =
              leftPageNum >= nav.page &&
              leftPageNum <
                (nav.page === 5
                  ? 11
                  : nav.page === 11
                  ? 17
                  : nav.page === 17
                  ? 25
                  : nav.page + 2);
            return (
              <button
                key={nav.page}
                type="button"
                onClick={() => goToPage(nav.page)}
                className={`px-2.5 py-1 rounded-md whitespace-nowrap cursor-pointer transition-all border ${
                  isCurr
                    ? 'bg-amber-400 text-slate-950 border-slate-950 font-black'
                    : 'bg-slate-900 text-slate-300 border-slate-800 hover:bg-slate-800'
                }`}
              >
                {nav.label}
              </button>
            );
          })}
        </div>

        <div className="font-mono text-[11px] text-amber-300 whitespace-nowrap shrink-0">
          {viewMode === 'single'
            ? `FOKUS HALAMAN ${activeSinglePage} DARI 30`
            : `BUKAAN HALAMAN ${leftPageNum} – ${rightPageNum} DARI 30`}
        </div>
      </div>

      {/* MAIN 3D FLIPBOOK CONTAINER */}
      <main className="flex-1 flex flex-col items-center justify-center p-2 sm:p-4 lg:p-6 perspective-container">
        <div
          className={`relative w-full max-w-6xl min-h-[660px] lg:h-[760px] bg-white rounded-2xl border-4 border-slate-900 pop-card-lg overflow-hidden book-preserve-3d transition-transform duration-300 ${
            isFlipping
              ? flipDirection === 'next'
                ? 'scale-[0.99] rotate-y-[-2deg]'
                : 'scale-[0.99] rotate-y-[2deg]'
              : 'scale-100'
          }`}
        >
          {/* Lipatan Tengah Buku (Hanya tampil pada Mode 2 Halaman) */}
          {viewMode === 'spread' && (
            <>
              <div className="hidden lg:block absolute top-0 bottom-0 left-1/2 w-8 -translate-x-1/2 pointer-events-none z-30 spine-gutter-left" />
              <div className="hidden lg:block absolute top-0 bottom-0 left-1/2 w-8 pointer-events-none z-30 spine-gutter-right" />
              <div className="hidden lg:block absolute top-0 bottom-0 left-1/2 w-[2px] -translate-x-1/2 bg-slate-400/40 pointer-events-none z-30" />
            </>
          )}

          {/* SPREAD RENDERER (15 SPREADS = 30 HALAMAN) */}
          <div
            className={`w-full h-full ${
              viewMode === 'single'
                ? activeSinglePage % 2 === 1
                  ? 'single-page-mode-odd'
                  : 'single-page-mode-even'
                : ''
            }`}
          >
            {currentSpread === 0 && (
              <Spread0CoverAndIntro
                onGoToPage={goToPage}
                onOpenPBLModal={() => setShowPBLModal(true)}
                onClickSound={() => audio.playClick()}
              />
            )}
            {currentSpread === 1 && (
              <Spread1TocAndCurriculum
                onGoToPage={goToPage}
                onClickSound={() => audio.playClick()}
                onSuccessSound={() => audio.playSuccess()}
              />
            )}
            {currentSpread === 2 && (
              <KB1Spread1OrientasiOrganisasi
                onClickSound={() => audio.playClick()}
                onSuccessSound={() => audio.playSuccess()}
              />
            )}
            {currentSpread === 3 && (
              <Spread3KB1Investigation
                hasWonStar={starsWon[1]}
                onEarnStar={() => handleEarnStar(1)}
                onOpenPBLModal={() => setShowPBLModal(true)}
              />
            )}
            {currentSpread === 4 && (
              <KB1Spread3SolusiEvaluasi
                onClickSound={() => audio.playClick()}
                onSuccessSound={() => audio.playSuccess()}
                onBuzzerSound={() => audio.playBuzzer()}
              />
            )}
            {currentSpread === 5 && (
              <KB2Spread1OrientasiOrganisasi
                onClickSound={() => audio.playClick()}
                onSuccessSound={() => audio.playSuccess()}
              />
            )}
            {currentSpread === 6 && (
              <Spread6KB2Investigation
                hasWonStar={starsWon[2]}
                onEarnStar={() => handleEarnStar(2)}
                onOpenPBLModal={() => setShowPBLModal(true)}
              />
            )}
            {currentSpread === 7 && (
              <KB2Spread3SolusiEvaluasi
                onClickSound={() => audio.playClick()}
                onSuccessSound={() => audio.playSuccess()}
                onBuzzerSound={() => audio.playBuzzer()}
              />
            )}
            {currentSpread === 8 && (
              <KB3Spread1OrientasiOrganisasi
                onClickSound={() => audio.playClick()}
                onSuccessSound={() => audio.playSuccess()}
              />
            )}
            {currentSpread === 9 && (
              <Spread9KB3InvestigationA
                hasWonStar={starsWon[5]}
                onEarnStar={() => handleEarnStar(5)}
                onOpenPBLModal={() => setShowPBLModal(true)}
              />
            )}
            {currentSpread === 10 && (
              <Spread10KB3MajemukSimulations
                hasWonStar3={starsWon[3]}
                onEarnStar3={() => handleEarnStar(3)}
                hasWonStar4={starsWon[4]}
                onEarnStar4={() => handleEarnStar(4)}
                onOpenPBLModal={() => setShowPBLModal(true)}
              />
            )}
            {currentSpread === 11 && (
              <KB3Spread4SolusiEvaluasi
                onClickSound={() => audio.playClick()}
                onSuccessSound={() => audio.playSuccess()}
                onBuzzerSound={() => audio.playBuzzer()}
              />
            )}
            {currentSpread === 12 && (
              <Spread12SummativeEvaluation
                starsCount={totalStars}
                completedLkpdCount={completedLkpdCount}
                onOpenCertificate={() => setShowCertificate(true)}
                onClickSound={() => audio.playClick()}
                onSuccessSound={() => audio.playSuccess()}
                onBuzzerSound={() => audio.playBuzzer()}
              />
            )}
            {currentSpread === 13 && <Spread13ModulAjarRPM />}
            {currentSpread === 14 && (
              <Spread14UserGuideAndBackCover
                onGoToPage={goToPage}
                onClickSound={() => audio.playClick()}
              />
            )}
          </div>

          {/* Floating Prev Button */}
          {(viewMode === 'single' ? activeSinglePage > 1 : currentSpread > 0) && (
            <button
              type="button"
              onClick={handlePrev}
              className="absolute left-2.5 top-1/2 -translate-y-1/2 z-40 w-10 h-10 rounded-full bg-slate-950/85 hover:bg-slate-950 text-white flex items-center justify-center border-2 border-white pop-card-sm transition-transform active:scale-95 cursor-pointer"
              title="Halaman Sebelumnya (Panah Kiri)"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
          )}

          {/* Floating Next Button */}
          {(viewMode === 'single'
            ? activeSinglePage < 30
            : currentSpread < SPREADS_CATALOG.length - 1) && (
            <button
              type="button"
              onClick={handleNext}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 z-40 w-10 h-10 rounded-full bg-slate-950/85 hover:bg-slate-950 text-white flex items-center justify-center border-2 border-white pop-card-sm transition-transform active:scale-95 cursor-pointer"
              title="Halaman Selanjutnya (Panah Kanan)"
            >
              <ChevronRight className="w-6 h-6" />
            </button>
          )}
        </div>
      </main>

      {/* BOTTOM SCRUBBER & 30-PAGE NAVIGATION CONTROLS */}
      <footer className="w-full bg-slate-900 border-t-2 border-slate-800 px-4 py-2.5 shrink-0 z-40">
        <div className="max-w-6xl mx-auto flex flex-col lg:flex-row items-center justify-between gap-2.5">
          {/* 15 Spread Scrubber Pills (Hal 1-2 s.d. Hal 29-30) */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full lg:w-auto pb-1 lg:pb-0">
            {SPREADS_CATALOG.map((sp) => (
              <button
                key={sp.spreadIndex}
                type="button"
                onClick={() => goToSpread(sp.spreadIndex)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold border transition-all cursor-pointer whitespace-nowrap flex items-center gap-1 ${
                  currentSpread === sp.spreadIndex
                    ? 'bg-amber-400 text-slate-950 border-slate-950 pop-card-sm font-black'
                    : 'bg-slate-800 text-slate-300 border-slate-700 hover:bg-slate-700'
                }`}
              >
                <span className="font-mono text-[10px] opacity-80">[{sp.pageRange}]</span>
                <span>{sp.shortTitle}</span>
                {sp.starId && starsWon[sp.starId] && <span>⭐</span>}
              </button>
            ))}
          </div>

          {/* Page Indicator & Prev/Next Buttons */}
          <div className="flex items-center gap-3 text-xs font-bold text-slate-300 shrink-0">
            <span className="font-mono bg-slate-950 px-2.5 py-1 rounded border border-slate-800">
              {viewMode === 'single' ? (
                <>
                  HALAMAN <strong className="text-amber-400">{activeSinglePage}</strong> / 30
                </>
              ) : (
                <>
                  HALAMAN <strong className="text-amber-400">{leftPageNum}–{rightPageNum}</strong> / 30
                </>
              )}
            </span>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                disabled={viewMode === 'single' ? activeSinglePage === 1 : currentSpread === 0}
                onClick={handlePrev}
                className="px-3 py-1 rounded bg-slate-800 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed border border-slate-700 text-white cursor-pointer"
              >
                ← Sebelumnya
              </button>
              <button
                type="button"
                disabled={
                  viewMode === 'single'
                    ? activeSinglePage === 30
                    : currentSpread === SPREADS_CATALOG.length - 1
                }
                onClick={handleNext}
                className="px-3 py-1 rounded bg-amber-400 hover:bg-amber-300 disabled:opacity-40 disabled:cursor-not-allowed border border-slate-950 text-slate-950 font-black pop-card-sm cursor-pointer"
              >
                Selanjutnya →
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
