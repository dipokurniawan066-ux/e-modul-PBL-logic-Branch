import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Zap,
  Coins,
  CheckCircle2,
  AlertTriangle,
  RotateCw,
  ArrowDown,
  Volume2,
  Gift,
  Flame,
  ShoppingBag
} from 'lucide-react';

export interface Vending2DProps {
  selectedSlot: number;
  isDispensing: boolean;
  onSelectSlot: (slot: number) => void;
  items: Record<
    number,
    { name: string; price: string; icon: string; priceNum: number; desc: string }
  >;
  dispensedItem: { name: string; price: string; icon: string; priceNum: number; desc?: string } | null;
  coinsInserted: number;
  coinDiscount?: number;
  onInsertCoin?: (amount: number) => void;
}

export function VendingMachine2D({
  selectedSlot,
  isDispensing,
  onSelectSlot,
  items,
  dispensedItem,
  coinsInserted,
  coinDiscount = 0,
  onInsertCoin
}: Vending2DProps) {
  // Animation states for dropping food
  const [fallingSlot, setFallingSlot] = useState<number | null>(null);
  const [fallStage, setFallStage] = useState<'idle' | 'spinning' | 'dropping' | 'landed'>('idle');
  const [hasPickedUp, setHasPickedUp] = useState<boolean>(false);
  const [showCelebration, setShowCelebration] = useState<boolean>(false);
  const [activeLedMessage, setActiveLedMessage] = useState<string>('PILIH NOMOR [1 - 4]');

  // Trigger drop animation whenever isDispensing becomes true
  useEffect(() => {
    if (isDispensing) {
      setFallingSlot(selectedSlot);
      setFallStage('spinning');
      setHasPickedUp(false);
      setShowCelebration(false);

      if (items[selectedSlot]) {
        setActiveLedMessage(`MEMUTAR PEGAS #${selectedSlot}...`);
      } else {
        setActiveLedMessage(`KODE #${selectedSlot} TIDAK ADA!`);
      }

      // Step 1: Coil spins, then food drops
      const dropTimer = setTimeout(() => {
        setFallStage('dropping');
      }, 400);

      // Step 2: Food lands in bottom tray
      const landTimer = setTimeout(() => {
        setFallStage('landed');
        if (items[selectedSlot]) {
          setActiveLedMessage(`SIAP DI NAMPAN: ${items[selectedSlot].name.toUpperCase()}`);
        } else {
          setActiveLedMessage('ERROR: DEFAULT CASE RUNNING');
        }
      }, 950);

      return () => {
        clearTimeout(dropTimer);
        clearTimeout(landTimer);
      };
    }
  }, [isDispensing, selectedSlot, items]);

  const handlePickup = () => {
    setHasPickedUp(true);
    setShowCelebration(true);
    setTimeout(() => setShowCelebration(false), 2400);
  };

  const currentItem = items[selectedSlot] || null;

  return (
    <div className="w-full flex flex-col gap-3 select-none">
      {/* ========================================================= */}
      {/* BADAN UTAMA VENDING MACHINE 2D ARCADE RETRO               */}
      {/* ========================================================= */}
      <div className="relative bg-gradient-to-b from-slate-900 via-purple-950 to-slate-950 border-4 border-slate-950 rounded-2xl pop-card shadow-2xl p-3 sm:p-4 text-white overflow-hidden">
        
        {/* Lampu Neon Header Vending */}
        <div className="flex items-center justify-between pb-2.5 mb-3 border-b-2 border-purple-500/40 bg-slate-950/80 -mx-3 -mt-3 sm:-mx-4 sm:-mt-4 p-3 rounded-t-xl">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-emerald-400 animate-ping" />
            <div>
              <div className="text-[11px] font-black uppercase tracking-wider text-amber-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>KANTIN DIGITAL // VENDING 2D INTERAKTIF</span>
              </div>
              <div className="text-[9px] font-mono text-purple-300">
                Tekan tombol keypad untuk mengeluarkan makanan secara nyata!
              </div>
            </div>
          </div>
          <div className="hidden sm:flex items-center gap-1 bg-purple-900/60 px-2 py-0.5 rounded border border-purple-400/50 text-[10px] font-mono text-purple-200">
            <span>MODE:</span>
            <span className="font-black text-emerald-300">SWITCH-CASE 2D</span>
          </div>
        </div>

        {/* Interior Mesin: 2 Kolom (Kaca Showcase Kiri & Panel Kontrol Kanan) */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-3.5">
          
          {/* ===================================================== */}
          {/* SISI KIRI (7 Kolom): ETALASE KACA & RAK MAKANAN       */}
          {/* ===================================================== */}
          <div className="md:col-span-8 flex flex-col justify-between bg-slate-950/90 rounded-xl border-3 border-slate-800 p-2.5 relative shadow-inner overflow-hidden">
            
            {/* Efek Kilau Kaca Showcase */}
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-cyan-400/5 to-white/10 pointer-events-none z-10" />

            {/* Label Rak Kaca */}
            <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 px-1 mb-1.5 z-20">
              <span className="flex items-center gap-1 text-cyan-300">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
                ETALASE KACA TEMBUS PANDANG (SLOT 1 - 4)
              </span>
              <span className="text-[9px] text-amber-300">KACA ANTI-GORES</span>
            </div>

            {/* RAK TINGKAT 1 (SLOT 1 & 2) */}
            <div className="bg-slate-900/80 rounded-lg border-2 border-slate-800 p-2 mb-2 relative">
              <div className="text-[9px] font-mono text-purple-300 mb-1 flex items-center justify-between">
                <span>RAK ATAS [MINUMAN & ROTI]</span>
                <span className="text-slate-400 text-[8px]">PEGAS SPIRAL BAJA</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                
                {/* SLOT 1: BOBA */}
                <button
                  type="button"
                  onClick={() => onSelectSlot(1)}
                  className={`relative p-2 rounded-lg border-2 text-left cursor-pointer transition-all flex items-center justify-between group ${
                    selectedSlot === 1
                      ? 'bg-purple-900/90 border-amber-400 ring-2 ring-amber-400/80 shadow-lg'
                      : 'bg-slate-950/80 border-slate-700 hover:border-purple-400 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {/* Visual Spiral Coil */}
                    <div className="relative w-10 h-10 flex items-center justify-center">
                      <div className={`absolute inset-0 border-2 border-dashed border-amber-400/60 rounded-full ${
                        isDispensing && selectedSlot === 1 ? 'animate-spin' : ''
                      }`} />
                      <span className="text-3xl filter drop-shadow group-hover:scale-110 transition-transform">
                        🧋
                      </span>
                    </div>
                    <div>
                      <div className="text-[11px] font-black text-amber-300 leading-tight">
                        Boba Milk Tea
                      </div>
                      <div className="text-[10px] font-mono text-emerald-400 font-bold">
                        Rp 12.000
                      </div>
                    </div>
                  </div>
                  <div className={`px-2 py-1 rounded text-xs font-mono font-black border ${
                    selectedSlot === 1
                      ? 'bg-amber-400 text-slate-950 border-amber-300'
                      : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}>
                    [ 1 ]
                  </div>
                </button>

                {/* SLOT 2: ROTI BAKAR */}
                <button
                  type="button"
                  onClick={() => onSelectSlot(2)}
                  className={`relative p-2 rounded-lg border-2 text-left cursor-pointer transition-all flex items-center justify-between group ${
                    selectedSlot === 2
                      ? 'bg-purple-900/90 border-amber-400 ring-2 ring-amber-400/80 shadow-lg'
                      : 'bg-slate-950/80 border-slate-700 hover:border-purple-400 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div className="relative w-10 h-10 flex items-center justify-center">
                      <div className={`absolute inset-0 border-2 border-dashed border-amber-400/60 rounded-full ${
                        isDispensing && selectedSlot === 2 ? 'animate-spin' : ''
                      }`} />
                      <span className="text-3xl filter drop-shadow group-hover:scale-110 transition-transform">
                        🥪
                      </span>
                    </div>
                    <div>
                      <div className="text-[11px] font-black text-amber-300 leading-tight">
                        Roti Keju
                      </div>
                      <div className="text-[10px] font-mono text-emerald-400 font-bold">
                        Rp 8.000
                      </div>
                    </div>
                  </div>
                  <div className={`px-2 py-1 rounded text-xs font-mono font-black border ${
                    selectedSlot === 2
                      ? 'bg-amber-400 text-slate-950 border-amber-300'
                      : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}>
                    [ 2 ]
                  </div>
                </button>
              </div>
            </div>

            {/* RAK TINGKAT 2 (SLOT 3 & 4) */}
            <div className="bg-slate-900/80 rounded-lg border-2 border-slate-800 p-2 mb-2.5 relative">
              <div className="text-[9px] font-mono text-purple-300 mb-1 flex items-center justify-between">
                <span>RAK BAWAH [ES KRIM & SUSU]</span>
                <span className="text-slate-400 text-[8px]">PEGAS SPIRAL BAJA</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                
                {/* SLOT 3: ES KRIM */}
                <button
                  type="button"
                  onClick={() => onSelectSlot(3)}
                  className={`relative p-2 rounded-lg border-2 text-left cursor-pointer transition-all flex items-center justify-between group ${
                    selectedSlot === 3
                      ? 'bg-purple-900/90 border-amber-400 ring-2 ring-amber-400/80 shadow-lg'
                      : 'bg-slate-950/80 border-slate-700 hover:border-purple-400 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div className="relative w-10 h-10 flex items-center justify-center">
                      <div className={`absolute inset-0 border-2 border-dashed border-pink-400/60 rounded-full ${
                        isDispensing && selectedSlot === 3 ? 'animate-spin' : ''
                      }`} />
                      <span className="text-3xl filter drop-shadow group-hover:scale-110 transition-transform">
                        🍦
                      </span>
                    </div>
                    <div>
                      <div className="text-[11px] font-black text-amber-300 leading-tight">
                        Sundae Ice
                      </div>
                      <div className="text-[10px] font-mono text-emerald-400 font-bold">
                        Rp 7.000
                      </div>
                    </div>
                  </div>
                  <div className={`px-2 py-1 rounded text-xs font-mono font-black border ${
                    selectedSlot === 3
                      ? 'bg-amber-400 text-slate-950 border-amber-300'
                      : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}>
                    [ 3 ]
                  </div>
                </button>

                {/* SLOT 4: SUSU STROBERI */}
                <button
                  type="button"
                  onClick={() => onSelectSlot(4)}
                  className={`relative p-2 rounded-lg border-2 text-left cursor-pointer transition-all flex items-center justify-between group ${
                    selectedSlot === 4
                      ? 'bg-purple-900/90 border-amber-400 ring-2 ring-amber-400/80 shadow-lg'
                      : 'bg-slate-950/80 border-slate-700 hover:border-purple-400 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div className="relative w-10 h-10 flex items-center justify-center">
                      <div className={`absolute inset-0 border-2 border-dashed border-sky-400/60 rounded-full ${
                        isDispensing && selectedSlot === 4 ? 'animate-spin' : ''
                      }`} />
                      <span className="text-3xl filter drop-shadow group-hover:scale-110 transition-transform">
                        🧃
                      </span>
                    </div>
                    <div>
                      <div className="text-[11px] font-black text-amber-300 leading-tight">
                        Susu Stroberi
                      </div>
                      <div className="text-[10px] font-mono text-emerald-400 font-bold">
                        Rp 5.000
                      </div>
                    </div>
                  </div>
                  <div className={`px-2 py-1 rounded text-xs font-mono font-black border ${
                    selectedSlot === 4
                      ? 'bg-amber-400 text-slate-950 border-amber-300'
                      : 'bg-slate-800 text-slate-300 border-slate-700'
                  }`}>
                    [ 4 ]
                  </div>
                </button>
              </div>
            </div>

            {/* =================================================== */}
            {/* NAMPAN PENGAMBILAN MAKANAN BAWAH (DISPENSE CHUTE)  */}
            {/* =================================================== */}
            <div className="mt-auto bg-slate-900 border-3 border-slate-700 rounded-xl p-2.5 relative overflow-hidden shadow-2xl">
              
              {/* Header Nampan / Pintu Seng */}
              <div className="flex items-center justify-between pb-1.5 mb-1.5 border-b border-slate-800 text-[10px] font-mono">
                <span className="text-amber-400 font-bold flex items-center gap-1">
                  <ArrowDown className="w-3 h-3 text-amber-400 animate-bounce" />
                  <span>NAMPAN PENGAMBILAN (DISPENSE TRAY)</span>
                </span>
                <span className="bg-slate-800 text-slate-300 px-1.5 py-0.5 rounded text-[9px]">
                  PUSH FLAP
                </span>
              </div>

              {/* Rongga Dalam Nampan Tempat Makanan Jatuh */}
              <div className="h-20 bg-slate-950 rounded-lg border-2 border-slate-800 p-2 flex items-center justify-between relative overflow-hidden">
                
                {/* Efek Lampu Interior Nampan */}
                <div className="absolute top-0 inset-x-0 h-1 bg-amber-400/60 blur-[2px]" />

                {/* ANIMASI MAKANAN JATUH / BERADA DI NAMPAN */}
                {fallingSlot && items[fallingSlot] ? (
                  <div className="flex items-center justify-between w-full z-10">
                    <div className="flex items-center gap-3">
                      {/* Icon Makanan dengan Animasi Jatuh dan Membal */}
                      <div className={`relative ${
                        fallStage === 'dropping'
                          ? 'animate-bounce translate-y-1'
                          : fallStage === 'landed'
                          ? 'scale-105 transition-transform'
                          : ''
                      }`}>
                        <span className="text-5xl filter drop-shadow-md">
                          {items[fallingSlot].icon}
                        </span>
                        {fallStage === 'landed' && !hasPickedUp && (
                          <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full animate-ping" />
                        )}
                      </div>

                      {/* Teks Informasi Makanan di Nampan */}
                      <div>
                        <div className="text-[10px] font-mono text-emerald-400 font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                          <span>
                            {fallStage === 'spinning'
                              ? 'Pegas Sedang Berputar...'
                              : fallStage === 'dropping'
                              ? 'Makanan Meluncur Jatuh! 🚀'
                              : 'Makanan Sudah Di Nampan! 🎉'}
                          </span>
                        </div>
                        <div className="text-sm font-black text-amber-300">
                          {items[fallingSlot].name}
                        </div>
                        <div className="text-[10px] text-slate-300">
                          Kode #{fallingSlot} • {items[fallingSlot].price}
                        </div>
                      </div>
                    </div>

                    {/* Tombol Interaktif Ambil Makanan */}
                    {!hasPickedUp ? (
                      <button
                        type="button"
                        onClick={handlePickup}
                        className="px-3 py-2 bg-gradient-to-r from-amber-400 to-amber-300 hover:from-amber-300 hover:to-amber-200 text-slate-950 font-black text-xs rounded-lg border-2 border-slate-950 pop-card-sm cursor-pointer shadow-lg animate-pulse flex items-center gap-1.5 shrink-0"
                      >
                        <ShoppingBag className="w-4 h-4 text-slate-950" />
                        <span>AMBIL MAKANAN! ✋</span>
                      </button>
                    ) : (
                      <div className="px-2.5 py-1.5 bg-emerald-950/80 border border-emerald-500 text-emerald-300 rounded-lg text-xs font-bold font-mono flex items-center gap-1.5">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                        <span>SUDAH DIAMBIL! ⭐</span>
                      </div>
                    )}
                  </div>
                ) : fallingSlot === 9 ? (
                  /* KASUS DEFAULT / KODE SALAH */
                  <div className="flex items-center gap-3 w-full text-rose-400 z-10">
                    <span className="text-4xl animate-bounce">⚠️</span>
                    <div>
                      <div className="text-xs font-black text-rose-300 uppercase">
                        BLOK DEFAULT DIJALANKAN (BUZZER BUNYI!)
                      </div>
                      <div className="text-[10px] text-slate-300">
                        Kode [9] tidak terdaftar di daftar case 1, 2, 3, 4 mesin!
                      </div>
                    </div>
                  </div>
                ) : (
                  /* KONDISI AWAL KOSONG */
                  <div className="flex items-center justify-center w-full text-slate-500 text-xs font-mono gap-2">
                    <ShoppingBag className="w-4 h-4 text-slate-600" />
                    <span>Nampan Siap Menampung Makanan yang Jatuh...</span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* ===================================================== */}
          {/* SISI KANAN (4 Kolom): PANEL KONTROL KEYPAD & COIN      */}
          {/* ===================================================== */}
          <div className="md:col-span-4 flex flex-col justify-between bg-slate-950 rounded-xl border-3 border-slate-800 p-3">
            
            {/* 1. Layar LED Display Digital */}
            <div className="bg-slate-900 border-2 border-emerald-500/50 rounded-lg p-2.5 mb-3 shadow-inner">
              <div className="flex items-center justify-between text-[9px] font-mono text-emerald-500/80 border-b border-emerald-500/30 pb-1 mb-1">
                <span>DIGITAL LED DISPLAY</span>
                <span className="flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  ONLINE
                </span>
              </div>
              <div className="font-mono text-xs font-black text-emerald-300 tracking-wide truncate">
                {activeLedMessage}
              </div>
              <div className="mt-1 flex items-center justify-between text-[10px] font-mono">
                <span className="text-slate-400">SALDO:</span>
                <span className="text-amber-400 font-bold">
                  Rp {coinsInserted.toLocaleString('id-ID')}
                </span>
              </div>
            </div>

            {/* 2. Lubang Koin Logam & Masukkan Koin */}
            <div className="bg-slate-900/80 rounded-lg border border-slate-800 p-2 mb-3">
              <div className="flex items-center justify-between text-[10px] font-mono text-slate-300 mb-1.5">
                <span className="flex items-center gap-1 text-amber-300 font-bold">
                  <Coins className="w-3 h-3 text-amber-400" />
                  <span>LUBANG KOIN (COIN SLOT)</span>
                </span>
              </div>
              
              {/* Lubang Fisik Koin */}
              <div className="h-3 w-16 mx-auto bg-black border border-slate-700 rounded-full mb-2 shadow-inner" />

              {/* Tombol Cepat Tambah Koin */}
              {onInsertCoin && (
                <div className="flex gap-1 text-[10px]">
                  <button
                    type="button"
                    onClick={() => onInsertCoin(5000)}
                    className="flex-1 py-1 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black rounded border border-slate-950 cursor-pointer text-center"
                  >
                    +5rb Koin
                  </button>
                  <button
                    type="button"
                    onClick={() => onInsertCoin(10000)}
                    className="flex-1 py-1 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black rounded border border-slate-950 cursor-pointer text-center"
                  >
                    +10rb Koin
                  </button>
                </div>
              )}
            </div>

            {/* 3. Keypad Fisik Angka Vending (1 - 4 & 9) */}
            <div className="bg-slate-900/90 rounded-lg border-2 border-slate-800 p-2.5">
              <div className="text-[10px] font-mono text-purple-300 font-bold mb-2 flex items-center justify-between">
                <span>KEYPAD PILIH MAKANAN:</span>
                <span className="text-amber-400">KODE [{selectedSlot}]</span>
              </div>

              {/* Grid Tombol Chunky */}
              <div className="grid grid-cols-2 gap-2 mb-2">
                {[1, 2, 3, 4].map((slot) => {
                  const it = items[slot];
                  const isCur = selectedSlot === slot;
                  return (
                    <button
                      key={slot}
                      type="button"
                      onClick={() => onSelectSlot(slot)}
                      className={`p-2 rounded-lg font-black text-xs border-2 cursor-pointer transition-all flex items-center justify-between ${
                        isCur
                          ? 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white border-amber-400 ring-2 ring-amber-400/80 shadow-md scale-105'
                          : 'bg-slate-800 hover:bg-slate-700 text-slate-200 border-slate-700'
                      }`}
                    >
                      <span className="text-base">{it?.icon}</span>
                      <span className="font-mono text-sm font-black">[{slot}]</span>
                    </button>
                  );
                })}
              </div>

              {/* Tombol Uji Kasus Default (Salah Kode [9]) */}
              <button
                type="button"
                onClick={() => onSelectSlot(9)}
                className={`w-full py-1.5 px-2 rounded-lg text-xs font-black border-2 cursor-pointer transition-all flex items-center justify-between ${
                  selectedSlot === 9
                    ? 'bg-rose-600 text-white border-rose-400 ring-2 ring-rose-400 shadow-md'
                    : 'bg-rose-950/60 hover:bg-rose-900/80 text-rose-300 border-rose-800'
                }`}
                title="Tekan untuk menguji apa yang terjadi saat kode tidak terdaftar (Default Block)"
              >
                <span className="flex items-center gap-1 text-[11px]">
                  <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                  <span>Uji Kode Salah [ 9 ]</span>
                </span>
                <span className="font-mono text-[10px] bg-rose-900 px-1.5 py-0.5 rounded text-rose-200">
                  DEFAULT
                </span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* ========================================================= */}
      {/* TULISAN DAN VISUAL MAKANAN LUMAYAN BESAR                  */}
      {/* (SESUAI PERMINTAAN USER: JELAS, BESAR, INTERAKTIF)       */}
      {/* ========================================================= */}
      {dispensedItem ? (
        <div className="w-full bg-gradient-to-r from-amber-50 via-purple-50 to-amber-50 border-4 border-slate-950 rounded-2xl p-4 sm:p-5 pop-card shadow-xl animate-fadeIn">
          
          {/* Header Banner Makanan Keluar */}
          <div className="flex items-center justify-between pb-3 mb-3 border-b-2 border-slate-950/20">
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-1 bg-emerald-500 text-slate-950 font-black text-xs rounded-full border-2 border-slate-950 flex items-center gap-1 shadow-sm">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>MAKANAN BERHASIL KELUAR!</span>
              </span>
              <span className="font-mono text-xs font-bold text-purple-900 bg-purple-200/80 px-2 py-0.5 rounded border border-purple-400">
                CASE {selectedSlot} TERPENUHI
              </span>
            </div>
            <div className="text-xs font-mono font-bold text-slate-700">
              Harga: <span className="text-emerald-700 font-black">{dispensedItem.price}</span>
            </div>
          </div>

          {/* BODY: VISUAL MAKANAN LUMAYAN BESAR */}
          <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6">
            
            {/* ICON / VISUAL MAKANAN SUPER BESAR DENGAN FRAME POP */}
            <div className="relative shrink-0 w-28 h-28 sm:w-32 sm:h-32 rounded-2xl bg-gradient-to-br from-amber-300 via-amber-200 to-purple-300 border-4 border-slate-950 flex items-center justify-center pop-card shadow-lg group">
              <span className="text-6xl sm:text-7xl filter drop-shadow-lg transform group-hover:scale-110 transition-transform animate-bounce">
                {dispensedItem.icon}
              </span>
              <span className="absolute -top-2 -right-2 bg-slate-950 text-amber-300 text-[10px] font-mono font-black px-2 py-0.5 rounded-full border border-amber-300">
                #{selectedSlot}
              </span>
            </div>

            {/* TEKS INFORMASI LENGKAP & SWITCH CASE EXPLANATION */}
            <div className="flex-1 text-center sm:text-left">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-1">
                <h3 className="text-xl sm:text-2xl font-black text-slate-950 uppercase tracking-tight">
                  {dispensedItem.name}
                </h3>
                <span className="bg-amber-400 text-slate-950 font-black px-2.5 py-0.5 rounded-full text-xs border border-slate-950">
                  {dispensedItem.price}
                </span>
              </div>

              {/* Deskripsi Rasa */}
              <p className="text-xs sm:text-sm text-slate-700 font-medium mb-2.5 leading-relaxed">
                {dispensedItem.desc || 'Makanan lezat favorit kantin sekolah yang siap dinikmati siswa!'}
              </p>

              {/* Kotak Edukasi Switch Case */}
              <div className="p-2.5 bg-white rounded-xl border-2 border-slate-900 text-xs font-mono text-slate-800 shadow-sm">
                <div className="flex items-center gap-1.5 text-purple-700 font-bold mb-1">
                  <Zap className="w-3.5 h-3.5 text-purple-600" />
                  <span>KODE SWITCH-CASE YANG BERHASIL:</span>
                </div>
                <div className="text-[11px] text-slate-600">
                  Komputer mengevaluasi <code className="text-purple-700 font-black">kodeMakanan = {selectedSlot}</code>, langsung melompat tanpa ragu ke <code className="text-emerald-700 font-black">case {selectedSlot}:</code> dan mengeksekusi instruksi <code className="text-amber-700 font-black">keluarkanMakanan("{dispensedItem.name}")</code>!
                </div>
              </div>
            </div>
          </div>

          {/* Interaksi Nikmati Makanan */}
          <div className="mt-4 pt-3 border-t-2 border-slate-950/20 flex flex-wrap items-center justify-between gap-2">
            <div className="text-xs font-bold text-slate-600 flex items-center gap-1.5">
              <Gift className="w-4 h-4 text-purple-600" />
              <span>Simulasi Pengeluaran Makanan Kantin Selesai!</span>
            </div>

            <button
              type="button"
              onClick={handlePickup}
              className="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white font-black text-xs rounded-xl border-2 border-slate-950 pop-card-sm cursor-pointer shadow-md flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>{hasPickedUp ? 'Nikmati Makanan Lagi! ⭐' : 'Ambil & Nikmati Makanan! 😋'}</span>
            </button>
          </div>
        </div>
      ) : selectedSlot === 9 ? (
        /* TAMPILAN ERROR KODE SALAH DENGAN VISUAL BESAR */
        <div className="w-full bg-rose-50 border-4 border-slate-950 rounded-2xl p-4 sm:p-5 pop-card shadow-xl animate-fadeIn">
          <div className="flex items-center gap-4">
            <div className="w-20 h-20 rounded-2xl bg-rose-200 border-4 border-slate-950 flex items-center justify-center shrink-0">
              <span className="text-5xl">⚠️</span>
            </div>
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2.5 py-0.5 bg-rose-600 text-white font-black text-xs rounded-full border border-slate-950">
                  DEFAULT CASE DIEKSEKUSI
                </span>
                <span className="font-mono text-xs font-bold text-rose-800">
                  KODE [ 9 ] TIDAK TERDAFTAR
                </span>
              </div>
              <h3 className="text-lg font-black text-slate-950">
                ❌ Tidak Ada Makanan di Slot Nomor 9!
              </h3>
              <p className="text-xs text-slate-700 mt-1 leading-relaxed">
                Karena tidak ada <code className="font-bold">case 9:</code>, switch-case otomatis melompat ke blok <code className="font-bold text-rose-700">default:</code>. Mesin membunyikan buzzer peringatan agar kamu memilih angka yang ada di etalase (1 sampai 4).
              </p>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
