import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { RotateCw, ZoomIn, ZoomOut, Eye, Sparkles } from 'lucide-react';

export interface Vending3DProps {
  selectedSlot: number;
  isDispensing: boolean;
  onSelectSlot: (slot: number) => void;
  items: Record<
    number,
    { name: string; price: string; icon: string; priceNum: number; desc: string }
  >;
  dispensedItem: { name: string; price: string; icon: string; priceNum: number } | null;
  coinsInserted: number;
}

export function VendingMachine3D({
  selectedSlot,
  isDispensing,
  onSelectSlot,
  items,
  dispensedItem,
  coinsInserted
}: Vending3DProps) {
  const canvasMountRef = useRef<HTMLDivElement>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const animFrameId = useRef<number | null>(null);

  // Interaction & camera rotation state
  const isDragging = useRef<boolean>(false);
  const previousMousePosition = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const machineGroupRef = useRef<THREE.Group | null>(null);
  const targetRotationY = useRef<number>(0.15);
  const targetRotationX = useRef<number>(0.05);

  // References to animated 3D meshes
  const coilsRef = useRef<Record<number, THREE.Mesh>>({});
  const productsOnShelfRef = useRef<Record<number, THREE.Group>>({});
  const droppingItemRef = useRef<THREE.Group | null>(null);
  const bottomFlapRef = useRef<THREE.Mesh | null>(null);
  const ledCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const ledTextureRef = useRef<THREE.CanvasTexture | null>(null);
  const internalLightRef = useRef<THREE.PointLight | null>(null);
  const slotBadgesRef = useRef<Record<number, THREE.Mesh>>({});
  const buttonMeshesRef = useRef<Record<number, THREE.Mesh>>({});

  // Drop animation physics state
  const dropState = useRef<{
    active: boolean;
    slot: number;
    t: number;
    startY: number;
    targetY: number;
    currentY: number;
    rotX: number;
    rotZ: number;
  }>({
    active: false,
    slot: 1,
    t: 0,
    startY: 0.5,
    targetY: -1.45,
    currentY: 0.5,
    rotX: 0,
    rotZ: 0
  });

  const [cameraZoom, setCameraZoom] = useState<number>(5.2);
  const [autoRotate, setAutoRotate] = useState<boolean>(false);
  const autoRotateRef = useRef<boolean>(autoRotate);
  autoRotateRef.current = autoRotate;

  // Helper to create a helical spring curve (pegas spiral kawat)
  const createSpringGeometry = (radius: number, length: number, turns: number) => {
    const points: THREE.Vector3[] = [];
    const count = turns * 40;
    for (let i = 0; i <= count; i++) {
      const u = i / count;
      const angle = u * Math.PI * 2 * turns;
      const x = Math.cos(angle) * radius;
      const y = Math.sin(angle) * radius;
      const z = (u - 0.5) * length;
      points.push(new THREE.Vector3(x, y, z));
    }
    const curve = new THREE.CatmullRomCurve3(points);
    return new THREE.TubeGeometry(curve, count, 0.022, 8, false);
  };

  // Helper to build 3D Boba Cup
  const createBobaCup = () => {
    const group = new THREE.Group();
    // Clear transparent cup
    const cupGeo = new THREE.CylinderGeometry(0.24, 0.18, 0.55, 20);
    const cupMat = new THREE.MeshPhysicalMaterial({
      color: 0x92400e, // milk tea color
      roughness: 0.1,
      metalness: 0.05,
      transparent: true,
      opacity: 0.85
    });
    const cup = new THREE.Mesh(cupGeo, cupMat);
    group.add(cup);

    // Cream foam top
    const foamGeo = new THREE.CylinderGeometry(0.24, 0.23, 0.08, 20);
    const foamMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.6 });
    const foam = new THREE.Mesh(foamGeo, foamMat);
    foam.position.y = 0.24;
    group.add(foam);

    // Dome lid
    const lidGeo = new THREE.SphereGeometry(0.24, 16, 12, 0, Math.PI * 2, 0, Math.PI * 0.45);
    const lidMat = new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: 0.6 });
    const lid = new THREE.Mesh(lidGeo, lidMat);
    lid.position.y = 0.28;
    group.add(lid);

    // Purple fat straw
    const strawGeo = new THREE.CylinderGeometry(0.022, 0.022, 0.4, 10);
    const strawMat = new THREE.MeshStandardMaterial({ color: 0x8b5cf6, roughness: 0.3 });
    const straw = new THREE.Mesh(strawGeo, strawMat);
    straw.position.set(0.04, 0.38, 0.04);
    straw.rotation.z = -0.25;
    group.add(straw);

    // Boba pearls at bottom
    const pearlGeo = new THREE.SphereGeometry(0.035, 8, 8);
    const pearlMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.3 });
    const pearlPositions = [
      [-0.08, -0.22, 0.05],
      [0.06, -0.21, -0.04],
      [-0.02, -0.2, -0.08],
      [0.05, -0.22, 0.06],
      [-0.05, -0.16, 0.02],
      [0.02, -0.15, -0.03]
    ];
    pearlPositions.forEach(([px, py, pz]) => {
      const pearl = new THREE.Mesh(pearlGeo, pearlMat);
      pearl.position.set(px, py, pz);
      group.add(pearl);
    });

    return group;
  };

  // Helper to build 3D Toasted Sandwich Snack
  const createSandwich = () => {
    const group = new THREE.Group();
    // Puffy foil packaging
    const packGeo = new THREE.BoxGeometry(0.42, 0.52, 0.16);
    const packMat = new THREE.MeshStandardMaterial({
      color: 0xf59e0b,
      metalness: 0.65,
      roughness: 0.25
    });
    const pack = new THREE.Mesh(packGeo, packMat);
    group.add(pack);

    // Center cheese label banner
    const labelGeo = new THREE.BoxGeometry(0.44, 0.18, 0.17);
    const labelMat = new THREE.MeshStandardMaterial({ color: 0xfef08a, roughness: 0.4 });
    const label = new THREE.Mesh(labelGeo, labelMat);
    group.add(label);

    // Crinkle sealed ends
    const sealGeo = new THREE.BoxGeometry(0.44, 0.04, 0.03);
    const sealMat = new THREE.MeshStandardMaterial({ color: 0xb45309, metalness: 0.7 });
    const topSeal = new THREE.Mesh(sealGeo, sealMat);
    topSeal.position.y = 0.26;
    const botSeal = new THREE.Mesh(sealGeo, sealMat);
    botSeal.position.y = -0.26;
    group.add(topSeal, botSeal);

    return group;
  };

  // Helper to build 3D Sundae Ice Cream
  const createSundae = () => {
    const group = new THREE.Group();
    // Glass cup
    const cupGeo = new THREE.CylinderGeometry(0.24, 0.12, 0.35, 16);
    const cupMat = new THREE.MeshPhysicalMaterial({
      color: 0xe0f2fe,
      roughness: 0.1,
      transparent: true,
      opacity: 0.75
    });
    const cup = new THREE.Mesh(cupGeo, cupMat);
    group.add(cup);

    // Stem & base
    const baseGeo = new THREE.CylinderGeometry(0.18, 0.18, 0.04, 16);
    const stemGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.12, 10);
    const baseMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.5 });
    const stem = new THREE.Mesh(stemGeo, baseMat);
    stem.position.y = -0.23;
    const base = new THREE.Mesh(baseGeo, baseMat);
    base.position.y = -0.29;
    group.add(stem, base);

    // Three scoops: pink (strawberry), brown (choco), white (vanilla)
    const scoopGeo = new THREE.SphereGeometry(0.13, 12, 12);
    const scoopPink = new THREE.Mesh(scoopGeo, new THREE.MeshStandardMaterial({ color: 0xf43f5e, roughness: 0.8 }));
    scoopPink.position.set(-0.08, 0.22, 0.05);

    const scoopChoco = new THREE.Mesh(scoopGeo, new THREE.MeshStandardMaterial({ color: 0x451a03, roughness: 0.8 }));
    scoopChoco.position.set(0.08, 0.22, 0.05);

    const scoopVanilla = new THREE.Mesh(scoopGeo, new THREE.MeshStandardMaterial({ color: 0xfef3c7, roughness: 0.8 }));
    scoopVanilla.position.set(0, 0.32, -0.04);
    group.add(scoopPink, scoopChoco, scoopVanilla);

    // Red cherry on top
    const cherryGeo = new THREE.SphereGeometry(0.05, 10, 10);
    const cherryMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, roughness: 0.2 });
    const cherry = new THREE.Mesh(cherryGeo, cherryMat);
    cherry.position.set(0, 0.44, 0);
    group.add(cherry);

    return group;
  };

  // Helper to build 3D Strawberry Milk Carton
  const createMilkCarton = () => {
    const group = new THREE.Group();
    // Main carton body
    const bodyGeo = new THREE.BoxGeometry(0.34, 0.45, 0.32);
    const bodyMat = new THREE.MeshStandardMaterial({ color: 0xfce7f3, roughness: 0.4 });
    const body = new THREE.Mesh(bodyGeo, bodyMat);
    group.add(body);

    // Pink brand stripe
    const stripeGeo = new THREE.BoxGeometry(0.35, 0.2, 0.33);
    const stripeMat = new THREE.MeshStandardMaterial({ color: 0xec4899, roughness: 0.4 });
    const stripe = new THREE.Mesh(stripeGeo, stripeMat);
    group.add(stripe);

    // Gable top (slanted carton roof)
    const roofGeo = new THREE.ConeGeometry(0.24, 0.18, 4);
    const roofMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.4 });
    const roof = new THREE.Mesh(roofGeo, roofMat);
    roof.position.y = 0.31;
    roof.rotation.y = Math.PI / 4;
    roof.scale.set(1.1, 1, 1.1);
    group.add(roof);

    // Straw attached to side
    const strawGeo = new THREE.CylinderGeometry(0.018, 0.018, 0.42, 8);
    const strawMat = new THREE.MeshStandardMaterial({ color: 0x38bdf8, roughness: 0.3 });
    const straw = new THREE.Mesh(strawGeo, strawMat);
    straw.position.set(0.18, 0.05, 0.1);
    straw.rotation.z = -0.15;
    group.add(straw);

    return group;
  };

  // Factory to create product by slot
  const createProductMesh = (slot: number) => {
    switch (slot) {
      case 1:
        return createBobaCup();
      case 2:
        return createSandwich();
      case 3:
        return createSundae();
      case 4:
        return createMilkCarton();
      default:
        return createBobaCup();
    }
  };

  // Update LED Canvas Texture
  const updateLEDDisplay = useCallback(() => {
    if (!ledCanvasRef.current || !ledTextureRef.current) return;
    const canvas = ledCanvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = '#0f172a';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Glowing border
    ctx.strokeStyle = '#a855f7';
    ctx.lineWidth = 4;
    ctx.strokeRect(4, 4, canvas.width - 8, canvas.height - 8);

    // Matrix LED text
    ctx.fillStyle = '#f59e0b';
    ctx.font = 'bold 20px monospace';
    ctx.textAlign = 'left';
    ctx.fillText(`SLOT: [${selectedSlot}]`, 16, 32);

    ctx.fillStyle = '#4ade80';
    ctx.font = 'bold 16px monospace';
    const item = items[selectedSlot];
    if (item) {
      ctx.fillText(item.price, 16, 56);
      ctx.fillStyle = '#38bdf8';
      ctx.font = '12px sans-serif';
      ctx.fillText(item.name.substring(0, 18), 16, 78);
    } else {
      ctx.fillStyle = '#f43f5e';
      ctx.fillText('ERR: KODE [9]', 16, 56);
      ctx.fillText('DEFAULT CASE', 16, 78);
    }

    ctx.fillStyle = '#e2e8f0';
    ctx.font = '11px monospace';
    ctx.fillText(`SALDO: Rp ${coinsInserted.toLocaleString('id-ID')}`, 16, 100);

    ledTextureRef.current.needsUpdate = true;
  }, [selectedSlot, coinsInserted, items]);

  // Main Three.js Scene Setup
  useEffect(() => {
    const mount = canvasMountRef.current;
    if (!mount) return;
    const width = mount.clientWidth || 400;
    const height = mount.clientHeight || 480;

    // 1. Scene & Camera
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x0f172a); // dark slate

    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    camera.position.set(0, 0.3, cameraZoom);
    cameraRef.current = camera;

    // 2. WebGL Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance' });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    rendererRef.current = renderer;

    // Safely append canvas into the dedicated isolated mount div (no React children here)
    while (mount.firstChild) {
      mount.removeChild(mount.firstChild);
    }
    mount.appendChild(renderer.domElement);

    // 3. Lighting
    // Ambient light
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    // Key front light
    const keyLight = new THREE.DirectionalLight(0xffedd5, 1.4);
    keyLight.position.set(3, 4, 4);
    keyLight.castShadow = true;
    keyLight.shadow.mapSize.width = 1024;
    keyLight.shadow.mapSize.height = 1024;
    scene.add(keyLight);

    // Cyan/Purple Rim Light
    const rimLight = new THREE.DirectionalLight(0xc084fc, 1.0);
    rimLight.position.set(-3, 3, -2);
    scene.add(rimLight);

    // Warm Interior Shelf Point Light
    const internalLight = new THREE.PointLight(0xfef08a, 1.8, 4.5);
    internalLight.position.set(0, 0.8, 0.3);
    scene.add(internalLight);
    internalLightRef.current = internalLight;

    // Drop hatch spotlight
    const dropSpotLight = new THREE.SpotLight(0x38bdf8, 2.0, 3, Math.PI / 4, 0.5);
    dropSpotLight.position.set(0, -0.6, 0.8);
    dropSpotLight.target.position.set(0, -1.4, 0.4);
    scene.add(dropSpotLight);
    scene.add(dropSpotLight.target);

    // 4. Construct Vending Machine Master Group
    const machineGroup = new THREE.Group();
    machineGroupRef.current = machineGroup;
    scene.add(machineGroup);

    // Outer Cabinet Dimensions: W=2.7, H=4.1, D=1.9
    // Cabinet Body Outer Frame
    const cabinetMat = new THREE.MeshStandardMaterial({
      color: 0x1e1b4b, // Deep Indigo Metallic
      metalness: 0.45,
      roughness: 0.35
    });

    // Main Chassis
    const chassisGeo = new THREE.BoxGeometry(2.7, 4.1, 1.9);
    const chassis = new THREE.Mesh(chassisGeo, cabinetMat);
    chassis.castShadow = true;
    chassis.receiveShadow = true;
    machineGroup.add(chassis);

    // Inner Cutout / Showcase Recess
    const cavityMat = new THREE.MeshStandardMaterial({
      color: 0x09090b,
      roughness: 0.8
    });
    const cavityGeo = new THREE.BoxGeometry(1.9, 2.4, 1.2);
    const cavity = new THREE.Mesh(cavityGeo, cavityMat);
    cavity.position.set(-0.25, 0.4, 0.38);
    machineGroup.add(cavity);

    // White Interior Side Mirror Accents
    const innerTrimGeo = new THREE.BoxGeometry(0.04, 2.38, 1.15);
    const innerTrimMat = new THREE.MeshStandardMaterial({ color: 0x64748b, metalness: 0.8, roughness: 0.2 });
    const innerTrimL = new THREE.Mesh(innerTrimGeo, innerTrimMat);
    innerTrimL.position.set(-1.18, 0.4, 0.38);
    const innerTrimR = new THREE.Mesh(innerTrimGeo, innerTrimMat);
    innerTrimR.position.set(0.68, 0.4, 0.38);
    machineGroup.add(innerTrimL, innerTrimR);

    // Top Illuminated Header Marquee ("SMART VENDING 3D")
    const marqueeGeo = new THREE.BoxGeometry(2.5, 0.5, 0.1);
    const marqueeMat = new THREE.MeshStandardMaterial({
      color: 0xa855f7,
      emissive: 0x7e22ce,
      emissiveIntensity: 0.6,
      roughness: 0.2
    });
    const marquee = new THREE.Mesh(marqueeGeo, marqueeMat);
    marquee.position.set(0, 1.8, 0.96);
    machineGroup.add(marquee);

    // Translucent Front Glass Window (Kaca Tem羅s Pandang Nyata)
    const glassGeo = new THREE.BoxGeometry(1.92, 2.42, 0.06);
    const glassMat = new THREE.MeshPhysicalMaterial({
      color: 0xffffff,
      transparent: true,
      opacity: 0.28,
      roughness: 0.08,
      metalness: 0.1,
      transmission: 0.85,
      ior: 1.5,
      reflectivity: 0.8
    });
    const glass = new THREE.Mesh(glassGeo, glassMat);
    glass.position.set(-0.25, 0.4, 0.97);
    machineGroup.add(glass);

    // Shelf Wire Racks (2 Shelves: Atas & Bawah)
    const shelfMat = new THREE.MeshStandardMaterial({
      color: 0x94a3b8,
      metalness: 0.85,
      roughness: 0.2
    });
    const shelfGeo = new THREE.BoxGeometry(1.88, 0.05, 1.1);

    // Shelf Top (Slots 1 & 2)
    const shelfTop = new THREE.Mesh(shelfGeo, shelfMat);
    shelfTop.position.set(-0.25, 0.85, 0.38);
    // Shelf Bottom (Slots 3 & 4)
    const shelfBot = new THREE.Mesh(shelfGeo, shelfMat);
    shelfBot.position.set(-0.25, -0.25, 0.38);
    machineGroup.add(shelfTop, shelfBot);

    // Shelf Front Price Label Strips
    const labelStripGeo = new THREE.BoxGeometry(1.88, 0.08, 0.04);
    const labelStripMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.3 });
    const labelStripTop = new THREE.Mesh(labelStripGeo, labelStripMat);
    labelStripTop.position.set(-0.25, 0.85, 0.94);
    const labelStripBot = new THREE.Mesh(labelStripGeo, labelStripMat);
    labelStripBot.position.set(-0.25, -0.25, 0.94);
    machineGroup.add(labelStripTop, labelStripBot);

    // Helical Spiral Coils & Products on Shelves
    // Slots coordinate mapping:
    // Slot 1: Top Left   [-0.72, 1.25]
    // Slot 2: Top Right  [ 0.22, 1.25]
    // Slot 3: Bot Left   [-0.72, 0.15]
    // Slot 4: Bot Right  [ 0.22, 0.15]
    const slotCoords: Record<number, { x: number; y: number; z: number }> = {
      1: { x: -0.72, y: 1.22, z: 0.45 },
      2: { x: 0.22, y: 1.22, z: 0.45 },
      3: { x: -0.72, y: 0.12, z: 0.45 },
      4: { x: 0.22, y: 0.12, z: 0.45 }
    };

    const coils: Record<number, THREE.Mesh> = {};
    const shelfProducts: Record<number, THREE.Group> = {};

    [1, 2, 3, 4].forEach((slot) => {
      const coord = slotCoords[slot];

      // 3D Metal Wire Spring Behind Product
      const springGeo = createSpringGeometry(0.24, 0.75, 4.5);
      const springMat = new THREE.MeshStandardMaterial({
        color: 0xd1d5db,
        metalness: 0.9,
        roughness: 0.2
      });
      const spring = new THREE.Mesh(springGeo, springMat);
      spring.position.set(coord.x, coord.y - 0.05, coord.z - 0.15);
      spring.rotation.x = Math.PI / 2;
      machineGroup.add(spring);
      coils[slot] = spring;

      // 3D Product Mesh on Shelf
      const prodGroup = createProductMesh(slot);
      prodGroup.position.set(coord.x, coord.y, coord.z);
      machineGroup.add(prodGroup);
      shelfProducts[slot] = prodGroup;

      // Add a small 3D slot number badge on the shelf lip
      const badgeGeo = new THREE.BoxGeometry(0.22, 0.08, 0.03);
      const badgeMat = new THREE.MeshStandardMaterial({
        color: slot === selectedSlot ? 0xf59e0b : 0x1e293b,
        emissive: slot === selectedSlot ? 0xb45309 : 0x000000,
        emissiveIntensity: 0.4
      });
      const badge = new THREE.Mesh(badgeGeo, badgeMat);
      badge.position.set(coord.x, coord.y - 0.36, 0.96);
      machineGroup.add(badge);
      slotBadgesRef.current[slot] = badge;
    });

    coilsRef.current = coils;
    productsOnShelfRef.current = shelfProducts;

    // Bottom Dispense Chute Compartment (Nampan Pengambilan)
    const hatchCavityGeo = new THREE.BoxGeometry(1.9, 0.75, 0.85);
    const hatchCavityMat = new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.9 });
    const hatchCavity = new THREE.Mesh(hatchCavityGeo, hatchCavityMat);
    hatchCavity.position.set(-0.25, -1.35, 0.5);
    machineGroup.add(hatchCavity);

    // Swinging Flap Door (Pintu Seng Berengsel Nampan)
    const flapGeo = new THREE.BoxGeometry(1.84, 0.65, 0.05);
    const flapMat = new THREE.MeshStandardMaterial({
      color: 0x334155,
      metalness: 0.7,
      roughness: 0.3
    });
    const flap = new THREE.Mesh(flapGeo, flapMat);
    flap.position.set(-0.25, -1.35, 0.96);
    machineGroup.add(flap);
    bottomFlapRef.current = flap;

    // "PUSH / AMBIL DI SINI" Decal Bar on Flap
    const pushBarGeo = new THREE.BoxGeometry(1.2, 0.16, 0.06);
    const pushBarMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, roughness: 0.4 });
    const pushBar = new THREE.Mesh(pushBarGeo, pushBarMat);
    pushBar.position.set(-0.25, -1.35, 0.99);
    machineGroup.add(pushBar);

    // Right Side Interactive Control Column
    // 1. Digital LED Display Screen
    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 128;
    ledCanvasRef.current = canvas;
    const ledTexture = new THREE.CanvasTexture(canvas);
    ledTextureRef.current = ledTexture;

    const ledScreenGeo = new THREE.PlaneGeometry(0.65, 0.36);
    const ledScreenMat = new THREE.MeshBasicMaterial({ map: ledTexture });
    const ledScreen = new THREE.Mesh(ledScreenGeo, ledScreenMat);
    ledScreen.position.set(0.98, 0.92, 0.96);
    machineGroup.add(ledScreen);

    // 2. Physical Coin Slot (Lubang Koin Logam)
    const coinRimGeo = new THREE.BoxGeometry(0.45, 0.16, 0.06);
    const coinRimMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, metalness: 0.9, roughness: 0.1 });
    const coinRim = new THREE.Mesh(coinRimGeo, coinRimMat);
    coinRim.position.set(0.98, 0.58, 0.96);

    const coinSlotHoleGeo = new THREE.BoxGeometry(0.24, 0.03, 0.08);
    const coinSlotHole = new THREE.Mesh(coinSlotHoleGeo, new THREE.MeshBasicMaterial({ color: 0x000000 }));
    coinSlotHole.position.set(0.98, 0.58, 0.97);
    machineGroup.add(coinRim, coinSlotHole);

    // 3. Banknote Acceptor Slot (Penerima Uang Kertas dengan Lampu Hijau)
    const billGeo = new THREE.BoxGeometry(0.52, 0.12, 0.05);
    const billMat = new THREE.MeshStandardMaterial({ color: 0x10b981, emissive: 0x059669, emissiveIntensity: 0.5 });
    const billSlot = new THREE.Mesh(billGeo, billMat);
    billSlot.position.set(0.98, 0.38, 0.96);
    machineGroup.add(billSlot);

    // 4. Keypad Buttons [1], [2], [3], [4], and [9]
    const buttonPositions = [
      { num: 1, pos: [0.86, 0.12] },
      { num: 2, pos: [1.1, 0.12] },
      { num: 3, pos: [0.86, -0.08] },
      { num: 4, pos: [1.1, -0.08] },
      { num: 9, pos: [0.98, -0.28] } // Test error button
    ];

    buttonPositions.forEach(({ num, pos }) => {
      const btnGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.04, 16);
      const isCurrent = num === selectedSlot;
      const btnMat = new THREE.MeshStandardMaterial({
        color: num === 9 ? 0xf43f5e : isCurrent ? 0xa855f7 : 0xe2e8f0,
        emissive: isCurrent ? 0x7e22ce : 0x000000,
        emissiveIntensity: 0.4,
        roughness: 0.3
      });
      const btn = new THREE.Mesh(btnGeo, btnMat);
      btn.rotation.x = Math.PI / 2;
      btn.position.set(pos[0], pos[1], 0.97);
      machineGroup.add(btn);
      buttonMeshesRef.current[num] = btn;
    });

    // Initial LED paint
    updateLEDDisplay();

    // 5. Animation Loop
    let lastTime = performance.now();
    const animate = () => {
      animFrameId.current = requestAnimationFrame(animate);
      const now = performance.now();
      const delta = (now - lastTime) / 1000;
      lastTime = now;

      // Handle auto-rotate if enabled
      if (autoRotateRef.current && !isDragging.current) {
        targetRotationY.current += 0.35 * delta;
      }

      // Smooth damped rotation
      if (machineGroupRef.current) {
        machineGroupRef.current.rotation.y += (targetRotationY.current - machineGroupRef.current.rotation.y) * 0.1;
        machineGroupRef.current.rotation.x += (targetRotationX.current - machineGroupRef.current.rotation.x) * 0.1;
      }

      // Handle Drop Physics Animation
      if (dropState.current.active && droppingItemRef.current) {
        const ds = dropState.current;
        ds.t += delta * 2.2; // Speed of drop

        // Gravitational fall curve
        const progress = Math.min(1, ds.t);
        // Easing with bounce at bottom
        let easeY: number;
        if (progress < 0.7) {
          // Fall
          const p = progress / 0.7;
          easeY = ds.startY + (ds.targetY - ds.startY) * (p * p);
        } else {
          // Bounce
          const p = (progress - 0.7) / 0.3;
          const bounceHeight = 0.18 * (1 - p);
          easeY = ds.targetY + Math.sin(p * Math.PI) * bounceHeight;
        }

        droppingItemRef.current.position.y = easeY;
        droppingItemRef.current.position.z = 0.45 + Math.sin(progress * Math.PI * 0.7) * 0.25;
        droppingItemRef.current.rotation.x += delta * 4;
        droppingItemRef.current.rotation.z += delta * 2;

        // Animate door flap open when passing through
        if (bottomFlapRef.current) {
          if (progress > 0.45 && progress < 0.95) {
            bottomFlapRef.current.rotation.x = -Math.PI / 3.5; // open
          } else {
            bottomFlapRef.current.rotation.x *= 0.85; // spring back
          }
        }

        if (progress >= 1) {
          dropState.current.active = false;
          // Product settles in bottom bin
          droppingItemRef.current.position.y = ds.targetY;
          droppingItemRef.current.rotation.x = Math.PI / 8;
        }
      }

      renderer.render(scene, camera);
    };

    animate();

    // Resize Observer for robust responsive layout
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width: w, height: h } = entry.contentRect;
        if (w > 0 && h > 0 && cameraRef.current && rendererRef.current) {
          cameraRef.current.aspect = w / h;
          cameraRef.current.updateProjectionMatrix();
          rendererRef.current.setSize(w, h);
        }
      }
    });

    resizeObserver.observe(mount);

    // Cleanup on unmount
    return () => {
      if (animFrameId.current) cancelAnimationFrame(animFrameId.current);
      resizeObserver.disconnect();
      if (renderer.domElement.parentNode) {
        renderer.domElement.parentNode.removeChild(renderer.domElement);
      }
      renderer.dispose();
      scene.clear();
    };
  }, []); // Initialize scene only once

  // Sync zoom changes with camera without rebuilding the scene
  useEffect(() => {
    if (cameraRef.current) {
      cameraRef.current.position.z = cameraZoom;
    }
  }, [cameraZoom]);

  // Update LED and slot/button mesh materials dynamically when selectedSlot changes
  useEffect(() => {
    Object.entries(slotBadgesRef.current).forEach(([slotStr, mesh]) => {
      const slot = Number(slotStr);
      const isCurrent = slot === selectedSlot;
      const mat = mesh.material as THREE.MeshStandardMaterial;
      if (mat) {
        mat.color.setHex(isCurrent ? 0xf59e0b : 0x1e293b);
        mat.emissive.setHex(isCurrent ? 0xb45309 : 0x000000);
      }
    });

    Object.entries(buttonMeshesRef.current).forEach(([numStr, mesh]) => {
      const num = Number(numStr);
      const isCurrent = num === selectedSlot;
      const mat = mesh.material as THREE.MeshStandardMaterial;
      if (mat) {
        mat.color.setHex(num === 9 ? 0xf43f5e : isCurrent ? 0xa855f7 : 0xe2e8f0);
        mat.emissive.setHex(isCurrent ? 0x7e22ce : 0x000000);
      }
    });

    updateLEDDisplay();
  }, [selectedSlot, updateLEDDisplay]);

  // Handle Dispense Physics Trigger
  useEffect(() => {
    if (isDispensing && sceneRef.current && machineGroupRef.current) {
      // 1. Rotate the target spring coil 360 deg
      const targetCoil = coilsRef.current[selectedSlot];
      if (targetCoil) {
        let rotated = 0;
        const spinInterval = setInterval(() => {
          targetCoil.rotation.z += 0.35;
          rotated += 0.35;
          if (rotated >= Math.PI * 2) {
            clearInterval(spinInterval);
          }
        }, 16);
      }

      // 2. Remove any previous dropped item
      if (droppingItemRef.current && machineGroupRef.current) {
        machineGroupRef.current.remove(droppingItemRef.current);
        droppingItemRef.current = null;
      }

      // 3. Spawn a clone of the product to drop realistically
      if (selectedSlot in items) {
        const dropProd = createProductMesh(selectedSlot);
        const startY = selectedSlot <= 2 ? 1.22 : 0.12;
        const startX = selectedSlot % 2 === 1 ? -0.72 : 0.22;
        dropProd.position.set(startX, startY, 0.45);
        machineGroupRef.current.add(dropProd);
        droppingItemRef.current = dropProd;

        // Init drop physics
        dropState.current = {
          active: true,
          slot: selectedSlot,
          t: 0,
          startY,
          targetY: -1.35,
          currentY: startY,
          rotX: 0,
          rotZ: 0
        };
      }
    }
  }, [isDispensing, selectedSlot, items]);

  // Pointer drag event handlers for rotating in 3D
  const handlePointerDown = (e: React.PointerEvent) => {
    isDragging.current = true;
    previousMousePosition.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging.current) return;
    const deltaX = e.clientX - previousMousePosition.current.x;
    const deltaY = e.clientY - previousMousePosition.current.y;

    targetRotationY.current += deltaX * 0.008;
    targetRotationX.current = Math.max(-0.35, Math.min(0.45, targetRotationX.current + deltaY * 0.006));

    previousMousePosition.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerUp = () => {
    isDragging.current = false;
  };

  // Preset Camera Angles
  const setPresetAngle = (angle: 'front' | 'right' | 'left' | 'chute') => {
    switch (angle) {
      case 'front':
        targetRotationY.current = 0;
        targetRotationX.current = 0;
        break;
      case 'right':
        targetRotationY.current = 0.55;
        targetRotationX.current = 0.08;
        break;
      case 'left':
        targetRotationY.current = -0.55;
        targetRotationX.current = 0.08;
        break;
      case 'chute':
        targetRotationY.current = 0.1;
        targetRotationX.current = 0.35;
        break;
    }
  };

  const handleZoom = (delta: number) => {
    const newZoom = Math.max(3.8, Math.min(7.5, cameraZoom + delta));
    setCameraZoom(newZoom);
    if (cameraRef.current) {
      cameraRef.current.position.z = newZoom;
    }
  };

  return (
    <div className="relative w-full flex flex-col items-center select-none">
      {/* 3D WebGL Canvas Container */}
      <div
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onPointerLeave={handlePointerUp}
        className="w-full h-80 lg:h-96 rounded-2xl border-4 border-slate-950 pop-card overflow-hidden relative cursor-grab active:cursor-grabbing bg-gradient-to-b from-slate-950 via-purple-950 to-slate-900 shadow-2xl"
      >
        {/* Dedicated isolated mount for Three.js canvas - NO React child nodes inside */}
        <div ref={canvasMountRef} className="absolute inset-0 w-full h-full pointer-events-none" />

        {/* Floating Top Badge */}
        <div className="absolute top-2.5 left-2.5 z-10 flex items-center gap-2 bg-slate-950/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-purple-500/50 text-[11px] font-mono text-purple-300 shadow-md pointer-events-none">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping" />
          <span className="font-black text-amber-300">★ REAL 3D VENDING MACHINE (THREE.JS) ★</span>
        </div>

        {/* Floating Hint: Drag to Rotate */}
        <div className="absolute bottom-2.5 left-2.5 z-10 flex items-center gap-1.5 bg-slate-950/75 backdrop-blur-sm px-2.5 py-1 rounded-lg border border-slate-700 text-[10px] text-slate-300 pointer-events-none">
          <RotateCw className="w-3 h-3 text-purple-400 animate-spin-slow" />
          <span>Geser / Drag layar untuk memutar sudut 3D 360°</span>
        </div>

        {/* Status Drop Indicator */}
        {isDispensing && (
          <div className="absolute top-12 left-1/2 -translate-x-1/2 z-20 bg-amber-400 text-slate-950 px-4 py-1.5 rounded-full border-2 border-slate-950 font-black text-xs uppercase tracking-wider shadow-lg flex items-center gap-2 animate-bounce">
            <Sparkles className="w-4 h-4" />
            <span>Pegas 3D Berputar & Menjatuhkan Minuman...</span>
          </div>
        )}

        {/* Dispensed Item Floating Banner */}
        {dispensedItem && !isDispensing && (
          <div className="absolute bottom-12 right-3 z-20 bg-emerald-500 text-slate-950 px-3 py-1.5 rounded-xl border-2 border-slate-950 font-black text-xs shadow-lg flex items-center gap-2 animate-fadeIn">
            <span className="text-xl">{dispensedItem.icon}</span>
            <div>
              <div className="text-[9px] uppercase tracking-wider text-emerald-950">Siap Diambil di Nampan 3D</div>
              <div className="leading-tight">{dispensedItem.name}</div>
            </div>
          </div>
        )}
      </div>

      {/* 3D Camera Controls Toolbar */}
      <div className="w-full mt-2.5 p-2 bg-slate-900 border-2 border-slate-950 rounded-xl flex flex-wrap items-center justify-between gap-2 text-xs font-bold text-slate-200 pop-card-sm shadow-md">
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] font-mono text-purple-400 flex items-center gap-1 mr-1">
            <Eye className="w-3.5 h-3.5" />
            <span>SUDUT KAMERA 3D:</span>
          </span>
          <button
            onClick={() => setPresetAngle('front')}
            className="px-2 py-1 rounded bg-slate-800 hover:bg-purple-600 hover:text-white border border-slate-700 text-[10px] cursor-pointer transition-colors"
          >
            Tampak Depan
          </button>
          <button
            onClick={() => setPresetAngle('right')}
            className="px-2 py-1 rounded bg-slate-800 hover:bg-purple-600 hover:text-white border border-slate-700 text-[10px] cursor-pointer transition-colors"
          >
            Miring Kanan
          </button>
          <button
            onClick={() => setPresetAngle('left')}
            className="px-2 py-1 rounded bg-slate-800 hover:bg-purple-600 hover:text-white border border-slate-700 text-[10px] cursor-pointer transition-colors"
          >
            Miring Kiri
          </button>
          <button
            onClick={() => setPresetAngle('chute')}
            className="px-2 py-1 rounded bg-slate-800 hover:bg-purple-600 hover:text-white border border-slate-700 text-[10px] cursor-pointer transition-colors"
          >
            Nampan Bawah
          </button>
        </div>

        <div className="flex items-center gap-1">
          <button
            onClick={() => handleZoom(-0.5)}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded border border-slate-700 cursor-pointer"
            title="Zoom In 3D"
          >
            <ZoomIn className="w-3.5 h-3.5 text-sky-400" />
          </button>
          <button
            onClick={() => handleZoom(0.5)}
            className="p-1.5 bg-slate-800 hover:bg-slate-700 rounded border border-slate-700 cursor-pointer"
            title="Zoom Out 3D"
          >
            <ZoomOut className="w-3.5 h-3.5 text-sky-400" />
          </button>
          <button
            onClick={() => setAutoRotate(!autoRotate)}
            className={`px-2 py-1 rounded border text-[10px] font-black cursor-pointer transition-all ${
              autoRotate
                ? 'bg-amber-400 text-slate-950 border-amber-500'
                : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
            }`}
          >
            {autoRotate ? '⏸️ Stop Putar' : '▶️ Auto Putar 3D'}
          </button>
        </div>
      </div>
    </div>
  );
}
